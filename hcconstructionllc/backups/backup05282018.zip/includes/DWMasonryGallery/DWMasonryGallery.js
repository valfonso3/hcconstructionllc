(function($) { 

	if(typeof Object.create != 'function') {
	  Object.create = (function() {
	    var Temp = function() {};
	    return function (prototype) {
	      if (arguments.length > 1) {
	        throw Error('Second argument not supported');
	      }
	      if (typeof prototype != 'object') {
	        throw TypeError('Argument must be an object');
	      }
	      Temp.prototype = prototype;
	      var result = new Temp();
	      Temp.prototype = null;
	      return result;
	    };
	  })();
	}
	if(typeof Object.keys != 'function') { 
		Object.keys = function(o,k,r){r=[];for(k in o)r.hasOwnProperty.call(o,k)&&r.push(k);return r};
	}
	if (!String.prototype.trim) {
	  (function() {
		// Make sure we trim BOM and NBSP
		var rtrim = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g;
		String.prototype.trim = function() {
		  return this.replace(rtrim, '');
		};
	  })();
	}
	
	$.fn.DWMasonryGallery = function(isSkin) {
		DWMasonryGallery($(this), isSkin);
	}
	
	function DWMasonryGallery(elem, isSkin) {
		var name = elem.attr('id');
		var xtdcode = '04dbe9451b';
		var firstAlbum;
		
		if (window.project) {
			if (!isSkin) {
				var options = $.extend({}, window.project.jsData);
				options.structure = window.project.structure;
				options.imagesInfo = window.project.imagesInfo;
			} else {
				var options = $.extend({}, window.project.skinJsData);
				options.structure = window.project.skinStructure;
				options.imagesInfo = window.project.skinImagesInfo;
			}
			elem.find('.DWMasonryGallery_loadMoreHolder').remove();
			options.relativePath = "";
			options.albumsMobileDropdown = false;
		} else {
			var options = $.extend({}, window[name+'_json']);
			$("link").each(function() {
				if (endsWith($(this).attr('href'), name+".css")) {
					options.relativePath = $(this).attr('href').replace(name+".css", '');
				}
			});
		}
		options.stillAnimating = false;
		
		elem.find('.DWMasonryGallery_widget').remove();
		if (options.percentPosition) {
			options.containerSize = Number((parseInt(options.columnWidth)/100).toString().match(/^\d+(?:\.\d{0,2})?/))*elem.width();
		} else {
			options.containerSize = parseInt(options.columnWidth);
		}
		elem.css('visibility', 'hidden');
		options.columnsSize = Math.round(options.containerSize/parseInt(options.columns));
		var spacingValue = elem.find(".gutter-sizer").width();
		for (var album in options.structure) {
			for (var i=0; i<options.structure[album].length; i++) {
				var nrColumns = options.imagesInfo[options.structure[album][i]].columns;
				var columnClass = "columns"+nrColumns;
				var imageSize = '640';
				if (options.columnsSize*nrColumns>640) {
					if (options.columnsSize*nrColumns>1280) {
						imageSize = '1920';
					} else {
						imageSize = '1280';
					}
				}
				if (options.isLightbox) {
					elem.append('<div class="DWMasonryGallery_widget '+columnClass+'"><div class="itemWrapper"><a class="grouped_elements" data-item="'+name+'" rel="'+album.replace(/[^a-zA-Z0-9]/g, "_")+'" href="'+options.relativePath+name+'/1920/'+options.structure[album][i]+'" data-title="'+options.imagesInfo[options.structure[album][i]].title+'" data-description="'+options.imagesInfo[options.structure[album][i]].description+'"><img class="lazy" data-name="'+options.structure[album][i]+'" data-original="'+options.relativePath+name+'/'+imageSize+'/'+options.structure[album][i]+'" alt="'+options.imagesInfo[options.structure[album][i]].alt+'" /></a></div></div>');
				} else {
					elem.append('<div class="DWMasonryGallery_widget '+columnClass+'"><div class="itemWrapper"><a class="grouped_elements" data-item="'+name+'" rel="'+album.replace(/[^a-zA-Z0-9]/g, "_")+'" href="'+options.imagesInfo[options.structure[album][i]].to+'" target="'+options.imagesInfo[options.structure[album][i]].target+'" data-title="'+options.imagesInfo[options.structure[album][i]].title+'" data-description="'+options.imagesInfo[options.structure[album][i]].description+'"><img class="lazy" data-name="'+options.structure[album][i]+'" data-original="'+options.relativePath+name+'/'+imageSize+'/'+options.structure[album][i]+'" alt="'+options.imagesInfo[options.structure[album][i]].alt+'" /></a></div></div>');
				}
				elem.find(".DWMasonryGallery_widget").css('margin-bottom', spacingValue+"px");
				if (options.titlesDescription!='false') {
					var showTitle = options.showTitle;
					var showDescription = options.showDescription;
					if (showTitle || showDescription) {
						switch (options.titlesDescription) {
							case "hover":
								var itemsHeight = 0;
								elem.find(".DWMasonryGallery_widget").last().find('.itemWrapper').append('<div class="DWMasonryGallery_hoverOverlay"></div>');
								if (showTitle && options.imagesInfo[options.structure[album][i]].title!='') {
									elem.find(".DWMasonryGallery_widget").last().find('.DWMasonryGallery_hoverOverlay').append('<p class="DWMasonryGallery_title">'+options.imagesInfo[options.structure[album][i]].title+'</p>');
									itemsHeight += elem.find(".DWMasonryGallery_widget").last().find('.DWMasonryGallery_title').outerHeight(true, true);
								}
								if (showDescription && options.imagesInfo[options.structure[album][i]].description!='') {
									elem.find(".DWMasonryGallery_widget").last().find('.DWMasonryGallery_hoverOverlay').append('<p class="DWMasonryGallery_description">'+options.imagesInfo[options.structure[album][i]].description+'</p>');
									itemsHeight += elem.find(".DWMasonryGallery_widget").last().find('.DWMasonryGallery_description').outerHeight(true, true);
								}
								var containerHeight = elem.find(".DWMasonryGallery_widget").last().height();
								if (showTitle && showDescription && options.imagesInfo[options.structure[album][i]].title!='' && options.imagesInfo[options.structure[album][i]].description!='') {
									elem.find(".DWMasonryGallery_widget").last().find('.DWMasonryGallery_title').css('margin-top', Math.round((containerHeight - itemsHeight)/2)+"px");
								} else if (showTitle && options.imagesInfo[options.structure[album][i]].title!='') {
									elem.find(".DWMasonryGallery_widget").last().find('.DWMasonryGallery_title').css('margin-top', Math.round((containerHeight - itemsHeight)/2)+"px");
								} else if (showDescription && options.imagesInfo[options.structure[album][i]].description!='') {
									elem.find(".DWMasonryGallery_widget").last().find('.DWMasonryGallery_description').css('margin-top', Math.round((containerHeight - itemsHeight)/2)+"px");
								}
								elem.find(".DWMasonryGallery_widget").last().find('.DWMasonryGallery_hoverOverlay').hide();
								break;
							case "under":
								elem.find(".DWMasonryGallery_widget").last().append('<div class="DWMasonryGallery_divUnder"></div>');
								if (showTitle && options.imagesInfo[options.structure[album][i]].title!='') {
									elem.find(".DWMasonryGallery_widget").last().find('.DWMasonryGallery_divUnder').append('<p class="DWMasonryGallery_title">'+options.imagesInfo[options.structure[album][i]].title+'</p>');
								}
								if (showDescription && options.imagesInfo[options.structure[album][i]].description!='') {
									elem.find(".DWMasonryGallery_widget").last().find('.DWMasonryGallery_divUnder').append('<p class="DWMasonryGallery_description">'+options.imagesInfo[options.structure[album][i]].description+'</p>');
								}
								break;
							case "hover_text":
								elem.find(".DWMasonryGallery_widget").last().find('.itemWrapper').append('<div class="DWMasonryGallery_hoverOverlay"><div class="DWMasonryGallery_hoverOverlayImage"></div></div>');
								elem.find(".DWMasonryGallery_widget").last().find('.DWMasonryGallery_hoverOverlay').hide();
								elem.find(".DWMasonryGallery_widget").last().append('<div class="DWMasonryGallery_divUnder"></div>');
								if (showTitle && options.imagesInfo[options.structure[album][i]].title!='') {
									elem.find(".DWMasonryGallery_widget").last().find('.DWMasonryGallery_divUnder').append('<p class="DWMasonryGallery_title">'+options.imagesInfo[options.structure[album][i]].title+'</p>');
								}
								if (showDescription && options.imagesInfo[options.structure[album][i]].description!='') {
									elem.find(".DWMasonryGallery_widget").last().find('.DWMasonryGallery_divUnder').append('<p class="DWMasonryGallery_description">'+options.imagesInfo[options.structure[album][i]].description+'</p>');
								}
								break;
						}
					}
				}
			}
			break;
		}
		elem.find(".itemWrapper").css('transition', 'none');
		options.oldWindowWidth = $(window).width();
		elem.find(".itemWrapper").each(function() {
            var image = $(this).find('img').attr('data-name');
            if ($(this).width()< options.imagesInfo[image].width) {
                $(this).height(Math.floor($(this).width()*options.imagesInfo[image].ratio));
				var self=this;
            } else {
                $(this).height(Math.floor(options.imagesInfo[image].width*options.imagesInfo[image].ratio));
				var self=this;
            }
        });
		elem.find(".itemWrapper").each(function() {
            var image = $(this).find('img').attr('data-name');
			$(this).removeAttr('style');
			$(this).find('img').removeAttr('style');
            if ($(this).width()< options.imagesInfo[image].width) {
                $(this).height(Math.floor($(this).width()*options.imagesInfo[image].ratio));
				var self=this;
            } else {
                $(this).height(Math.floor(options.imagesInfo[image].width*options.imagesInfo[image].ratio));
				var self=this;
            }
        });
		elem.find(".itemWrapper").css('transition', '');
		if (options.titlesDescription=='hover' && (options.showTitle || options.showDescription)) {
			doHover(elem, options);
		}
		
		if (options.titlesDescription=='hover_text') {
			doHoverOverlay(elem, options);
		}
		
		elem.find('.DWMasonryGallery_widget').hide();
		elem.find(".DWMasonryGallery_albumsWrapper").html("");
		
		var shown = false;
		if (options.showAlbums) {
			for (var album in options.structure) {
				var newA = $(document.createElement('a'));
				newA.attr('data-album', album);
				newA.attr('href', 'javascript:void(0)');
				newA.data('album', album);
				if (!shown) {
					firstAlbum = album;
					shown = true;
					newA.attr('class', 'DWMasonryGallery_albumButton selected');
				} else {
					newA.attr('class', 'DWMasonryGallery_albumButton');
				}
				newA.html(album);
				elem.find(".DWMasonryGallery_albumsWrapper").append(newA);
			}
			if (options.albumsMobileDropdown) {
				elem.find(".DWMasonryGallery_albumsWrapper").append('<select style="display:none;" class="DWMasonryGallery_mobileSelect"></select>');
				shown = false;
				for (var album in options.structure) {
					var newOption = $(document.createElement('option'));
					newOption.data('album', album);
					newOption.attr('value', album);
					newOption.html(album);
					elem.find(".DWMasonryGallery_mobileSelect").append(newOption);
				}
			}
		}
		
		if ($(window).width()<=parseInt(options.devices.mobile.width) && options.albumsMobileDropdown) {
			elem.find(".DWMasonryGallery_albumButton").hide();
			elem.find(".DWMasonryGallery_mobileSelect").show();
			//add padding for mobile here
		}
		
		if (options.albumsMobileDropdown) {
			$(window).unbind("resize.mobile"+name).bind("resize.mobile"+name, function() {
				if ($(window).width()<=parseInt(options.devices.mobile.width)) {
					elem.find(".DWMasonryGallery_albumButton").hide();
					elem.find(".DWMasonryGallery_mobileSelect").show();
					//add padding for mobile here
				} else {
					elem.find(".DWMasonryGallery_albumButton").show();
					elem.find(".DWMasonryGallery_mobileSelect").hide();
				}
			});
		}
		
		if (options.showAlbums) {
			elem.css('padding-top', elem.find(".DWMasonryGallery_albumsWrapper").outerHeight(true, true)+"px");
		} else {
			elem.css('padding-top', "0px");
		}
		
		elem.find('.DWMasonryGallery_mobileSelect').unbind('change').change(function() {
			if (!options.stillAnimating) {
				options.stillAnimating = true;
				$(this).siblings('.DWMasonryGallery_albumButton').removeClass('selected');
				elem.find('[data-album="'+$(this).val()+'"]').addClass('selected');
				changeAlbum($(this).val(), options, elem);
			} else {
				options.clickedButton = $(this);
				$(this).siblings('.DWMasonryGallery_albumButton').removeClass('selected');
				elem.find('[data-album="'+$(this).val()+'"]').addClass('selected');
			}
		});
		
		elem.find(".DWMasonryGallery_albumsWrapper .DWMasonryGallery_albumButton").click(function() {
			if (!$(this).hasClass('selected') && !options.stillAnimating) {
				$(this).siblings('.DWMasonryGallery_albumButton').removeClass('selected');
				$(this).addClass('selected');
				options.stillAnimating = true;
				elem.find('[data-album="'+$(this).data('album')+'"]').addClass('selected');
				elem.find('.DWMasonryGallery_mobileSelect').val($(this).data('album'));
				changeAlbum($(this).data('album'), options, elem);
			} else if (options.stillAnimating) {
				$(this).siblings('.DWMasonryGallery_albumButton').removeClass('selected');
				$(this).addClass('selected');
				elem.find('.DWMasonryGallery_mobileSelect').val($(this).data('album'));
				options.clickedButton = $(this);
			}
		});
		
		$(window).unbind("resize.height"+name+" orientationchange.height"+name).on("resize.height"+name+" orientationchange.height"+name, function() {
			if (options.oldWindowWidth == $(window).width()) {
				return;
			} else {
				options.oldWindowWidth = $(window).width();
			}
			elem.masonry('destroy');
			elem.find(".DWMasonryGallery_widget").show();
			var spacingValue = elem.find(".gutter-sizer").width();
			elem.find(".DWMasonryGallery_widget").css('margin-bottom', spacingValue+"px");
			elem.find(".itemWrapper").css('transition', 'none');
			elem.find(".itemWrapper").each(function() {
				if ($(this).width()< options.imagesInfo[$(this).find('img[data-name]').attr('data-name')].width) {
					$(this).height(Math.floor($(this).width()*options.imagesInfo[$(this).find('img[data-name]').attr('data-name')].ratio));
					var self=this;
				} else {
					$(this).height(Math.floor(options.imagesInfo[$(this).find('img[data-name]').attr('data-name')].width*options.imagesInfo[$(this).find('img[data-name]').attr('data-name')].ratio));
					var self=this;
				}
			});
			elem.find(".itemWrapper").css('transition', '');
			elem.css('padding-top', elem.find(".DWMasonryGallery_albumsWrapper").outerHeight(true, true));
			elem.masonry({
				"columnWidth": options.percentPosition ? ".grid-sizer" : parseInt(options.columnWidth),
				"itemSelector": '.DWMasonryGallery_widget',
				"percentPosition": options.percentPosition,
				"gutter": options.percentPosition ? ".gutter-sizer" : parseInt(options.gutter),
				"transitionDuration": options.transitionDuration,
				"hiddenStyle": {opacity: 0},
				"visibleStyle": {opacity: 1}
			});
			elem.find(".DWMasonryGallery_widget.hiddenItem").hide();
			var maxHeight=0;
			elem.find('.DWMasonryGallery_widget').each(function() {
				if ($(this).is(":visible")) {
					if ((parseInt($(this).css('top')) + parseInt($(this).outerHeight(true, true))) > maxHeight)
						maxHeight = parseInt($(this).css('top')) + parseInt($(this).outerHeight(true, true));
				}
			});
			if (maxHeight==0)
				maxHeight = 10;
			else
				maxHeight = maxHeight - parseInt(elem.css('padding-top'));
			if (elem.find('.DWMasonryGallery_widget.hiddenItem').length==0) {
				elem.find(".DWMasonryGallery_loadMoreHolder").remove();
			}
			if (elem.find('.DWMasonryGallery_loadMoreHolder').length) {

				elem.css('height', maxHeight+elem.find(".DWMasonryGallery_loadMoreHolder").outerHeight(true, true));
			} else {

				elem.css('height', maxHeight);
			}
		});

		elem.find('.DWMasonryGallery_widget').each(function() {
			$(this).show();
		});
		elem.imagesLoaded( function() {
			elem.masonry({
				"columnWidth": options.percentPosition ? ".grid-sizer" : parseInt(options.columnWidth),
				"itemSelector": '.DWMasonryGallery_widget',
				"percentPosition": options.percentPosition,
				"gutter": options.percentPosition ? ".gutter-sizer" : parseInt(options.gutter),
				"transitionDuration": options.transitionDuration,
				"hiddenStyle": {opacity: 0},
				"visibleStyle": {opacity: 1}
			});
			elem.data('currentAlbum', firstAlbum);
			if (options.isLightbox) {
				if(isTabletDevice) {
					doTouchLightbox(elem, name, options);
				} else {
					elem.find("a.grouped_elements").fancybox({
						margin: 60,
						elemName: elem.attr('id'),
						padding: 0,
						cyclic: true,
						overlayShow: options.overlayColor=='none' ? false : true,
						overlayColor: options.overlayColor,
						skin: options.lightboxSkin ? options.lightboxSkin : "skin1",
						overlayOpacity: options.overlayOpacity,
						showCloseButton: options.lightboxClose,
						showNavArrows: options.lightboxPrevNext,
						titlePosition: "inside",
						transitionIn : options.lightboxEffect,
						transitionOut : options.lightboxEffect,  
						changeFade: parseInt(options.lightboxSpeed),
						speedIn: parseInt(options.lightboxSpeed),
						speedOut: parseInt(options.lightboxSpeed),
						textPosition: options.lightboxTextPosition,
						titleFormat: function(title, currentArray, currentIndex, currentOpts){
							var currentImage = $(currentArray[currentIndex]).children('img').attr('data-name');
							toReturn = '';
							if (options.lightboxTitle && options.lightboxDescription)
								return "<p class='"+name+"_lightboxTitle'>"+options.imagesInfo[currentImage].title+"</p><p class='"+name+"_lightboxDescription' style='margin:0;'>"+options.imagesInfo[currentImage].description+"</p>";
							else if (options.lightboxTitle) {
								return "<p class='"+name+"_lightboxTitle' style='margin:0;'>"+options.imagesInfo[currentImage].title+"</p>";
							} else if (options.lightboxDescription) {
								return "<p class='"+name+"_lightboxDescription' style='margin:0;'>"+options.imagesInfo[currentImage].description+"</p>";
							}
						}
					});
				}
			} else if (window.project) {
				$("a.grouped_elements").click(function(ev) {
					ev.preventDefault();
					ev.stopPropagation();
					return false;
				});
			}
			if (options.infiniteScroll) {
				doInfiniteScroll(elem, options)
				$(window).unbind('scroll.reveal'+name).bind('scroll.reveal'+name, function() {
					doScroll(elem)
				});
				$(elem).parent().unbind('scroll.reveal'+name).bind('scroll.reveal'+name, function() {
					doScroll(elem)
				});
			} else {
				doLoadMore(elem, options, name)
			}
			elem.css('visibility', 'visible');
			if(options.xtdCode=="#xtd_code#" || xtdcode != options.xtdCode) {
				 makeTopVisible();
			}
			if (elem.attr('data-scrollreveal')) {
				var revealFXInterval = setInterval(function() {
					if (elem.attr('data-scrollreveal-complete')) {
						clearInterval(revealFXInterval);
						elem.css('visibility', 'visible');
						options.oldWindowWidth = 0;
						$(window).trigger('resize.height'+elem.attr('id'));
					}
				}, 10);
			}
			var scrollbarInterval = setInterval(function() {
				var msnry = Masonry.data(elem.get(0));
				if (msnry._isLayoutInited) {
					clearInterval(scrollbarInterval);
					$(window).trigger('resize.height'+elem.attr('id'));
				}
			},10);
		});
	}
	
	function doScroll(elem) {
		var maxHeight = 0;
		elem.find('.hiddenItem').each(function() {
			$(this).show();
			if (isElementInViewport_gallery(this)) {
				var item = elem.masonry( 'getItem', this );
				elem.masonry('reveal', [item]);
				$(this).removeClass('hiddenItem');
				$(this).find('img').trigger('sporty');
			} else {
				$(this).hide();
			}
		});
		elem.find('.DWMasonryGallery_widget').each(function() {
			if (isElementInViewport_gallery(this)) {
				if ((parseInt($(this).css('top')) + parseInt($(this).outerHeight(true, true))) > maxHeight)
					maxHeight = parseInt($(this).css('top')) + parseInt($(this).outerHeight(true, true));
			}
		});
		if (maxHeight==0)
			maxHeight = 10;
		else
			maxHeight = maxHeight - parseInt(elem.css('padding-top'));
		if (maxHeight > elem.height())
			elem.css('height', maxHeight);
		if (elem.parents('.jQueryTabs_container').length) {
			doTabsHeight(elem, options);
		}
	}
	
	function changeAlbum(album, options, elem) {
		var name = elem.attr('id');
		var itemsToAdd = [];
		var itemsToRemove = [];
		window.removedElements = false;
		elem.find('.DWMasonryGallery_widget').each(function() {
			var self = this;
			if ($(this).is(":visible"))
				itemsToRemove.push(self);
			else 
				$(this).remove();
		});
		var spacingValue = elem.find(".gutter-sizer").width();
		for (var i=0; i<options.structure[album].length; i++) {
			var newDiv = document.createElement('div');
			var nrColumns = options.imagesInfo[options.structure[album][i]].columns;
			var columnClass = "columns"+nrColumns;
			var imageSize = '640';
			if (options.columnsSize*nrColumns>640) {
				if (options.columnsSize*nrColumns>1280) {
					imageSize = '1920';
				} else {
					imageSize = '1280';
				}
			}
			$(newDiv).attr('class', 'DWMasonryGallery_widget '+columnClass);
			if (options.isLightbox) {
				$(newDiv).html('<div class="itemWrapper"><a class="grouped_elements" data-item="'+name+'" rel="'+album.replace(/[^a-zA-Z0-9]/g, "_")+'" href="'+options.relativePath+name+'/1920/'+options.structure[album][i]+'" data-title="'+options.imagesInfo[options.structure[album][i]].title+'" data-description="'+options.imagesInfo[options.structure[album][i]].description+'"><img class="lazy" data-name="'+options.structure[album][i]+'" data-original="'+options.relativePath+name+'/'+imageSize+'/'+options.structure[album][i]+'" alt="'+options.imagesInfo[options.structure[album][i]].alt+'" /></a></div>');
			} else {
				$(newDiv).html('<div class="itemWrapper"><a class="grouped_elements" data-item="'+name+'" rel="'+album.replace(/[^a-zA-Z0-9]/g, "_")+'" href="'+options.imagesInfo[options.structure[album][i]].to+'" target="'+options.imagesInfo[options.structure[album][i]].target+'" data-title="'+options.imagesInfo[options.structure[album][i]].title+'" data-description="'+options.imagesInfo[options.structure[album][i]].description+'"><img class="lazy" data-name="'+options.structure[album][i]+'" data-original="'+options.relativePath+name+'/'+imageSize+'/'+options.structure[album][i]+'" alt="'+options.imagesInfo[options.structure[album][i]].alt+'" /></a></div>');
			}
			$(newDiv).css('opacity', '0').css('position', 'absolute');
			elem.append(newDiv);
			elem.find(".DWMasonryGallery_widget").css('margin-bottom', spacingValue+"px");
			elem.find(".itemWrapper").css('transition', 'none');
			if (elem.find(".itemWrapper").last().width() < options.imagesInfo[options.structure[album][i]].width) {
				elem.find(".itemWrapper").last().height(Math.floor(elem.find(".itemWrapper").last().width()*options.imagesInfo[options.structure[album][i]].ratio));
			} else {
				elem.find(".itemWrapper").last().height(Math.floor(options.imagesInfo[options.structure[album][i]].width*options.imagesInfo[options.structure[album][i]].ratio));
			}
			elem.find(".itemWrapper").css('transition', '');
			itemsToAdd.push(newDiv);
			if (options.titlesDescription!='false') {
				var showTitle = options.showTitle;
				var showDescription = options.showDescription;
				if (showTitle || showDescription) {
					switch (options.titlesDescription) {
						case "hover":
							var itemsHeight = 0;
							elem.find(".DWMasonryGallery_widget").last().find('.itemWrapper').append('<div class="DWMasonryGallery_hoverOverlay"></div>');
							if (showTitle && options.imagesInfo[options.structure[album][i]].title!='') {
								elem.find(".DWMasonryGallery_widget").last().find('.DWMasonryGallery_hoverOverlay').append('<p class="DWMasonryGallery_title">'+options.imagesInfo[options.structure[album][i]].title+'</p>');
								itemsHeight += elem.find(".DWMasonryGallery_widget").last().find('.DWMasonryGallery_title').outerHeight(true, true);
							}
							if (showDescription && options.imagesInfo[options.structure[album][i]].description!='') {
								elem.find(".DWMasonryGallery_widget").last().find('.DWMasonryGallery_hoverOverlay').append('<p class="DWMasonryGallery_description">'+options.imagesInfo[options.structure[album][i]].description+'</p>');
								itemsHeight += elem.find(".DWMasonryGallery_widget").last().find('.DWMasonryGallery_description').outerHeight(true, true);
							}
							var containerHeight = elem.find(".DWMasonryGallery_widget").last().height();
							if (showTitle && showDescription && options.imagesInfo[options.structure[album][i]].title!='' && options.imagesInfo[options.structure[album][i]].description!='') {
								elem.find(".DWMasonryGallery_widget").last().find('.DWMasonryGallery_title').css('margin-top', Math.round((containerHeight - itemsHeight)/2)+"px");
							} else if (showTitle && options.imagesInfo[options.structure[album][i]].title!='') {
								elem.find(".DWMasonryGallery_widget").last().find('.DWMasonryGallery_title').css('margin-top', Math.round((containerHeight - itemsHeight)/2)+"px");
							} else if (showDescription && options.imagesInfo[options.structure[album][i]].description!='') {
								elem.find(".DWMasonryGallery_widget").last().find('.DWMasonryGallery_description').css('margin-top', Math.round((containerHeight - itemsHeight)/2)+"px");
							}
							elem.find(".DWMasonryGallery_widget").last().find('.DWMasonryGallery_hoverOverlay').hide();
							break;
						case "under":
							elem.find(".DWMasonryGallery_widget").last().append('<div class="DWMasonryGallery_divUnder"></div>');
							if (showTitle && options.imagesInfo[options.structure[album][i]].title!='') {
								elem.find(".DWMasonryGallery_widget").last().find('.DWMasonryGallery_divUnder').append('<p class="DWMasonryGallery_title">'+options.imagesInfo[options.structure[album][i]].title+'</p>');
							}
							if (showDescription && options.imagesInfo[options.structure[album][i]].description!='') {
								elem.find(".DWMasonryGallery_widget").last().find('.DWMasonryGallery_divUnder').append('<p class="DWMasonryGallery_description">'+options.imagesInfo[options.structure[album][i]].description+'</p>');
							}
							break;
						case "hover_text":
							elem.find(".DWMasonryGallery_widget").last().find('.itemWrapper').append('<div class="DWMasonryGallery_hoverOverlay"><div class="DWMasonryGallery_hoverOverlayImage"></div></div>');
							elem.find(".DWMasonryGallery_widget").last().find('.DWMasonryGallery_hoverOverlay').hide();
							elem.find(".DWMasonryGallery_widget").last().append('<div class="DWMasonryGallery_divUnder"></div>');
							if (showTitle && options.imagesInfo[options.structure[album][i]].title!='') {
								elem.find(".DWMasonryGallery_widget").last().find('.DWMasonryGallery_divUnder').append('<p class="DWMasonryGallery_title">'+options.imagesInfo[options.structure[album][i]].title+'</p>');
							}
							if (showDescription && options.imagesInfo[options.structure[album][i]].description!='') {
								elem.find(".DWMasonryGallery_widget").last().find('.DWMasonryGallery_divUnder').append('<p class="DWMasonryGallery_description">'+options.imagesInfo[options.structure[album][i]].description+'</p>');
							}
							break;
					}
				}
			}
		}
		if (options.titlesDescription=='hover' && (options.showTitle || options.showDescription)) {
			doHover(elem, options);
		}
		if (options.titlesDescription=='hover_text') {
			doHoverOverlay(elem, options);
		}
		var elemHeight = elem.height();
		if (options.clickedButton && options.clickedButton!=null) {
			var newAlbum = options.clickedButton.data('album');
			options.clickedButton = null;
			for (var i in itemsToAdd) {
				if ($(itemsToAdd[i]).length) {
					$(itemsToAdd[i]).remove();
				}
			}
			changeAlbum(newAlbum, options, elem);
			return false;
		} else {
			if (itemsToRemove.length) {
				elem.masonry( 'remove', itemsToRemove );
				var msnry = Masonry.data(elem.get(0));
				if (Browser.IsIe() && Browser.Version() <= 9) {
					if (options.clickedButton && options.clickedButton!=null) {
						var newAlbum = options.clickedButton.data('album');
						options.clickedButton = null;
						for (var i in itemsToAdd) {
							if ($(itemsToAdd[i]).length) {
								$(itemsToAdd[i]).remove();
							}
						}
						changeAlbum(newAlbum, options, elem);
						return false;
					} else {
						elem.masonry('destroy');
						elem.height(elemHeight);
						elem.masonry({
							"columnWidth": options.percentPosition ? ".grid-sizer" : parseInt(options.columnWidth),
							"itemSelector": '.DWMasonryGallery_widget',
							"percentPosition": options.percentPosition,
							"gutter": options.percentPosition ? ".gutter-sizer" : parseInt(options.gutter),
							"transitionDuration": options.transitionDuration,
							"hiddenStyle": {opacity: 0},
							"visibleStyle": {opacity: 1}
						});
						if (options.clickedButton && options.clickedButton!=null) {
							var newAlbum = options.clickedButton.data('album');
							options.clickedButton = null;
							for (var i in itemsToAdd) {
								if ($(itemsToAdd[i]).length) {
									$(itemsToAdd[i]).remove();
								}
							}
							changeAlbum(newAlbum, options, elem);
							return false;
						} else {
							elem.masonry('reveal', Masonry.data(elem.get(0)).items);
							if (itemsToAdd.length) {
								setTimeout(function() {
									options.stillAnimating = false;
								}, 100);
							} else {
								options.stillAnimating = false;
							}
							if (options.isLightbox) {
								if(isTabletDevice) {
									doTouchLightbox(elem, name, options);
								} else {
									elem.find("a.grouped_elements").fancybox({
										margin: 60,
										elemName: elem.attr('id'),
										padding: 0,
										cyclic: true,
										overlayShow: options.overlayColor=='none' ? false : true,
										overlayColor: options.overlayColor,
										skin: options.lightboxSkin ? options.lightboxSkin : "skin1",
										overlayOpacity: options.overlayOpacity,
										showCloseButton: options.lightboxClose,
										showNavArrows: options.lightboxPrevNext,
										titlePosition: "inside",
										transitionIn : options.lightboxEffect,
										transitionOut : options.lightboxEffect,  
										changeFade: parseInt(options.lightboxSpeed),
										speedIn: parseInt(options.lightboxSpeed),
										speedOut: parseInt(options.lightboxSpeed),
										textPosition: options.lightboxTextPosition,
										titleFormat: function(title, currentArray, currentIndex, currentOpts){
											var currentImage = $(currentArray[currentIndex]).children('img').attr('data-name');
											toReturn = '';
											if (options.lightboxTitle && options.lightboxDescription)
												return "<p class='"+name+"_lightboxTitle'>"+options.imagesInfo[currentImage].title+"</p><p class='"+name+"_lightboxDescription' style='margin:0;'>"+options.imagesInfo[currentImage].description+"</p>";
											else if (options.lightboxTitle) {
												return "<p class='"+name+"_lightboxTitle' style='margin:0;'>"+options.imagesInfo[currentImage].title+"</p>";
											} else if (options.lightboxDescription) {
												return "<p class='"+name+"_lightboxDescription' style='margin:0;'>"+options.imagesInfo[currentImage].description+"</p>";
											}
										}
									});
								}
							} else if (window.project) {
								$("a.grouped_elements").click(function(ev) {
									ev.preventDefault();
									ev.stopPropagation();
									return false;
								});
							}
							if (options.infiniteScroll) {
								doInfiniteScroll(elem, options);
							} else {
								doLoadMore(elem, options, name);
							}
						}
					}
				} else {
					msnry.on('removeComplete', function() {
						if (options.clickedButton && options.clickedButton!=null) {
							var newAlbum = options.clickedButton.data('album');
							options.clickedButton = null;
							for (var i in itemsToAdd) {
								if ($(itemsToAdd[i]).length) {
									$(itemsToAdd[i]).remove();
								}
							}
							changeAlbum(newAlbum, options, elem);
							return false;
						} else {
							elem.masonry('destroy');
							elem.height(elemHeight);
							elem.masonry({
								"columnWidth": options.percentPosition ? ".grid-sizer" : parseInt(options.columnWidth),
								"itemSelector": '.DWMasonryGallery_widget',
								"percentPosition": options.percentPosition,
								"gutter": options.percentPosition ? ".gutter-sizer" : parseInt(options.gutter),
								"transitionDuration": options.transitionDuration,
								"hiddenStyle": {opacity: 0},
								"visibleStyle": {opacity: 1}
							});
							if (options.clickedButton && options.clickedButton!=null) {
								var newAlbum = options.clickedButton.data('album');
								options.clickedButton = null;
								for (var i in itemsToAdd) {
									if ($(itemsToAdd[i]).length) {
										$(itemsToAdd[i]).remove();
									}
								}
								changeAlbum(newAlbum, options, elem);
								return false;
							} else {
								elem.masonry('reveal', Masonry.data(elem.get(0)).items);
								if (itemsToAdd.length) {
									setTimeout(function() {
										options.stillAnimating = false;
									}, 100);
								} else {
									options.stillAnimating = false;
								}
								if (options.isLightbox) {
									if(isTabletDevice) {
										doTouchLightbox(elem, name, options);
									} else {
										elem.find("a.grouped_elements").fancybox({
											margin: 60,
											elemName: elem.attr('id'),
											padding: 0,
											cyclic: true,
											overlayShow: options.overlayColor=='none' ? false : true,
											overlayColor: options.overlayColor,
											skin: options.lightboxSkin ? options.lightboxSkin : "skin1",
											overlayOpacity: options.overlayOpacity,
											showCloseButton: options.lightboxClose,
											showNavArrows: options.lightboxPrevNext,
											titlePosition: "inside",
											transitionIn : options.lightboxEffect,
											transitionOut : options.lightboxEffect,  
											changeFade: parseInt(options.lightboxSpeed),
											speedIn: parseInt(options.lightboxSpeed),
											speedOut: parseInt(options.lightboxSpeed),
											textPosition: options.lightboxTextPosition,
											titleFormat: function(title, currentArray, currentIndex, currentOpts){
												var currentImage = $(currentArray[currentIndex]).children('img').attr('data-name');
												toReturn = '';
												if (options.lightboxTitle && options.lightboxDescription)
													return "<p class='"+name+"_lightboxTitle'>"+options.imagesInfo[currentImage].title+"</p><p class='"+name+"_lightboxDescription' style='margin:0;'>"+options.imagesInfo[currentImage].description+"</p>";
												else if (options.lightboxTitle) {
													return "<p class='"+name+"_lightboxTitle' style='margin:0;'>"+options.imagesInfo[currentImage].title+"</p>";
												} else if (options.lightboxDescription) {
													return "<p class='"+name+"_lightboxDescription' style='margin:0;'>"+options.imagesInfo[currentImage].description+"</p>";
												}
											}
										});
									}
								} else if (window.project) {
									$("a.grouped_elements").click(function(ev) {
										ev.preventDefault();
										ev.stopPropagation();
										return false;
									});
								}
								if (options.infiniteScroll) {
									doInfiniteScroll(elem, options);
								} else {
									doLoadMore(elem, options, name);
								}
							}
						}
					});
				}
			} else {
				elem.masonry('destroy');
				elem.imagesLoaded( function() {
					elem.masonry({
						"columnWidth": options.percentPosition ? ".grid-sizer" : parseInt(options.columnWidth),
						"itemSelector": '.DWMasonryGallery_widget',
						"percentPosition": options.percentPosition,
						"gutter": options.percentPosition ? ".gutter-sizer" : parseInt(options.gutter),
						"transitionDuration": options.transitionDuration,
						"hiddenStyle": {opacity: 0},
						"visibleStyle": {opacity: 1}
					});
					if (options.clickedButton && options.clickedButton!=null) {
						var newAlbum = options.clickedButton.data('album');
						options.clickedButton = null;
						for (var i in itemsToAdd) {
							if ($(itemsToAdd[i]).length) {
								$(itemsToAdd[i]).remove();
							}
						}
						changeAlbum(newAlbum, options, elem);
						return false;
					} else {
						elem.masonry('reveal', Masonry.data(elem.get(0)).items);
						setTimeout(function() {
							options.stillAnimating = false;
						}, 100);
						if (options.isLightbox) {
							if(isTabletDevice) {
								doTouchLightbox(elem, name, options);
							} else {
								elem.find("a.grouped_elements").fancybox({
									margin: 60,
									elemName: elem.attr('id'),
									padding: 0,
									cyclic: true,
									overlayShow: options.overlayColor=='none' ? false : true,
									overlayColor: options.overlayColor,
									skin: options.lightboxSkin ? options.lightboxSkin : "skin1",
									overlayOpacity: options.overlayOpacity,
									showCloseButton: options.lightboxClose,
									showNavArrows: options.lightboxPrevNext,
									titlePosition: "inside",
									transitionIn : options.lightboxEffect,
									transitionOut : options.lightboxEffect,  
									changeFade: parseInt(options.lightboxSpeed),
									speedIn: parseInt(options.lightboxSpeed),
									speedOut: parseInt(options.lightboxSpeed),
									textPosition: options.lightboxTextPosition,
									titleFormat: function(title, currentArray, currentIndex, currentOpts){
										var currentImage = $(currentArray[currentIndex]).children('img').attr('data-name');
										toReturn = '';
										if (options.lightboxTitle && options.lightboxDescription)
											return "<p class='"+name+"_lightboxTitle'>"+options.imagesInfo[currentImage].title+"</p><p class='"+name+"_lightboxDescription' style='margin:0;'>"+options.imagesInfo[currentImage].description+"</p>";
										else if (options.lightboxTitle) {
											return "<p class='"+name+"_lightboxTitle' style='margin:0;'>"+options.imagesInfo[currentImage].title+"</p>";
										} else if (options.lightboxDescription) {
											return "<p class='"+name+"_lightboxDescription' style='margin:0;'>"+options.imagesInfo[currentImage].description+"</p>";
										}
									}
								});
							}
						} else if (window.project) {
							$("a.grouped_elements").click(function(ev) {
								ev.preventDefault();
								ev.stopPropagation();
								return false;
							});
						}
						if (options.infiniteScroll) {
							doInfiniteScroll(elem, options);
						} else {
							doLoadMore(elem, options, name)
						}
					}
				});
			}
			elem.data('currentAlbum', album);
		}
	}
	
	function doHoverOverlay(elem, options) {
		elem.find(".DWMasonryGallery_widget").unbind('hover').hover(function() {
			$(this).find('.DWMasonryGallery_hoverOverlay').width($(this).find('img').width());
			$(this).find('.DWMasonryGallery_hoverOverlay').height($(this).find('img').height());
			if (options.titlesDescriptionEffect == 'fade' && !(Browser.IsIe() && Browser.Version() <= 8)) { 
				$(this).find('.DWMasonryGallery_hoverOverlay').hide();
				$(this).find('.DWMasonryGallery_hoverOverlay').stop().fadeIn(parseInt(options.titlesDescriptionSpeed));
			} else {
				$(this).find('.DWMasonryGallery_hoverOverlay').show();
			}
		}, function() {
			if (options.titlesDescriptionEffect == 'fade' && !(Browser.IsIe() && Browser.Version() <= 8)) { 
				$(this).find('.DWMasonryGallery_hoverOverlay').stop().fadeOut(parseInt(options.titlesDescriptionSpeed));
			} else {
				$(this).find('.DWMasonryGallery_hoverOverlay').hide();
			}
		});
		elem.find(".DWMasonryGallery_hoverOverlay").unbind('click').bind('click', function() {
			if (options.isLightbox) {
				$(this).siblings('a').trigger('click');
			} else {
				var link = $(this).siblings('a');
				var target = link.attr("target");

				if($.trim(target).length > 0)
				{
					window.open(link.attr("href"), target);
				}
			}
		});
	}
	
	function doHover(elem, options) {
		var showTitle = options.showTitle;
		var showDescription = options.showDescription;
		elem.find(".DWMasonryGallery_widget").unbind('hover').hover(function() {
			$(this).find('.DWMasonryGallery_hoverOverlay').width($(this).find('img').width());
			$(this).find('.DWMasonryGallery_hoverOverlay').height($(this).find('img').height());
			if (options.titlesDescriptionEffect == 'fade' && !(Browser.IsIe() && Browser.Version() <= 8)) { 
				$(this).find('.DWMasonryGallery_hoverOverlay').hide();
				$(this).find('.DWMasonryGallery_hoverOverlay').stop().fadeIn(parseInt(options.titlesDescriptionSpeed));
			} else {
				$(this).find('.DWMasonryGallery_hoverOverlay').show();
			}
			var containerHeight = $(this).height();
			var itemsHeight = 0;
			$(this).find('p').removeAttr('style');
			if (showTitle && $(this).find('.DWMasonryGallery_title').length) {
				itemsHeight += $(this).find('.DWMasonryGallery_title').outerHeight(true, true);
			}
			if (showDescription && $(this).find('.DWMasonryGallery_description').length) {
				itemsHeight += $(this).find('.DWMasonryGallery_description').outerHeight(true, true);
			}
			if (showTitle && showDescription && $(this).find('.DWMasonryGallery_title').length && $(this).find('.DWMasonryGallery_description').length) {
				$(this).find('.DWMasonryGallery_title').css('margin-top', Math.round((containerHeight - itemsHeight)/2)+"px");
			} else if (showTitle && $(this).find('.DWMasonryGallery_title').length) {
				$(this).find('.DWMasonryGallery_title').css('margin-top', Math.round((containerHeight - itemsHeight)/2)+"px");
			} else if (showDescription && $(this).find('.DWMasonryGallery_description').length) {
				$(this).find('.DWMasonryGallery_description').css('margin-top', Math.round((containerHeight - itemsHeight)/2)+"px");
			}
		}, function() {
			if (options.titlesDescriptionEffect == 'fade' && !(Browser.IsIe() && Browser.Version() <= 8)) { 
				$(this).find('.DWMasonryGallery_hoverOverlay').stop().fadeOut(parseInt(options.titlesDescriptionSpeed));
			} else {
				$(this).find('.DWMasonryGallery_hoverOverlay').hide();
			}
		});
		elem.find(".DWMasonryGallery_hoverOverlay").unbind('click').bind('click', function() {
			if (options.isLightbox) {
				$(this).siblings('a').trigger('click');
			} else {
				var link = $(this).siblings('a');
				var target = link.attr("target");

				if($.trim(target).length > 0)
				{
					window.open(link.attr("href"), target);
				}
			}
		});
	}
	
	function doInfiniteScroll(elem, options) {
		elem.find('.DWMasonryGallery_widget img').lazyload({
			event: "sporty"
		});
		elem.find('.DWMasonryGallery_widget img').trigger('sporty');
		var maxHeight = 0;
		elem.find('.DWMasonryGallery_widget').each(function() {
			if (!isElementInViewport_gallery(this)) {
				$(this).css({
					display: "none",
					opacity: "0",
				});
				$(this).addClass('hiddenItem');
			} else {
				if ((parseInt($(this).css('top')) + parseInt($(this).outerHeight(true, true))) > maxHeight)
					maxHeight = parseInt($(this).css('top')) + parseInt($(this).outerHeight(true, true));
			}
		});
		if (maxHeight==0)
			maxHeight = 10;
		else
			maxHeight = maxHeight - parseInt(elem.css('padding-top'));
		elem.css('height', maxHeight);
		if (elem.parents('.jQueryTabs_container').length) {
			doTabsHeight(elem, options);
		}
	}
	
	function doLoadMore(elem, options, name) {
		$(window).unbind('scroll.reveal'+name);
		elem.find('.DWMasonryGallery_widget img').lazyload({
			event: "sporty"
		});
		elem.find('.DWMasonryGallery_widget img').trigger('sporty');
		elem.find('.DWMasonryGallery_loadMoreHolder').remove();
		$(window).unbind('scroll.reveal'+name);
		$(elem).parent().unbind('scroll.reveal'+name);
		var maxHeight = 0;
		options.extraInitial = 0;
		if (options.tablet_friendly && $(window).width() <= parseInt(options.devices.tablet.width) && $(window).width() > parseInt(options.devices.mobile.width) && options.columns%options.tabletColumns == 1) {
			options.extraInitial = 1;
		} else if (options.mobile_friendly && $(window).width() <= parseInt(options.devices.mobile.width) && options.columns%options.mobileColumns == 1) {
			options.extraInitial = 1;
		}
		elem.find('.DWMasonryGallery_widget').each(function(index) {
			if (index>=options.initialImages - options.extraInitial) {
				$(this).css({
					display: "none",
					opacity: "0",
				});
				$(this).addClass('hiddenItem');
			} else {
				if ((parseInt($(this).css('top')) + parseInt($(this).outerHeight(true, true))) > maxHeight)
					maxHeight = parseInt($(this).css('top')) + parseInt($(this).outerHeight(true, true));
			}
		});
		if (maxHeight==0)
			maxHeight = 10;
		else
			maxHeight = maxHeight - parseInt(elem.css('padding-top'));
		elem.css('height', maxHeight);
		if (elem.find('.DWMasonryGallery_widget').length > options.initialImages) {
			elem.append('<div class="DWMasonryGallery_loadMoreHolder"><a href="javascript:void(0)" class="DWMasonryGallery_loadMore">'+options.loadMoreText+'</a></div>');
		}
		elem.height(elem.height()+elem.find(".DWMasonryGallery_loadMoreHolder").outerHeight(true, true));
		elem.find(".DWMasonryGallery_loadMore").unbind('click').click(function() {
			var maxHeight = 0;
			if ($(window).width() <= parseInt(options.devices.tablet.width) && options.columns%options.tabletColumns == 1) {
			options.extraInitial = 1;
			} else if ($(window).width() <= parseInt(options.devices.mobile.width) && options.columns%options.mobileColumns == 1) {
				options.extraInitial = 1;
			} else {
				options.extraInitial = 0;
			}
			var compensation = elem.find('.DWMasonryGallery_widget:not(".hiddenItem")').length%(options.initialImages - options.extraInitial)
			elem.find('.DWMasonryGallery_widget.hiddenItem').each(function(index) {
				if (index<options.initialImages - options.extraInitial - compensation) {
					$(this).show();
					var item = elem.masonry( 'getItem', this );
					elem.masonry('reveal', [item]);
					$(this).removeClass('hiddenItem');
					$(this).find('img').trigger('sporty');
				}
			});
			elem.find('.DWMasonryGallery_widget').each(function() {
				if ($(this).is(":visible")) {
					if ((parseInt($(this).css('top')) + parseInt($(this).outerHeight(true, true))) > maxHeight)
						maxHeight = parseInt($(this).css('top')) + parseInt($(this).outerHeight(true, true));
				}
			});
			if (maxHeight==0)
				maxHeight = 10;
			else
				maxHeight = maxHeight - parseInt(elem.css('padding-top'));
			if (elem.find('.DWMasonryGallery_widget.hiddenItem').length==0) {
				elem.find(".DWMasonryGallery_loadMoreHolder").remove();
			}
			if (elem.find('.DWMasonryGallery_loadMoreHolder').length) {
				elem.css('height', maxHeight+elem.find(".DWMasonryGallery_loadMoreHolder").outerHeight(true, true));
			} else {
				elem.css('height', maxHeight);
			}
			if (elem.parents('.jQueryTabs_container').length) {
				doTabsHeight(elem, options);
			}
		});
		elem.find(".DWMasonryGallery_loadMore").unbind('hover').hover(function() {
			var maxHeight = 0;
			elem.find('.DWMasonryGallery_widget').each(function() {
				if ($(this).is(":visible")) {
					if ((parseInt($(this).css('top')) + parseInt($(this).outerHeight(true, true))) > maxHeight)
						maxHeight = parseInt($(this).css('top')) + parseInt($(this).outerHeight(true, true));
				}
			});
			if (maxHeight==0)
				maxHeight = 10;
			else
				maxHeight = maxHeight - parseInt(elem.css('padding-top'));
			elem.css('height', maxHeight+elem.find(".DWMasonryGallery_loadMoreHolder").outerHeight(true, true));
		}, function() {
			var maxHeight = 0;
			elem.find('.DWMasonryGallery_widget').each(function() {
				if ($(this).is(":visible")) {
					if ((parseInt($(this).css('top')) + parseInt($(this).outerHeight(true, true))) > maxHeight)
						maxHeight = parseInt($(this).css('top')) + parseInt($(this).outerHeight(true, true));
				}
			});
			if (maxHeight==0)
				maxHeight = 10;
			else
				maxHeight = maxHeight - parseInt(elem.css('padding-top'));
			elem.css('height', maxHeight+elem.find(".DWMasonryGallery_loadMoreHolder").outerHeight(true, true));
		});
		if (elem.parents('.jQueryTabs_container').length) {
			doTabsHeight(elem, options);
		}
	}
	
	function doTabsHeight(elem, options) {
		tabs_jQuery(window).trigger('resize');
		tabs_jQuery(".jQueryTabs_content").unbind('transitionend webkitTransitionEnd oTransitionEnd otransitionend MSTransitionEnd').on('transitionend webkitTransitionEnd oTransitionEnd otransitionend MSTransitionEnd', function() {
			if ($(this).find('#'+elem.attr('id')).length) {
				$(this).find('.DWMasonryGallery_container img').css('transition', 'none');
				options.oldWindowWidth = 0;
				$(window).trigger('resize.height'+elem.attr('id'));
				tabs_jQuery(window).trigger('resize');
				$(this).find('.DWMasonryGallery_container img').css('transition', '');
			}
		});
	}
	
	function doTouchLightbox(elem, name, options) {
		elem.find("a.grouped_elements").each(function() {
			var self = this;
			if (!$(self).data('hammer'))
			$(self).data('hammer', new Hammer($(self).get(0)));
			$(self).data('hammer').on('tap', function() {
				$(self).trigger('click');
			});
		});
		elem.find("a.grouped_elements").unbind('click').bind('click', function(e) { 
			e.preventDefault();
			
			try { 
				options.mobileBodyOverflow = $('body').css('overflow');
				$('body').css('overflow', 'hidden');
				var rel = $(this).attr('rel');
				var index = $(this).index('[rel="'+rel+'"][data-item="'+name+'"].grouped_elements');
				var overlayMobile = $('#overlay-mobile');
				if($('#mobile-tmp').length === 0){
					$('<div id="mobile-tmp" class="hide"></div>').appendTo('body');
				}
				var self = this;
				
				//$('head').append('<meta id ="extViewportMeta" name="viewport" content="width=device-width,  initial-scale=1.0">');

				if(overlayMobile.length === 0){
					mobileClose =  $('<div id="xtd-mobile-close-button"></div>').prependTo('body');
				   overlayMobile = $('<div id="overlay-mobile" class="hide"></div>').prependTo('body');
				 
				   overlayMobile.bind('touchstart touch drag',function(e){
						$('#mobile-tmp').empty();
						$('#mobile-gallery').carousel('destroy');
					   $('#mobile-gallery-wrap').remove();
						$(this).fadeOut();
						e.preventDefault();
					});
						
					$('#xtd-mobile-close-button').bind('click touchstart', function(ev){
						var here = this;
						ev.stopPropagation();
						ev.preventDefault();
						setTimeout(function() {
							$('body').css('overflow', options.mobileBodyOverflow);
							$('#mobile-tmp').empty();
							$('#mobile-gallery').carousel('destroy');
							$('#mobile-gallery-wrap').remove();
							$(here).add(overlayMobile).remove();
						}, 20);
						//$('head').append('<meta id ="extViewportMeta" name="viewport" content="width=device-width;  maximum-scale=1.0">');
					})
				}

			   
				
				elem.find('a[rel=' + rel + ']').clone().appendTo('#mobile-tmp');
				createMobileMarkup();
				createCarousel(options, name);
				var gallery = $('#mobile-gallery');
			   
				initCarousel(gallery, index);


				if(window.galleryGrid.browser.name != 'msie') { 

					var zoom = (window.screen.availHeight / window.innerHeight);
					var transform = "scale("+(1)+","+(1)+")";
					gallery[0].style.transform = transform;
					gallery[0].style.oTransform = transform;
					gallery[0].style.msTransform = transform;
					gallery[0].style.mozTransform = transform;
					gallery[0].style.webkitTransform = transform;

					  var hammertime = Hammer(gallery[0], {
						transform_always_block: true,
						transform_min_scale: 1,
						drag_block_horizontal: true,
						drag_block_vertical: true,
						drag_min_distance: 0
					});

					var posX=0, posY=0,
						scale=1, last_scale,
						rotation= 1, last_rotation;
					 hammertime.on('touch drag transform', function(ev) {
						var rect = $('.m-active img');
						
						var transform;
						 switch(ev.type) {
							case 'touch':
								rect.data('last_scale', scale);
								rect.data('last_rotation', rotation);
							   
								ev.stopImmediatePropagation();
								return;
								break;
							case 'transform':
								var rect = $('.m-active img');
								var last_scale = rect.data('last_scale') ? rect.data('last_scale') : 1;
								var last_rotation = rect.data('last_scale') ? rect.data('last_scale') : 1;
								rotation = last_rotation + ev.gesture.rotation;
								scale = Math.max(1, Math.min(last_scale * ev.gesture.scale, 10));
								ev.stopImmediatePropagation();

								transform = "scale("+scale+","+scale+") ";// +  "rotate("+rotation+"deg) ";
							
								break;
						}

						rect[0].style.transform = transform;
						rect[0].style.oTransform = transform;
						rect[0].style.msTransform = transform;
						rect[0].style.mozTransform = transform;
						rect[0].style.webkitTransform = transform;

					 });
				}


			 centerMobileGallery(gallery, name, options);
			 } catch(e) { 
				alert(e);
			 }

		
						});
	}
	
	function makeTopVisible() {
		if (!gallery_jQuery('.gallery-banner-trial').length && !window.project) {
			 var newTop = $('<div />');
			 var bgColor = (Browser.IsIe() && Browser.Version() <= 9) ? "#EAA249" : "rgba(183, 207, 35, 0.82)";
			 newTop.css({
				'display' : 'inline-block',
				'max-height' : '300px',
				'width' : '100%',
				'background-color' : bgColor,
				'padding': '15px 0px',
				'position': 'fixed',
				'top': '0px',
				'left': '0px',
				'z-index': '2147483583'
			 });
			 var textholder = $('<div></div>').css({
				'text-align' : 'center',
				'font-size' : '16px',
				'width' : '100%',
				'float' : 'left',
				'position' : 'relative',
				'display' : 'block',
				'color' : '#fff',
				'vertical-align' : 'middle',
				'font-family' : 'Tahoma, sans-serif'
			}).html(Base64.decode("R2FsbGVyeSBjcmVhdGVkIHVzaW5nIERXIE1hc29ucnkgR2FsbGVyeSAtIGZyZWUgdHJpYWwgdmVyc2lvbi4gUmVhZCBtb3JlIDxhIGhyZWY9Imh0dHA6Ly93d3cuZXh0ZW5kc3R1ZGlvLmNvbS8iPmh0dHA6Ly93d3cuZXh0ZW5kc3R1ZGlvLmNvbS88L2E+"));
			 newTop.append(textholder);

			 var closeButton = $('<div></div>')
			 .css({
				"background-position" : "center center",
				"background-repeat" : "no-repeat",
				"background-image" : "url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABMAAAATCAYAAAByUDbMAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyZpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNS1jMDIxIDc5LjE1NTc3MiwgMjAxNC8wMS8xMy0xOTo0NDowMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTQgKFdpbmRvd3MpIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjJEQUNFM0Y2MjMxQTExRTQ5RjBFOTZDMTFGMTUzNERFIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjJEQUNFM0Y3MjMxQTExRTQ5RjBFOTZDMTFGMTUzNERFIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6MkRBQ0UzRjQyMzFBMTFFNDlGMEU5NkMxMUYxNTM0REUiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6MkRBQ0UzRjUyMzFBMTFFNDlGMEU5NkMxMUYxNTM0REUiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz5ceTilAAAA6klEQVR42uyUMQqDQBRExxCx9ggW2uhxPIGNXsZaG60ULDyOnYVHsBZWEmbRBRNFhW0C2WaYv/D4O/+r4fs+dJ3noi8NLOMBjefHYFVVoWka2La9qdOzXtf1dZhpmgiCAEVRKCCVnnXeX4YlSYK+7+F5ngQ4jiOVnvU4jvfHuezZ12qwk7Is4boupmmCZVkSFEURxnHcZR3CeNhR27YSRGAYhhiG4f6esbM0TRWISv85lNPM1rDXjNjRmiGffgTchWVZpkDMiE+j0jPDPM+vw+Z5Rtd1m7Cp9KwLIe5N8/+hn/4cDR2wtwADAM7VaD9mmmFzAAAAAElFTkSuQmCC')",
				"width" : "19px",
				"height" : "20px",
				"display" : "block",
				"position" : "absolute",
				"right" : "20px",
				"cursor" : "pointer"
			 }).click(function() {
				newTop.hide();
			 });
			newTop.addClass('gallery-banner-trial');
			newTop.append(closeButton);

			gallery_jQuery('body').prepend(newTop);
		 }
	}
	
	var createMobileMarkup = function(){
		if (!$("#mobile-gallery").length) {
			var markup =
				  $('<div id="mobile-gallery">' +
						'<div class="m-carousel m-fluid m-carousel-photos">' +
							'<div id="m-carousel-inner" class="m-carousel-inner">' +
							'</div>' +
						'</div>' +
				  '</div>');
			markup.appendTo('body');
		}

    };
    var createCarousel = function(options, name){
        var items = $('#mobile-tmp a');
        $(items.get()).each(function(){
            var index = $(this).index() + 1;
            var newHref = $(this).attr('href');
			if ($(window).width()<= parseInt(options.devices.mobile.width)) {
				newHref = newHref.replace('1920', '640').replace('1280', '640');
			} else {
				newHref = newHref.replace('1920', '1280').replace('640', '1280');
			}
            var itemCaption = $(this).children('img').attr('data-name');
            var mitem = $('<div class="m-item"></div>');
			var toAppend = "";
			if ($(window).width()>parseInt(options.devices.mobile.width)) {
				if (options.lightboxTitle && options.lightboxDescription)
					toAppend = "<p class='"+name+"_lightboxTitle'>"+options.imagesInfo[itemCaption].title+"</p><p class='"+name+"_lightboxDescription' style='margin-top:0; margin-bottom:0;'>"+options.imagesInfo[itemCaption].description+"</p>";
				else if (options.lightboxTitle) {
					toAppend = "<p class='"+name+"_lightboxTitle' style='margin:0;'>"+options.imagesInfo[itemCaption].title+"</p>";
				} else if (options.lightboxDescription) {
					toAppend = "<p class='"+name+"_lightboxDescription' style='margin:0;'>"+options.imagesInfo[itemCaption].description+"</p>";
				}
			}
            $('<img />')
                    .attr('src',newHref)
                    .appendTo(mitem)
                    .parent().append(toAppend);
            $('#overlay-mobile').fadeIn(0);
            mitem.appendTo(".m-carousel-inner");


        });
    };



	function initCarousel(e, index){
       
        $(e).carousel({
            dragRadius: 200
            , moveRadius: 200
            , classPrefix: undefined
            , classNames: {
                outer: "carousel"
                , inner: "carousel-inner"
                , item: "item"
                , touch: "has-touch"
                , dragging: "dragging"
                , active: "active"
            }
        })
		if (index!=0) {
			$(e).carousel('move', [index+1, {disableAnimation:true}]);
		}
    }

     var centerMobileGalleryVertically = function(gallery, name, options){
    	var zoom = (window.screen.availHeight / window.innerHeight);
     	var zoomW = (window.screen.availWidth / window.innerWidth);
     	
         var self = $(this);
         var galleryImage = self.find('img');

         gallery.find('img').each(function(){
             $(this).unbind('load').load(function(){
             	//WIP -  set natural height & width on load as data attributes for correct centering 
				 if (options) {
					 if ($(this).height()>window.innerHeight*0.8) {
						$(this).css('max-height', Math.round(window.innerHeight*0.8))
					}
					if ($(this).width()>window.innerWidth*0.8) {
						$(this).css('max-width', Math.round(window.innerWidth*0.8))
					}
					 if ($(window).width()>parseInt(options.devices.mobile.width)) {
						if (options.lightboxTitle && options.lightboxDescription) {
							$(this).height($(this).height() - $(this).siblings('.'+name+"_lightboxDescription").outerHeight(true, true) - $(this).siblings('.'+name+"_lightboxTitle").outerHeight(true, true));
							$(this).siblings('.'+name+"_lightboxTitle").width($(this).width());
							$(this).siblings('.'+name+"_lightboxDescription").width($(this).width());
						} else if (options.lightboxTitle) {
							$(this).height($(this).height() - $(this).siblings('.'+name+"_lightboxTitle").outerHeight(true, true));
							$(this).siblings('.'+name+"_lightboxTitle").width($(this).width());
						} else if (options.lightboxDescription) {
							$(this).height($(this).height() - $(this).siblings('.'+name+"_lightboxDescription").outerHeight(true, true));
							$(this).siblings('.'+name+"_lightboxDescription").width($(this).width());
						}
					 }
				 } else {
					 $(this).removeAttr('style');
					 if ($(this).height()>window.innerHeight*0.8) {
						$(this).css('max-height', Math.round(window.innerHeight*0.8))
					}
					if ($(this).width()>window.innerWidth*0.8) {
						$(this).css('max-width', Math.round(window.innerWidth*0.8))
					}
					 if ($(this).siblings('p').length==2) {
						$(this).height($(this).height() - $(this).siblings("p").first().outerHeight(true, true) - $(this).siblings("p").last().outerHeight(true, true));
					 } else if ($(this).siblings('p').length==1) {
						 $(this).height($(this).height() - $(this).siblings("p").outerHeight(true, true));
					 }
					 if ($(this).siblings('p').length) {
						$(this).siblings('p').width($(this).width());
					}
				 }
				 $(this).parent().attr({
                     "data-image-width":$(this)[0].naturalWidth,
                     "data-image-height":$(this)[0].naturalHeight
                 })
                 .css({
                     'margin-top' : Math.abs(Math.round(parseInt(parseInt(window.innerHeight) - $(this).parent().height())*0.5))
                 });
			 });
         });
		 
		 gallery.css({
             'height' : Math.abs(Math.round(parseInt(window.innerHeight)))
         });
         gallery.css({
             'width' : Math.abs(Math.round(parseInt(window.innerWidth)))
         });

         gallery.find('.m-item').each(function(){
         	var self = this;
            $(this).css({
                'margin-top' : Math.abs(Math.round(parseInt(parseInt(window.innerHeight) - $(this).height())*0.5))
            })
         });
         //alert($(window).width()+ " .. " + window.innerWidth);
         
    };

     var centerMobileGallery = function(gallery, name, options){
    	// if(window.galleryGrid.browser.name != 'msie') { 
    	 	centerMobileGalleryVertically(gallery, name, options);
    	 	return;
    	// }
    	var zoom = (window.screen.availHeight / window.innerHeight);
     	var zoomW = (window.screen.availWidth / window.innerWidth);
     	
          var self = $(this);
         var galleryImage = self.find('img');
	 
         gallery.find('img').each(function(){
             $(this).load(function(){
             	//WIP -  set natural height & width on load as data attributes for correct centering 
                 $(this).parent().attr({
                     "data-image-width":$(this)[0].naturalWidth,
                     "data-image-height":$(this)[0].naturalHeight
                 })
                 .css({
                     'margin-top' : Math.abs(Math.round(parseInt($(window).height() - $(this).height())*0.5)) / zoom
                 });
            

             });
         });
		 
		 gallery.find('.m-item').each(function(){
			$(this).css({
				'margin-top' : Math.abs(Math.round(parseInt($(window).height() - $(this).height())*0.5) / zoom)
			})
		
		});
		 gallery.css({
			 'height' : Math.abs(Math.round(parseInt($(window).height())))
		 });
		 gallery.css({
			 'width' : Math.abs(Math.round(parseInt($(window).width() *0.9)))
		 });
		 gallery.css({
			 'padding-left' :Math.abs(Math.round(parseInt($(window).width() - $(gallery).width()) / 2) / zoom)
		 });
    };

     var preventScroll = function(){
        var body = $('body');
        if(body.hasClass('no-scroll') !== true){
            body.addClass('no-scroll')
        }
    };

    function isFunction(arg) {
    	if(arg && typeof arg === 'function') {
			return true;
		}
		return false;
    }


    var fixScroll = function(){
        var body = gallery_jQuery('body');
        var fixer = 'xtd-body-fix';
            if(!body.hasClass(fixer)){
                body.addClass(fixer);
            }
    };
    var fixPosition = function(){
        var elem = gallery_jQuery('#g-fancybox-wrap');
        var top = Math.round(parseInt((gallery_jQuery(window).height() - elem.height())/2));
        var left = Math.round(parseInt((gallery_jQuery(window).width() - elem.width())/2));
    };

    var addPIE = function(){
        gallery_jQuery("body").addClass('xtd-body-fix');
        gallery_jQuery(".fb-outer-wrapper").find('div').each(function(){
            if (window.PIE) PIE.attach(this)
        })
    };

    var fixPerspective = function(){
        var magicNumber = 1300;
        var reference = 1080;
        try{
        	var perspectiveValue = Math.round(($(document).height() / reference) * magicNumber);
            if(gallery_jQuery(document).height() > gallery_jQuery(window).height()){
                gallery_jQuery('##g-fancybox-xtdLightbox-effects').css({
                    '-webkit-perspective' : perspectiveValue,
                    '-moz-perspective' : perspectiveValue,
                    'perspective' : perspectiveValue

                });
            }
        }
        catch (e){
            //alert(e)
        }
    };
	
	/** device detection */
	var DeviceDetect;

	if (!DeviceDetect) {
		DeviceDetect = new Object;
	}

	DeviceDetect.UserAgent = navigator.userAgent.toLowerCase();

	DeviceDetect.isMobile = function (viewportWidth, maxWidth) {
		var deviceMatch = (/iphone|ipod|android|blackberry|mini|windows\sce|windows\sphone|iemobile|palm|webos|series60|symbianos|meego/i.test(DeviceDetect.UserAgent));
		var sizeMatch;
		if(window.matchMedia) { 
			sizeMatch = window.matchMedia("(max-width:" + (maxWidth) + "px)").matches;
		} else { 
			sizeMatch = viewportWidth < maxWidth;
		}
		return deviceMatch || sizeMatch;
	}

	/*
	 *	IsTablet() - Return true if this is a tablet device.
	 */
	DeviceDetect.isTablet = function (viewportWidth, minWidth, maxWidth) {
		var UA = DeviceDetect.UserAgent;
		var is_touch_device = 'ontouchstart' in document.documentElement;
		
		var deviceMatch = (/ipad|Win64|tablet/i.test(UA));
		var sizeMatch;

		if(window.matchMedia) { 
			sizeMatch = window.matchMedia("(max-width:" + (maxWidth) + "px) and (min-width:" + (minWidth+1) + "px)").matches;
		} else { 
			sizeMatch = viewportWidth < maxWidth && viewportWidth >= minWidth;
		}
		return is_touch_device && (deviceMatch || sizeMatch);
	}

	var correctedViewportW = (function (win, docElem) {

	    var mM = win['matchMedia'] || win['msMatchMedia']
	      , client = docElem['clientWidth']
	      , inner = win['innerWidth']

	    return mM && client < inner && true === mM('(min-width:' + inner + 'px)')['matches']
	        ? function () { return win['innerWidth'] }
	        : function () { return docElem['clientWidth'] }

	}(window, document.documentElement));


	var viewportWidth = correctedViewportW();
	var mobileCheck = DeviceDetect.isMobile(viewportWidth, 480)
	var isMobileDevice = mobileCheck;
	var tabletCheck = DeviceDetect.isTablet(viewportWidth, 480, 750);
	var isTabletDevice = tabletCheck || mobileCheck;
	window.galleryGrid = {};
	window.galleryGrid.browser = getBrowser();
	
	function getBrowser() {
		// jquery code//
		var ua = navigator.userAgent.toLowerCase();
		var match = /(chrome)[ \/]([\w.]+)/.exec( ua ) ||
			/(webkit)[ \/]([\w.]+)/.exec( ua ) ||
			/(opera)(?:.*version|)[ \/]([\w.]+)/.exec( ua ) ||
			/(msie) ([\w.]+)/.exec( ua ) ||
			ua.indexOf("compatible") < 0 && /(mozilla)(?:.*? rv:([\w.]+)|)/.exec( ua ) ||
			[];
		
		var ver = match[ 2 ] || "0";
		var fi = ver.indexOf('.');
		var fi2 = ver.indexOf('.', fi);
		if (fi2 != -1) {
			ver = parseFloat(ver.substring(0, fi2));
		}
		return {
			name: match[ 1 ] || "",
			version: ver
		};
	}
	
	var Browser = {
		IsIe: function () {
			return navigator.appVersion.indexOf("MSIE") != -1;
		},
		Navigator: navigator.appVersion,
		Version: function() {
			var version = 999; // we assume a sane browser
			if (navigator.appVersion.indexOf("MSIE") != -1)
				// bah, IE again, lets downgrade version number
				version = parseFloat(navigator.appVersion.split("MSIE")[1]);
			return version;
		}
	};

	var Base64 = {

		// private property
		_keyStr : "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",

		// public method for encoding
		encode : function (input) {
			var output = "";
			var chr1, chr2, chr3, enc1, enc2, enc3, enc4;
			var i = 0;

			input = Base64._utf8_encode(input);

			while (i < input.length) {

				chr1 = input.charCodeAt(i++);
				chr2 = input.charCodeAt(i++);
				chr3 = input.charCodeAt(i++);

				enc1 = chr1 >> 2;
				enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
				enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
				enc4 = chr3 & 63;

				if (isNaN(chr2)) {
					enc3 = enc4 = 64;
				} else if (isNaN(chr3)) {
					enc4 = 64;
				}

				output = output +
				this._keyStr.charAt(enc1) + this._keyStr.charAt(enc2) +
				this._keyStr.charAt(enc3) + this._keyStr.charAt(enc4);

			}

			return output;
		},

		// public method for decoding
		decode : function (input) {
			var output = "";
			var chr1, chr2, chr3;
			var enc1, enc2, enc3, enc4;
			var i = 0;

			input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");

			while (i < input.length) {

				enc1 = this._keyStr.indexOf(input.charAt(i++));
				enc2 = this._keyStr.indexOf(input.charAt(i++));
				enc3 = this._keyStr.indexOf(input.charAt(i++));
				enc4 = this._keyStr.indexOf(input.charAt(i++));

				chr1 = (enc1 << 2) | (enc2 >> 4);
				chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
				chr3 = ((enc3 & 3) << 6) | enc4;

				output = output + String.fromCharCode(chr1);

				if (enc3 != 64) {
					output = output + String.fromCharCode(chr2);
				}
				if (enc4 != 64) {
					output = output + String.fromCharCode(chr3);
				}

			}

			output = Base64._utf8_decode(output);

			return output;

		},

		// private method for UTF-8 encoding
		_utf8_encode : function (string) {
			string = string.replace(/\r\n/g,"\n");
			var utftext = "";

			for (var n = 0; n < string.length; n++) {

				var c = string.charCodeAt(n);

				if (c < 128) {
					utftext += String.fromCharCode(c);
				}
				else if((c > 127) && (c < 2048)) {
					utftext += String.fromCharCode((c >> 6) | 192);
					utftext += String.fromCharCode((c & 63) | 128);
				}
				else {
					utftext += String.fromCharCode((c >> 12) | 224);
					utftext += String.fromCharCode(((c >> 6) & 63) | 128);
					utftext += String.fromCharCode((c & 63) | 128);
				}

			}

			return utftext;
		},

		// private method for UTF-8 decoding
		_utf8_decode : function (utftext) {
			var string = "";
			var i = 0;
			var c = c1 = c2 = 0;

			while ( i < utftext.length ) {

				c = utftext.charCodeAt(i);

				if (c < 128) {
					string += String.fromCharCode(c);
					i++;
				}
				else if((c > 191) && (c < 224)) {
					c2 = utftext.charCodeAt(i+1);
					string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
					i += 2;
				}
				else {
					c2 = utftext.charCodeAt(i+1);
					c3 = utftext.charCodeAt(i+2);
					string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
					i += 3;
				}

			}

			return string;
		}
	}
	
	function is_touch_device() {
	  return 'ontouchstart' in window // works on most browsers 
		  || 'onmsgesturechange' in window; // works on ie10
	};
	
	function endsWith(str, suffix) {
		return str.indexOf(suffix, str.length - suffix.length) !== -1;
	}
	
	/*!
 * Masonry PACKAGED v3.3.0
 * Cascading grid layout library
 * http://masonry.desandro.com
 * MIT License
 * by David DeSandro
 */

( function( window ) {



// -------------------------- utils -------------------------- //

var slice = Array.prototype.slice;

function noop() {}

// -------------------------- definition -------------------------- //

function defineBridget( $ ) {

// bail if no jQuery
if ( !$ ) {
  return;
}

// -------------------------- addOptionMethod -------------------------- //

/**
 * adds option method -> $().plugin('option', {...})
 * @param {Function} PluginClass - constructor class
 */
function addOptionMethod( PluginClass ) {
  // don't overwrite original option method
  if ( PluginClass.prototype.option ) {
    return;
  }

  // option setter
  PluginClass.prototype.option = function( opts ) {
    // bail out if not an object
    if ( !$.isPlainObject( opts ) ){
      return;
    }
    this.options = $.extend( true, this.options, opts );
  };
}

// -------------------------- plugin bridge -------------------------- //

// helper function for logging errors
// $.error breaks jQuery chaining
var logError = typeof console === 'undefined' ? noop :
  function( message ) {
    console.error( message );
  };

/**
 * jQuery plugin bridge, access methods like $elem.plugin('method')
 * @param {String} namespace - plugin name
 * @param {Function} PluginClass - constructor class
 */
function bridge( namespace, PluginClass ) {
  // add to jQuery fn namespace
  $.fn[ namespace ] = function( options ) {
    if ( typeof options === 'string' ) {
      // call plugin method when first argument is a string
      // get arguments for method
      var args = slice.call( arguments, 1 );

      for ( var i=0, len = this.length; i < len; i++ ) {
        var elem = this[i];
        var instance = $.data( elem, namespace );
        if ( !instance ) {
          logError( "cannot call methods on " + namespace + " prior to initialization; " +
            "attempted to call '" + options + "'" );
          continue;
        }
        if ( !$.isFunction( instance[options] ) || options.charAt(0) === '_' ) {
          logError( "no such method '" + options + "' for " + namespace + " instance" );
          continue;
        }

        // trigger method with arguments
        var returnValue = instance[ options ].apply( instance, args );

        // break look and return first value if provided
        if ( returnValue !== undefined ) {
          return returnValue;
        }
      }
      // return this if no return value
      return this;
    } else {
      return this.each( function() {
        var instance = $.data( this, namespace );
        if ( instance ) {
          // apply options & init
          instance.option( options );
          instance._init();
        } else {
          // initialize new instance
          instance = new PluginClass( this, options );
          $.data( this, namespace, instance );
        }
      });
    }
  };

}

// -------------------------- bridget -------------------------- //

/**
 * converts a Prototypical class into a proper jQuery plugin
 *   the class must have a ._init method
 * @param {String} namespace - plugin name, used in $().pluginName
 * @param {Function} PluginClass - constructor class
 */
$.bridget = function( namespace, PluginClass ) {
  addOptionMethod( PluginClass );
  bridge( namespace, PluginClass );
};

return $.bridget;

}

// transport
if ( typeof define === 'function' && define.amd ) {
  // AMD
  define( 'jquery-bridget/jquery.bridget',[ 'jquery' ], defineBridget );
} else if ( typeof exports === 'object' ) {
  defineBridget( require('jquery') );
} else {
  // get jquery from browser global
  defineBridget( window.gallery_jQuery );
}

})( window );

/*!
 * eventie v1.0.6
 * event binding helper
 *   eventie.bind( elem, 'click', myFn )
 *   eventie.unbind( elem, 'click', myFn )
 * MIT license
 */

/*jshint browser: true, undef: true, unused: true */
/*global define: false, module: false */

( function( window ) {



var docElem = document.documentElement;

var bind = function() {};

function getIEEvent( obj ) {
  var event = window.event;
  // add event.target
  event.target = event.target || event.srcElement || obj;
  return event;
}

if ( docElem.addEventListener ) {
  bind = function( obj, type, fn ) {
    obj.addEventListener( type, fn, false );
  };
} else if ( docElem.attachEvent ) {
  bind = function( obj, type, fn ) {
    obj[ type + fn ] = fn.handleEvent ?
      function() {
        var event = getIEEvent( obj );
        fn.handleEvent.call( fn, event );
      } :
      function() {
        var event = getIEEvent( obj );
        fn.call( obj, event );
      };
    obj.attachEvent( "on" + type, obj[ type + fn ] );
  };
}

var unbind = function() {};

if ( docElem.removeEventListener ) {
  unbind = function( obj, type, fn ) {
    obj.removeEventListener( type, fn, false );
  };
} else if ( docElem.detachEvent ) {
  unbind = function( obj, type, fn ) {
    obj.detachEvent( "on" + type, obj[ type + fn ] );
    try {
      delete obj[ type + fn ];
    } catch ( err ) {
      // can't delete window object properties
      obj[ type + fn ] = undefined;
    }
  };
}

var eventie = {
  bind: bind,
  unbind: unbind
};

// ----- module definition ----- //

if ( typeof define === 'function' && define.amd ) {
  // AMD
  define( 'eventie/eventie',eventie );
} else if ( typeof exports === 'object' ) {
  // CommonJS
  module.exports = eventie;
} else {
  // browser global
  window.eventie = eventie;
}

})( window );

/*!
 * EventEmitter v4.2.11 - git.io/ee
 * Unlicense - http://unlicense.org/
 * Oliver Caldwell - http://oli.me.uk/
 * @preserve
 */

;(function () {
    

    /**
     * Class for managing events.
     * Can be extended to provide event functionality in other classes.
     *
     * @class EventEmitter Manages event registering and emitting.
     */
    function EventEmitter() {}

    // Shortcuts to improve speed and size
    var proto = EventEmitter.prototype;
    var exports = this;
    var originalGlobalValue = exports.EventEmitter;

    /**
     * Finds the index of the listener for the event in its storage array.
     *
     * @param {Function[]} listeners Array of listeners to search through.
     * @param {Function} listener Method to look for.
     * @return {Number} Index of the specified listener, -1 if not found
     * @api private
     */
    function indexOfListener(listeners, listener) {
        var i = listeners.length;
        while (i--) {
            if (listeners[i].listener === listener) {
                return i;
            }
        }

        return -1;
    }

    /**
     * Alias a method while keeping the context correct, to allow for overwriting of target method.
     *
     * @param {String} name The name of the target method.
     * @return {Function} The aliased method
     * @api private
     */
    function alias(name) {
        return function aliasClosure() {
            return this[name].apply(this, arguments);
        };
    }

    /**
     * Returns the listener array for the specified event.
     * Will initialise the event object and listener arrays if required.
     * Will return an object if you use a regex search. The object contains keys for each matched event. So /ba[rz]/ might return an object containing bar and baz. But only if you have either defined them with defineEvent or added some listeners to them.
     * Each property in the object response is an array of listener functions.
     *
     * @param {String|RegExp} evt Name of the event to return the listeners from.
     * @return {Function[]|Object} All listener functions for the event.
     */
    proto.getListeners = function getListeners(evt) {
        var events = this._getEvents();
        var response;
        var key;

        // Return a concatenated array of all matching events if
        // the selector is a regular expression.
        if (evt instanceof RegExp) {
            response = {};
            for (key in events) {
                if (events.hasOwnProperty(key) && evt.test(key)) {
                    response[key] = events[key];
                }
            }
        }
        else {
            response = events[evt] || (events[evt] = []);
        }

        return response;
    };

    /**
     * Takes a list of listener objects and flattens it into a list of listener functions.
     *
     * @param {Object[]} listeners Raw listener objects.
     * @return {Function[]} Just the listener functions.
     */
    proto.flattenListeners = function flattenListeners(listeners) {
        var flatListeners = [];
        var i;

        for (i = 0; i < listeners.length; i += 1) {
            flatListeners.push(listeners[i].listener);
        }

        return flatListeners;
    };

    /**
     * Fetches the requested listeners via getListeners but will always return the results inside an object. This is mainly for internal use but others may find it useful.
     *
     * @param {String|RegExp} evt Name of the event to return the listeners from.
     * @return {Object} All listener functions for an event in an object.
     */
    proto.getListenersAsObject = function getListenersAsObject(evt) {
        var listeners = this.getListeners(evt);
        var response;

        if (listeners instanceof Array) {
            response = {};
            response[evt] = listeners;
        }

        return response || listeners;
    };

    /**
     * Adds a listener function to the specified event.
     * The listener will not be added if it is a duplicate.
     * If the listener returns true then it will be removed after it is called.
     * If you pass a regular expression as the event name then the listener will be added to all events that match it.
     *
     * @param {String|RegExp} evt Name of the event to attach the listener to.
     * @param {Function} listener Method to be called when the event is emitted. If the function returns true then it will be removed after calling.
     * @return {Object} Current instance of EventEmitter for chaining.
     */
    proto.addListener = function addListener(evt, listener) {
        var listeners = this.getListenersAsObject(evt);
        var listenerIsWrapped = typeof listener === 'object';
        var key;

        for (key in listeners) {
            if (listeners.hasOwnProperty(key) && indexOfListener(listeners[key], listener) === -1) {
                listeners[key].push(listenerIsWrapped ? listener : {
                    listener: listener,
                    once: false
                });
            }
        }

        return this;
    };

    /**
     * Alias of addListener
     */
    proto.on = alias('addListener');

    /**
     * Semi-alias of addListener. It will add a listener that will be
     * automatically removed after its first execution.
     *
     * @param {String|RegExp} evt Name of the event to attach the listener to.
     * @param {Function} listener Method to be called when the event is emitted. If the function returns true then it will be removed after calling.
     * @return {Object} Current instance of EventEmitter for chaining.
     */
    proto.addOnceListener = function addOnceListener(evt, listener) {
        return this.addListener(evt, {
            listener: listener,
            once: true
        });
    };

    /**
     * Alias of addOnceListener.
     */
    proto.once = alias('addOnceListener');

    /**
     * Defines an event name. This is required if you want to use a regex to add a listener to multiple events at once. If you don't do this then how do you expect it to know what event to add to? Should it just add to every possible match for a regex? No. That is scary and bad.
     * You need to tell it what event names should be matched by a regex.
     *
     * @param {String} evt Name of the event to create.
     * @return {Object} Current instance of EventEmitter for chaining.
     */
    proto.defineEvent = function defineEvent(evt) {
        this.getListeners(evt);
        return this;
    };

    /**
     * Uses defineEvent to define multiple events.
     *
     * @param {String[]} evts An array of event names to define.
     * @return {Object} Current instance of EventEmitter for chaining.
     */
    proto.defineEvents = function defineEvents(evts) {
        for (var i = 0; i < evts.length; i += 1) {
            this.defineEvent(evts[i]);
        }
        return this;
    };

    /**
     * Removes a listener function from the specified event.
     * When passed a regular expression as the event name, it will remove the listener from all events that match it.
     *
     * @param {String|RegExp} evt Name of the event to remove the listener from.
     * @param {Function} listener Method to remove from the event.
     * @return {Object} Current instance of EventEmitter for chaining.
     */
    proto.removeListener = function removeListener(evt, listener) {
        var listeners = this.getListenersAsObject(evt);
        var index;
        var key;

        for (key in listeners) {
            if (listeners.hasOwnProperty(key)) {
                index = indexOfListener(listeners[key], listener);

                if (index !== -1) {
                    listeners[key].splice(index, 1);
                }
            }
        }

        return this;
    };

    /**
     * Alias of removeListener
     */
    proto.off = alias('removeListener');

    /**
     * Adds listeners in bulk using the manipulateListeners method.
     * If you pass an object as the second argument you can add to multiple events at once. The object should contain key value pairs of events and listeners or listener arrays. You can also pass it an event name and an array of listeners to be added.
     * You can also pass it a regular expression to add the array of listeners to all events that match it.
     * Yeah, this function does quite a bit. That's probably a bad thing.
     *
     * @param {String|Object|RegExp} evt An event name if you will pass an array of listeners next. An object if you wish to add to multiple events at once.
     * @param {Function[]} [listeners] An optional array of listener functions to add.
     * @return {Object} Current instance of EventEmitter for chaining.
     */
    proto.addListeners = function addListeners(evt, listeners) {
        // Pass through to manipulateListeners
        return this.manipulateListeners(false, evt, listeners);
    };

    /**
     * Removes listeners in bulk using the manipulateListeners method.
     * If you pass an object as the second argument you can remove from multiple events at once. The object should contain key value pairs of events and listeners or listener arrays.
     * You can also pass it an event name and an array of listeners to be removed.
     * You can also pass it a regular expression to remove the listeners from all events that match it.
     *
     * @param {String|Object|RegExp} evt An event name if you will pass an array of listeners next. An object if you wish to remove from multiple events at once.
     * @param {Function[]} [listeners] An optional array of listener functions to remove.
     * @return {Object} Current instance of EventEmitter for chaining.
     */
    proto.removeListeners = function removeListeners(evt, listeners) {
        // Pass through to manipulateListeners
        return this.manipulateListeners(true, evt, listeners);
    };

    /**
     * Edits listeners in bulk. The addListeners and removeListeners methods both use this to do their job. You should really use those instead, this is a little lower level.
     * The first argument will determine if the listeners are removed (true) or added (false).
     * If you pass an object as the second argument you can add/remove from multiple events at once. The object should contain key value pairs of events and listeners or listener arrays.
     * You can also pass it an event name and an array of listeners to be added/removed.
     * You can also pass it a regular expression to manipulate the listeners of all events that match it.
     *
     * @param {Boolean} remove True if you want to remove listeners, false if you want to add.
     * @param {String|Object|RegExp} evt An event name if you will pass an array of listeners next. An object if you wish to add/remove from multiple events at once.
     * @param {Function[]} [listeners] An optional array of listener functions to add/remove.
     * @return {Object} Current instance of EventEmitter for chaining.
     */
    proto.manipulateListeners = function manipulateListeners(remove, evt, listeners) {
        var i;
        var value;
        var single = remove ? this.removeListener : this.addListener;
        var multiple = remove ? this.removeListeners : this.addListeners;

        // If evt is an object then pass each of its properties to this method
        if (typeof evt === 'object' && !(evt instanceof RegExp)) {
            for (i in evt) {
                if (evt.hasOwnProperty(i) && (value = evt[i])) {
                    // Pass the single listener straight through to the singular method
                    if (typeof value === 'function') {
                        single.call(this, i, value);
                    }
                    else {
                        // Otherwise pass back to the multiple function
                        multiple.call(this, i, value);
                    }
                }
            }
        }
        else {
            // So evt must be a string
            // And listeners must be an array of listeners
            // Loop over it and pass each one to the multiple method
            i = listeners.length;
            while (i--) {
                single.call(this, evt, listeners[i]);
            }
        }

        return this;
    };

    /**
     * Removes all listeners from a specified event.
     * If you do not specify an event then all listeners will be removed.
     * That means every event will be emptied.
     * You can also pass a regex to remove all events that match it.
     *
     * @param {String|RegExp} [evt] Optional name of the event to remove all listeners for. Will remove from every event if not passed.
     * @return {Object} Current instance of EventEmitter for chaining.
     */
    proto.removeEvent = function removeEvent(evt) {
        var type = typeof evt;
        var events = this._getEvents();
        var key;

        // Remove different things depending on the state of evt
        if (type === 'string') {
            // Remove all listeners for the specified event
            delete events[evt];
        }
        else if (evt instanceof RegExp) {
            // Remove all events matching the regex.
            for (key in events) {
                if (events.hasOwnProperty(key) && evt.test(key)) {
                    delete events[key];
                }
            }
        }
        else {
            // Remove all listeners in all events
            delete this._events;
        }

        return this;
    };

    /**
     * Alias of removeEvent.
     *
     * Added to mirror the node API.
     */
    proto.removeAllListeners = alias('removeEvent');

    /**
     * Emits an event of your choice.
     * When emitted, every listener attached to that event will be executed.
     * If you pass the optional argument array then those arguments will be passed to every listener upon execution.
     * Because it uses `apply`, your array of arguments will be passed as if you wrote them out separately.
     * So they will not arrive within the array on the other side, they will be separate.
     * You can also pass a regular expression to emit to all events that match it.
     *
     * @param {String|RegExp} evt Name of the event to emit and execute listeners for.
     * @param {Array} [args] Optional array of arguments to be passed to each listener.
     * @return {Object} Current instance of EventEmitter for chaining.
     */
    proto.emitEvent = function emitEvent(evt, args) {
        var listeners = this.getListenersAsObject(evt);
        var listener;
        var i;
        var key;
        var response;

        for (key in listeners) {
            if (listeners.hasOwnProperty(key)) {
                i = listeners[key].length;

                while (i--) {
                    // If the listener returns true then it shall be removed from the event
                    // The function is executed either with a basic call or an apply if there is an args array
                    listener = listeners[key][i];

                    if (listener.once === true) {
                        this.removeListener(evt, listener.listener);
                    }

                    response = listener.listener.apply(this, args || []);

                    if (response === this._getOnceReturnValue()) {
                        this.removeListener(evt, listener.listener);
                    }
                }
            }
        }

        return this;
    };

    /**
     * Alias of emitEvent
     */
    proto.trigger = alias('emitEvent');

    /**
     * Subtly different from emitEvent in that it will pass its arguments on to the listeners, as opposed to taking a single array of arguments to pass on.
     * As with emitEvent, you can pass a regex in place of the event name to emit to all events that match it.
     *
     * @param {String|RegExp} evt Name of the event to emit and execute listeners for.
     * @param {...*} Optional additional arguments to be passed to each listener.
     * @return {Object} Current instance of EventEmitter for chaining.
     */
    proto.emit = function emit(evt) {
        var args = Array.prototype.slice.call(arguments, 1);
        return this.emitEvent(evt, args);
    };

    /**
     * Sets the current value to check against when executing listeners. If a
     * listeners return value matches the one set here then it will be removed
     * after execution. This value defaults to true.
     *
     * @param {*} value The new value to check for when executing listeners.
     * @return {Object} Current instance of EventEmitter for chaining.
     */
    proto.setOnceReturnValue = function setOnceReturnValue(value) {
        this._onceReturnValue = value;
        return this;
    };

    /**
     * Fetches the current value to check against when executing listeners. If
     * the listeners return value matches this one then it should be removed
     * automatically. It will return true by default.
     *
     * @return {*|Boolean} The current value to check for or the default, true.
     * @api private
     */
    proto._getOnceReturnValue = function _getOnceReturnValue() {
        if (this.hasOwnProperty('_onceReturnValue')) {
            return this._onceReturnValue;
        }
        else {
            return true;
        }
    };

    /**
     * Fetches the events object and creates one if required.
     *
     * @return {Object} The events storage object.
     * @api private
     */
    proto._getEvents = function _getEvents() {
        return this._events || (this._events = {});
    };

    /**
     * Reverts the global {@link EventEmitter} to its previous value and returns a reference to this version.
     *
     * @return {Function} Non conflicting EventEmitter class.
     */
    EventEmitter.noConflict = function noConflict() {
        exports.EventEmitter = originalGlobalValue;
        return EventEmitter;
    };

    // Expose the class either via AMD, CommonJS or the global object
    if (typeof define === 'function' && define.amd) {
        define('eventEmitter/EventEmitter',[],function () {
            return EventEmitter;
        });
    }
    else if (typeof module === 'object' && module.exports){
        module.exports = EventEmitter;
    }
    else {
        exports.EventEmitter = EventEmitter;
    }
}.call(this));

/*!
 * getStyleProperty v1.0.4
 * original by kangax
 * http://perfectionkills.com/feature-testing-css-properties/
 * MIT license
 */

/*jshint browser: true, strict: true, undef: true */
/*global define: false, exports: false, module: false */

( function( window ) {



var prefixes = 'Webkit Moz ms Ms O'.split(' ');
var docElemStyle = document.documentElement.style;

function getStyleProperty( propName ) {
  if ( !propName ) {
    return;
  }

  // test standard property first
  if ( typeof docElemStyle[ propName ] === 'string' ) {
    return propName;
  }

  // capitalize
  propName = propName.charAt(0).toUpperCase() + propName.slice(1);

  // test vendor specific properties
  var prefixed;
  for ( var i=0, len = prefixes.length; i < len; i++ ) {
    prefixed = prefixes[i] + propName;
    if ( typeof docElemStyle[ prefixed ] === 'string' ) {
      return prefixed;
    }
  }
}

// transport
if ( typeof define === 'function' && define.amd ) {
  // AMD
  define( 'get-style-property/get-style-property',[],function() {
    return getStyleProperty;
  });
} else if ( typeof exports === 'object' ) {
  // CommonJS for Component
  module.exports = getStyleProperty;
} else {
  // browser global
  window.getStyleProperty = getStyleProperty;
}

})( window );

/*!
 * getSize v1.2.2
 * measure size of elements
 * MIT license
 */

/*jshint browser: true, strict: true, undef: true, unused: true */
/*global define: false, exports: false, require: false, module: false, console: false */

( function( window, undefined ) {



// -------------------------- helpers -------------------------- //

// get a number from a string, not a percentage
function getStyleSize( value ) {
  var num = parseFloat( value );
  // not a percent like '100%', and a number
  var isValid = value.indexOf('%') === -1 && !isNaN( num );
  return isValid && num;
}

function noop() {}

var logError = typeof console === 'undefined' ? noop :
  function( message ) {
    console.error( message );
  };

// -------------------------- measurements -------------------------- //

var measurements = [
  'paddingLeft',
  'paddingRight',
  'paddingTop',
  'paddingBottom',
  'marginLeft',
  'marginRight',
  'marginTop',
  'marginBottom',
  'borderLeftWidth',
  'borderRightWidth',
  'borderTopWidth',
  'borderBottomWidth'
];

function getZeroSize() {
  var size = {
    width: 0,
    height: 0,
    innerWidth: 0,
    innerHeight: 0,
    outerWidth: 0,
    outerHeight: 0
  };
  for ( var i=0, len = measurements.length; i < len; i++ ) {
    var measurement = measurements[i];
    size[ measurement ] = 0;
  }
  return size;
}



function defineGetSize( getStyleProperty ) {

// -------------------------- setup -------------------------- //

var isSetup = false;

var getStyle, boxSizingProp, isBoxSizeOuter;

/**
 * setup vars and functions
 * do it on initial getSize(), rather than on script load
 * For Firefox bug https://bugzilla.mozilla.org/show_bug.cgi?id=548397
 */
function setup() {
  // setup once
  if ( isSetup ) {
    return;
  }
  isSetup = true;

  var getComputedStyle = window.getComputedStyle;
  getStyle = ( function() {
    var getStyleFn = getComputedStyle ?
      function( elem ) {
        return getComputedStyle( elem, null );
      } :
      function( elem ) {
        return elem.currentStyle;
      };

      return function getStyle( elem ) {
        var style = getStyleFn( elem );
        if ( !style ) {
          logError( 'Style returned ' + style +
            '. Are you running this code in a hidden iframe on Firefox? ' +
            'See http://bit.ly/getsizebug1' );
        }
        return style;
      };
  })();

  // -------------------------- box sizing -------------------------- //

  boxSizingProp = getStyleProperty('boxSizing');

  /**
   * WebKit measures the outer-width on style.width on border-box elems
   * IE & Firefox measures the inner-width
   */
  if ( boxSizingProp ) {
    var div = document.createElement('div');
    div.style.width = '200px';
    div.style.padding = '1px 2px 3px 4px';
    div.style.borderStyle = 'solid';
    div.style.borderWidth = '1px 2px 3px 4px';
    div.style[ boxSizingProp ] = 'border-box';

    var body = document.body || document.documentElement;
    body.appendChild( div );
    var style = getStyle( div );

    isBoxSizeOuter = getStyleSize( style.width ) === 200;
    body.removeChild( div );
  }

}

// -------------------------- getSize -------------------------- //

function getSize( elem ) {
  setup();

  // use querySeletor if elem is string
  if ( typeof elem === 'string' ) {
    elem = document.querySelector( elem );
  }

  // do not proceed on non-objects
  if ( !elem || typeof elem !== 'object' || !elem.nodeType ) {
    return;
  }

  var style = getStyle( elem );

  // if hidden, everything is 0
  if ( style.display === 'none' ) {
    return getZeroSize();
  }

  var size = {};
  size.width = elem.offsetWidth;
  size.height = elem.offsetHeight;
  if (Browser.IsIe() && Browser.Version() <= 8) {
	  if ($('body').css('margin')!=0 && $(elem).hasClass('DWMasonryGallery_container')) {
		  size.width = size.width - 2*parseInt($('body').css('margin'));
	  } else if ($(elem).hasClass('DWMasonryGallery_widget') || $(elem).hasClass('grid-sizer')) {
		   size.width = size.width - parseInt($('body').css('margin'));
	  }
  }

  var isBorderBox = size.isBorderBox = !!( boxSizingProp &&
    style[ boxSizingProp ] && style[ boxSizingProp ] === 'border-box' );

  // get all measurements
  for ( var i=0, len = measurements.length; i < len; i++ ) {
    var measurement = measurements[i];
    var value = style[ measurement ];
    value = mungeNonPixel( elem, value );
    var num = parseFloat( value );
    // any 'auto', 'medium' value will be 0
    size[ measurement ] = !isNaN( num ) ? num : 0;
  }

  var paddingWidth = size.paddingLeft + size.paddingRight;
  var paddingHeight = size.paddingTop + size.paddingBottom;
  var marginWidth = size.marginLeft + size.marginRight;
  var marginHeight = size.marginTop + size.marginBottom;
  var borderWidth = size.borderLeftWidth + size.borderRightWidth;
  var borderHeight = size.borderTopWidth + size.borderBottomWidth;

  var isBorderBoxSizeOuter = isBorderBox && isBoxSizeOuter;

  // overwrite width and height if we can get it from style
  var styleWidth = getStyleSize( style.width );
  if ( styleWidth !== false ) {
    size.width = styleWidth +
      // add padding and border unless it's already including it
      ( isBorderBoxSizeOuter ? 0 : paddingWidth + borderWidth );
  }

  var styleHeight = getStyleSize( style.height );
  if ( styleHeight !== false ) {
    size.height = styleHeight +
      // add padding and border unless it's already including it
      ( isBorderBoxSizeOuter ? 0 : paddingHeight + borderHeight );
  }

  size.innerWidth = size.width - ( paddingWidth + borderWidth );
  size.innerHeight = size.height - ( paddingHeight + borderHeight );

  size.outerWidth = size.width + marginWidth;
  size.outerHeight = size.height + marginHeight;
	
  return size;
}

// IE8 returns percent values, not pixels
// taken from jQuery's curCSS
function mungeNonPixel( elem, value ) {
  // IE8 and has percent value
  if ( window.getComputedStyle || value.indexOf('%') === -1 ) {
    return value;
  }
  var style = elem.style;
  // Remember the original values
  var left = style.left;
  var rs = elem.runtimeStyle;
  var rsLeft = rs && rs.left;

  // Put in the new values to get a computed value out
  if ( rsLeft ) {
    rs.left = elem.currentStyle.left;
  }
  style.left = value;
  value = style.pixelLeft;

  // Revert the changed values
  style.left = left;
  if ( rsLeft ) {
    rs.left = rsLeft;
  }

  return value;
}

return getSize;

}

// transport
if ( typeof define === 'function' && define.amd ) {
  // AMD for RequireJS
  define( 'get-size/get-size',[ 'get-style-property/get-style-property' ], defineGetSize );
} else if ( typeof exports === 'object' ) {
  // CommonJS for Component
  module.exports = defineGetSize( require('desandro-get-style-property') );
} else {
  // browser global
  window.getSize = defineGetSize( window.getStyleProperty );
}

})( window );

/*!
 * docReady v1.0.4
 * Cross browser DOMContentLoaded event emitter
 * MIT license
 */

/*jshint browser: true, strict: true, undef: true, unused: true*/
/*global define: false, require: false, module: false */

( function( window ) {



var document = window.document;
// collection of functions to be triggered on ready
var queue = [];

function docReady( fn ) {
  // throw out non-functions
  if ( typeof fn !== 'function' ) {
    return;
  }

  if ( docReady.isReady ) {
    // ready now, hit it
    fn();
  } else {
    // queue function when ready
    queue.push( fn );
  }
}

docReady.isReady = false;

// triggered on various doc ready events
function onReady( event ) {
  // bail if already triggered or IE8 document is not ready just yet
  var isIE8NotReady = event.type === 'readystatechange' && document.readyState !== 'complete';
  if ( docReady.isReady || isIE8NotReady ) {
    return;
  }

  trigger();
}

function trigger() {
  docReady.isReady = true;
  // process queue
  for ( var i=0, len = queue.length; i < len; i++ ) {
    var fn = queue[i];
    fn();
  }
}

function defineDocReady( eventie ) {
  // trigger ready if page is ready
  if ( document.readyState === 'complete' ) {
    trigger();
  } else {
    // listen for events
    eventie.bind( document, 'DOMContentLoaded', onReady );
    eventie.bind( document, 'readystatechange', onReady );
    eventie.bind( window, 'load', onReady );
  }

  return docReady;
}

// transport
if ( typeof define === 'function' && define.amd ) {
  // AMD
  define( 'doc-ready/doc-ready',[ 'eventie/eventie' ], defineDocReady );
} else if ( typeof exports === 'object' ) {
  module.exports = defineDocReady( require('eventie') );
} else {
  // browser global
  window.docReady = defineDocReady( window.eventie );
}

})( window );

/**
 * matchesSelector v1.0.3
 * matchesSelector( element, '.selector' )
 * MIT license
 */

/*jshint browser: true, strict: true, undef: true, unused: true */
/*global define: false, module: false */

( function( ElemProto ) {

  

  var matchesMethod = ( function() {
    // check for the standard method name first
    if ( ElemProto.matches ) {
      return 'matches';
    }
    // check un-prefixed
    if ( ElemProto.matchesSelector ) {
      return 'matchesSelector';
    }
    // check vendor prefixes
    var prefixes = [ 'webkit', 'moz', 'ms', 'o' ];

    for ( var i=0, len = prefixes.length; i < len; i++ ) {
      var prefix = prefixes[i];
      var method = prefix + 'MatchesSelector';
      if ( ElemProto[ method ] ) {
        return method;
      }
    }
  })();

  // ----- match ----- //

  function match( elem, selector ) {
    return elem[ matchesMethod ]( selector );
  }

  // ----- appendToFragment ----- //

  function checkParent( elem ) {
    // not needed if already has parent
    if ( elem.parentNode ) {
      return;
    }
    var fragment = document.createDocumentFragment();
    fragment.appendChild( elem );
  }

  // ----- query ----- //

  // fall back to using QSA
  // thx @jonathantneal https://gist.github.com/3062955
  function query( elem, selector ) {
    // append to fragment if no parent
    checkParent( elem );

    // match elem with all selected elems of parent
    var elems = elem.parentNode.querySelectorAll( selector );
    for ( var i=0, len = elems.length; i < len; i++ ) {
      // return true if match
      if ( elems[i] === elem ) {
        return true;
      }
    }
    // otherwise return false
    return false;
  }

  // ----- matchChild ----- //

  function matchChild( elem, selector ) {
    checkParent( elem );
    return match( elem, selector );
  }

  // ----- matchesSelector ----- //

  var matchesSelector;

  if ( matchesMethod ) {
    // IE9 supports matchesSelector, but doesn't work on orphaned elems
    // check for that
    var div = document.createElement('div');
    var supportsOrphans = match( div, 'div' );
    matchesSelector = supportsOrphans ? match : matchChild;
  } else {
    matchesSelector = query;
  }

  // transport
  if ( typeof define === 'function' && define.amd ) {
    // AMD
    define( 'matches-selector/matches-selector',[],function() {
      return matchesSelector;
    });
  } else if ( typeof exports === 'object' ) {
    module.exports = matchesSelector;
  }
  else {
    // browser global
    window.matchesSelector = matchesSelector;
  }

})( Element.prototype );

/**
 * Fizzy UI utils v1.0.1
 * MIT license
 */

/*jshint browser: true, undef: true, unused: true, strict: true */

( function( window, factory ) {
  /*global define: false, module: false, require: false */
  
  // universal module definition

  if ( typeof define == 'function' && define.amd ) {
    // AMD
    define( 'fizzy-ui-utils/utils',[
      'doc-ready/doc-ready',
      'matches-selector/matches-selector'
    ], function( docReady, matchesSelector ) {
      return factory( window, docReady, matchesSelector );
    });
  } else if ( typeof exports == 'object' ) {
    // CommonJS
    module.exports = factory(
      window,
      require('doc-ready'),
      require('desandro-matches-selector')
    );
  } else {
    // browser global
    window.fizzyUIUtils = factory(
      window,
      window.docReady,
      window.matchesSelector
    );
  }

}( window, function factory( window, docReady, matchesSelector ) {



var utils = {};

// ----- extend ----- //

// extends objects
utils.extend = function( a, b ) {
  for ( var prop in b ) {
    a[ prop ] = b[ prop ];
  }
  return a;
};

// ----- modulo ----- //

utils.modulo = function( num, div ) {
  return ( ( num % div ) + div ) % div;
};

// ----- isArray ----- //
  
var objToString = Object.prototype.toString;
utils.isArray = function( obj ) {
  return objToString.call( obj ) == '[object Array]';
};

// ----- makeArray ----- //

// turn element or nodeList into an array
utils.makeArray = function( obj ) {
  var ary = [];
  if ( utils.isArray( obj ) ) {
    // use object if already an array
    ary = obj;
  } else if ( obj && typeof obj.length == 'number' ) {
    // convert nodeList to array
    for ( var i=0, len = obj.length; i < len; i++ ) {
      ary.push( obj[i] );
    }
  } else {
    // array of single index
    ary.push( obj );
  }
  return ary;
};

// ----- indexOf ----- //

// index of helper cause IE8
utils.indexOf = Array.prototype.indexOf ? function( ary, obj ) {
    return ary.indexOf( obj );
  } : function( ary, obj ) {
    for ( var i=0, len = ary.length; i < len; i++ ) {
      if ( ary[i] === obj ) {
        return i;
      }
    }
    return -1;
  };

// ----- removeFrom ----- //

utils.removeFrom = function( ary, obj ) {
  var index = utils.indexOf( ary, obj );
  if ( index != -1 ) {
    ary.splice( index, 1 );
  }
};

// ----- isElement ----- //

// http://stackoverflow.com/a/384380/182183
utils.isElement = ( typeof HTMLElement == 'function' || typeof HTMLElement == 'object' ) ?
  function isElementDOM2( obj ) {
    return obj instanceof HTMLElement;
  } :
  function isElementQuirky( obj ) {
    return obj && typeof obj == 'object' &&
      obj.nodeType == 1 && typeof obj.nodeName == 'string';
  };

// ----- setText ----- //

utils.setText = ( function() {
  var setTextProperty;
  function setText( elem, text ) {
    // only check setTextProperty once
    setTextProperty = setTextProperty || ( document.documentElement.textContent !== undefined ? 'textContent' : 'innerText' );
    elem[ setTextProperty ] = text;
  }
  return setText;
})();

// ----- getParent ----- //

utils.getParent = function( elem, selector ) {
  while ( elem != document.body ) {
    elem = elem.parentNode;
    if ( matchesSelector( elem, selector ) ) {
      return elem;
    }
  }
};

// ----- getQueryElement ----- //

// use element as selector string
utils.getQueryElement = function( elem ) {
  if ( typeof elem == 'string' ) {
    return document.querySelector( elem );
  }
  return elem;
};

// ----- handleEvent ----- //

// enable .ontype to trigger from .addEventListener( elem, 'type' )
utils.handleEvent = function( event ) {
  var method = 'on' + event.type;
  if ( this[ method ] ) {
    this[ method ]( event );
  }
};

// ----- filterFindElements ----- //

utils.filterFindElements = function( elems, selector ) {
  // make array of elems
  elems = utils.makeArray( elems );
  var ffElems = [];

  for ( var i=0, len = elems.length; i < len; i++ ) {
    var elem = elems[i];
    // check that elem is an actual element
    if ( !utils.isElement( elem ) ) {
      continue;
    }
    // filter & find items if we have a selector
    if ( selector ) {
      // filter siblings
      if ( matchesSelector( elem, selector ) ) {
        ffElems.push( elem );
      }
      // find children
      var childElems = elem.querySelectorAll( selector );
      // concat childElems to filterFound array
      for ( var j=0, jLen = childElems.length; j < jLen; j++ ) {
        ffElems.push( childElems[j] );
      }
    } else {
      ffElems.push( elem );
    }
  }

  return ffElems;
};

// ----- debounceMethod ----- //

utils.debounceMethod = function( _class, methodName, threshold ) {
  // original method
  var method = _class.prototype[ methodName ];
  var timeoutName = methodName + 'Timeout';

  _class.prototype[ methodName ] = function() {
    var timeout = this[ timeoutName ];
    if ( timeout ) {
      clearTimeout( timeout );
    }
    var args = arguments;

    var _this = this;
    this[ timeoutName ] = setTimeout( function() {
      method.apply( _this, args );
      delete _this[ timeoutName ];
    }, threshold || 100 );
  };
};

// ----- htmlInit ----- //

// http://jamesroberts.name/blog/2010/02/22/string-functions-for-javascript-trim-to-camel-case-to-dashed-and-to-underscore/
utils.toDashed = function( str ) {
  return str.replace( /(.)([A-Z])/g, function( match, $1, $2 ) {
    return $1 + '-' + $2;
  }).toLowerCase();
};

var console = window.console;
/**
 * allow user to initialize classes via .js-namespace class
 * htmlInit( Widget, 'widgetName' )
 * options are parsed from data-namespace-option attribute
 */
utils.htmlInit = function( WidgetClass, namespace ) {
  docReady( function() {
    var dashedNamespace = utils.toDashed( namespace );
    var elems = document.querySelectorAll( '.js-' + dashedNamespace );
    var dataAttr = 'data-' + dashedNamespace + '-options';

    for ( var i=0, len = elems.length; i < len; i++ ) {
      var elem = elems[i];
      var attr = elem.getAttribute( dataAttr );
      var options;
      try {
        options = attr && JSON.parse( attr );
      } catch ( error ) {
        // log error, do not initialize
        if ( console ) {
          console.error( 'Error parsing ' + dataAttr + ' on ' +
            elem.nodeName.toLowerCase() + ( elem.id ? '#' + elem.id : '' ) + ': ' +
            error );
        }
        continue;
      }
      // initialize
      var instance = new WidgetClass( elem, options );
      // make available via $().data('layoutname')
      var jQuery = window.gallery_jQuery;
      if ( jQuery ) {
        jQuery.data( elem, namespace, instance );
      }
    }
  });
};

// -----  ----- //

return utils;

}));

/**
 * Outlayer Item
 */

( function( window, factory ) {
  
  // universal module definition
  if ( typeof define === 'function' && define.amd ) {
    // AMD
    define( 'outlayer/item',[
        'eventEmitter/EventEmitter',
        'get-size/get-size',
        'get-style-property/get-style-property',
        'fizzy-ui-utils/utils'
      ],
      function( EventEmitter, getSize, getStyleProperty, utils ) {
        return factory( window, EventEmitter, getSize, getStyleProperty, utils );
      }
    );
  } else if (typeof exports === 'object') {
    // CommonJS
    module.exports = factory(
      window,
      require('wolfy87-eventemitter'),
      require('get-size'),
      require('desandro-get-style-property'),
      require('fizzy-ui-utils')
    );
  } else {
    // browser global
    window.Outlayer = {};
    window.Outlayer.Item = factory(
      window,
      window.EventEmitter,
      window.getSize,
      window.getStyleProperty,
      window.fizzyUIUtils
    );
  }

}( window, function factory( window, EventEmitter, getSize, getStyleProperty, utils ) {


// ----- helpers ----- //

var getComputedStyle = window.getComputedStyle;
var getStyle = getComputedStyle ?
  function( elem ) {
    return getComputedStyle( elem, null );
  } :
  function( elem ) {
    return elem.currentStyle;
  };


function isEmptyObj( obj ) {
  for ( var prop in obj ) {
    return false;
  }
  prop = null;
  return true;
}

// -------------------------- CSS3 support -------------------------- //

var transitionProperty = getStyleProperty('transition');
var transformProperty = getStyleProperty('transform');
var supportsCSS3 = transitionProperty && transformProperty;
var is3d = !!getStyleProperty('perspective');

var transitionEndEvent = {
  WebkitTransition: 'webkitTransitionEnd',
  MozTransition: 'transitionend',
  OTransition: 'otransitionend',
  transition: 'transitionend'
}[ transitionProperty ];

// properties that could have vendor prefix
var prefixableProperties = [
  'transform',
  'transition',
  'transitionDuration',
  'transitionProperty'
];

// cache all vendor properties
var vendorProperties = ( function() {
  var cache = {};
  for ( var i=0, len = prefixableProperties.length; i < len; i++ ) {
    var prop = prefixableProperties[i];
    var supportedProp = getStyleProperty( prop );
    if ( supportedProp && supportedProp !== prop ) {
      cache[ prop ] = supportedProp;
    }
  }
  return cache;
})();

// -------------------------- Item -------------------------- //

function Item( element, layout ) {
  if ( !element ) {
    return;
  }
  
  this.element = element;
  // parent layout class, i.e. Masonry, Isotope, or Packery
  this.layout = layout;
  this.position = {
    x: 0,
    y: 0
  };

  this._create();
}

// inherit EventEmitter
utils.extend( Item.prototype, EventEmitter.prototype );

Item.prototype._create = function() {
  // transition objects
  this._transn = {
    ingProperties: {},
    clean: {},
    onEnd: {}
  };

  this.css({
    position: 'absolute'
  });
};

// trigger specified handler for event type
Item.prototype.handleEvent = function( event ) {
  var method = 'on' + event.type;
  if ( this[ method ] ) {
    this[ method ]( event );
  }
};

Item.prototype.getSize = function() {
  this.size = getSize( this.element );
};

/**
 * apply CSS styles to element
 * @param {Object} style
 */
Item.prototype.css = function( style ) {
  var elemStyle = this.element.style;

  for ( var prop in style ) {
    // use vendor property if available
    var supportedProp = vendorProperties[ prop ] || prop;
    elemStyle[ supportedProp ] = style[ prop ];
  }
};

 // measure position, and sets it
Item.prototype.getPosition = function() {
  var style = getStyle( this.element );
  var layoutOptions = this.layout.options;
  var isOriginLeft = layoutOptions.isOriginLeft;
  var isOriginTop = layoutOptions.isOriginTop;
  var x = parseInt( style[ isOriginLeft ? 'left' : 'right' ], 10 );
  var y = parseInt( style[ isOriginTop ? 'top' : 'bottom' ], 10 );

  // clean up 'auto' or other non-integer values
  x = isNaN( x ) ? 0 : x;
  y = isNaN( y ) ? 0 : y;
  // remove padding from measurement
  var layoutSize = this.layout.size;
  x -= isOriginLeft ? layoutSize.paddingLeft : layoutSize.paddingRight;
  y -= isOriginTop ? layoutSize.paddingTop : layoutSize.paddingBottom;

  this.position.x = x;
  this.position.y = y;
};

// set settled position, apply padding
Item.prototype.layoutPosition = function() {
  var layoutSize = this.layout.size;
  var layoutOptions = this.layout.options;
  var style = {};

  // x
  var xPadding = layoutOptions.isOriginLeft ? 'paddingLeft' : 'paddingRight';
  var xProperty = layoutOptions.isOriginLeft ? 'left' : 'right';
  var xResetProperty = layoutOptions.isOriginLeft ? 'right' : 'left';

  var x = this.position.x + layoutSize[ xPadding ];
  // set in percentage
  x = layoutOptions.percentPosition && !layoutOptions.isHorizontal ?
	( ( x / layoutSize.width ) * 100 ) + '%' : x + 'px';
		
  style[ xProperty ] = x;
  // reset other property
  style[ xResetProperty ] = '';

  // y
  var yPadding = layoutOptions.isOriginTop ? 'paddingTop' : 'paddingBottom';
  var yProperty = layoutOptions.isOriginTop ? 'top' : 'bottom';
  var yResetProperty = layoutOptions.isOriginTop ? 'bottom' : 'top';

  var y = this.position.y + layoutSize[ yPadding ];
  // set in percentage
  y = layoutOptions.percentPosition && layoutOptions.isHorizontal ?
    ( ( y / layoutSize.height ) * 100 ) + '%' : y + 'px';
  style[ yProperty ] = y;
  // reset other property
  style[ yResetProperty ] = '';

  this.css( style );
  this.emitEvent( 'layout', [ this ] );
};


// transform translate function
var translate = is3d ?
  function( x, y ) {
    return 'translate3d(' + x + 'px, ' + y + 'px, 0)';
  } :
  function( x, y ) {
    return 'translate(' + x + 'px, ' + y + 'px)';
  };


Item.prototype._transitionTo = function( x, y ) {
  this.getPosition();
  // get current x & y from top/left
  var curX = this.position.x;
  var curY = this.position.y;

  var compareX = parseInt( x, 10 );
  var compareY = parseInt( y, 10 );
  var didNotMove = compareX === this.position.x && compareY === this.position.y;

  // save end position
  this.setPosition( x, y );

  // if did not move and not transitioning, just go to layout
  if ( didNotMove && !this.isTransitioning ) {
    this.layoutPosition();
    return;
  }

  var transX = x - curX;
  var transY = y - curY;
  var transitionStyle = {};
  // flip cooridinates if origin on right or bottom
  var layoutOptions = this.layout.options;
  transX = layoutOptions.isOriginLeft ? transX : -transX;
  transY = layoutOptions.isOriginTop ? transY : -transY;
  transitionStyle.transform = translate( transX, transY );

  this.transition({
    to: transitionStyle,
    onTransitionEnd: {
      transform: this.layoutPosition
    },
    isCleaning: true
  });
};

// non transition + transform support
Item.prototype.goTo = function( x, y ) {
  this.setPosition( x, y );
  this.layoutPosition();
};

// use transition and transforms if supported
Item.prototype.moveTo = supportsCSS3 ?
  Item.prototype._transitionTo : Item.prototype.goTo;

Item.prototype.setPosition = function( x, y ) {
  this.position.x = parseInt( x, 10 );
  this.position.y = parseInt( y, 10 );
};

// ----- transition ----- //

/**
 * @param {Object} style - CSS
 * @param {Function} onTransitionEnd
 */

// non transition, just trigger callback
Item.prototype._nonTransition = function( args ) {
  this.css( args.to );
  if ( args.isCleaning ) {
    this._removeStyles( args.to );
  }
  for ( var prop in args.onTransitionEnd ) {
    args.onTransitionEnd[ prop ].call( this );
  }
};

/**
 * proper transition
 * @param {Object} args - arguments
 *   @param {Object} to - style to transition to
 *   @param {Object} from - style to start transition from
 *   @param {Boolean} isCleaning - removes transition styles after transition
 *   @param {Function} onTransitionEnd - callback
 */
Item.prototype._transition = function( args ) {
  // redirect to nonTransition if no transition duration
  if ( !parseFloat( this.layout.options.transitionDuration ) ) {
    this._nonTransition( args );
    return;
  }

  var _transition = this._transn;
  // keep track of onTransitionEnd callback by css property
  for ( var prop in args.onTransitionEnd ) {
    _transition.onEnd[ prop ] = args.onTransitionEnd[ prop ];
  }
  // keep track of properties that are transitioning
  for ( prop in args.to ) {
    _transition.ingProperties[ prop ] = true;
    // keep track of properties to clean up when transition is done
    if ( args.isCleaning ) {
      _transition.clean[ prop ] = true;
    }
  }

  // set from styles
  if ( args.from ) {
    this.css( args.from );
    // force redraw. http://blog.alexmaccaw.com/css-transitions
    var h = this.element.offsetHeight;
    // hack for JSHint to hush about unused var
    h = null;
  }
  // enable transition
  this.enableTransition( args.to );
  // set styles that are transitioning
  this.css( args.to );

  this.isTransitioning = true;

};

var itemTransitionProperties = transformProperty && ( utils.toDashed( transformProperty ) +
  ',opacity' );

Item.prototype.enableTransition = function(/* style */) {
  // only enable if not already transitioning
  // bug in IE10 were re-setting transition style will prevent
  // transitionend event from triggering
  if ( this.isTransitioning ) {
    return;
  }

  // make transition: foo, bar, baz from style object
  // TODO uncomment this bit when IE10 bug is resolved
  // var transitionValue = [];
  // for ( var prop in style ) {
  //   // dash-ify camelCased properties like WebkitTransition
  //   transitionValue.push( toDash( prop ) );
  // }
  // enable transition styles
  // HACK always enable transform,opacity for IE10
  this.css({
    transitionProperty: itemTransitionProperties,
    transitionDuration: this.layout.options.transitionDuration
  });
  // listen for transition end event
  this.element.addEventListener( transitionEndEvent, this, false );
};

Item.prototype.transition = Item.prototype[ transitionProperty ? '_transition' : '_nonTransition' ];

// ----- events ----- //

Item.prototype.onwebkitTransitionEnd = function( event ) {
  this.ontransitionend( event );
};

Item.prototype.onotransitionend = function( event ) {
  this.ontransitionend( event );
};

// properties that I munge to make my life easier
var dashedVendorProperties = {
  '-webkit-transform': 'transform',
  '-moz-transform': 'transform',
  '-o-transform': 'transform'
};

Item.prototype.ontransitionend = function( event ) {
  // disregard bubbled events from children
  if ( event.target !== this.element ) {
    return;
  }
  var _transition = this._transn;
  // get property name of transitioned property, convert to prefix-free
  var propertyName = dashedVendorProperties[ event.propertyName ] || event.propertyName;

  // remove property that has completed transitioning
  delete _transition.ingProperties[ propertyName ];
  // check if any properties are still transitioning
  if ( isEmptyObj( _transition.ingProperties ) ) {
    // all properties have completed transitioning
    this.disableTransition();
  }
  // clean style
  if ( propertyName in _transition.clean ) {
    // clean up style
    this.element.style[ event.propertyName ] = '';
    delete _transition.clean[ propertyName ];
  }
  // trigger onTransitionEnd callback
  if ( propertyName in _transition.onEnd ) {
    var onTransitionEnd = _transition.onEnd[ propertyName ];
    onTransitionEnd.call( this );
    delete _transition.onEnd[ propertyName ];
  }

  this.emitEvent( 'transitionEnd', [ this ] );
};

Item.prototype.disableTransition = function() {
  this.removeTransitionStyles();
  this.element.removeEventListener( transitionEndEvent, this, false );
  this.isTransitioning = false;
};

/**
 * removes style property from element
 * @param {Object} style
**/
Item.prototype._removeStyles = function( style ) {
  // clean up transition styles
  var cleanStyle = {};
  for ( var prop in style ) {
    cleanStyle[ prop ] = '';
  }
  this.css( cleanStyle );
};

var cleanTransitionStyle = {
  transitionProperty: '',
  transitionDuration: ''
};

Item.prototype.removeTransitionStyles = function() {
  // remove transition
  this.css( cleanTransitionStyle );
};

// ----- show/hide/remove ----- //

// remove element from DOM
Item.prototype.removeElem = function() {
  this.element.parentNode.removeChild( this.element );
  // remove display: none
  this.css({ display: '' });
  this.emitEvent( 'remove', [ this ] );
};

Item.prototype.remove = function() {
  // just remove element if no transition support or no transition
  if ( !transitionProperty || !parseFloat( this.layout.options.transitionDuration ) ) {
    this.removeElem();
    return;
  }

  // start transition
  var _this = this;
  this.once( 'transitionEnd', function() {
    _this.removeElem();
  });
  this.hide();
};

Item.prototype.reveal = function() {
  delete this.isHidden;
  // remove display: none
  this.css({ display: '' });

  var options = this.layout.options;

  var onTransitionEnd = {};
  var transitionEndProperty = this.getHideRevealTransitionEndProperty('visibleStyle');
  onTransitionEnd[ transitionEndProperty ] = this.onRevealTransitionEnd;

  this.transition({
    from: options.hiddenStyle,
    to: options.visibleStyle,
    isCleaning: true,
    onTransitionEnd: onTransitionEnd
  });
};

Item.prototype.onRevealTransitionEnd = function() {
  // check if still visible
  // during transition, item may have been hidden
  if ( !this.isHidden ) {
    this.emitEvent('reveal');
  }
};

/**
 * get style property use for hide/reveal transition end
 * @param {String} styleProperty - hiddenStyle/visibleStyle
 * @returns {String}
 */
Item.prototype.getHideRevealTransitionEndProperty = function( styleProperty ) {
  var optionStyle = this.layout.options[ styleProperty ];
  // use opacity
  if ( optionStyle.opacity ) {
    return 'opacity';
  }
  // get first property
  for ( var prop in optionStyle ) {
    return prop;
  }
};

Item.prototype.hide = function() {
  // set flag
  this.isHidden = true;
  // remove display: none
  this.css({ display: '' });

  var options = this.layout.options;

  var onTransitionEnd = {};
  var transitionEndProperty = this.getHideRevealTransitionEndProperty('hiddenStyle');
  onTransitionEnd[ transitionEndProperty ] = this.onHideTransitionEnd;

  this.transition({
    from: options.visibleStyle,
    to: options.hiddenStyle,
    // keep hidden stuff hidden
    isCleaning: true,
    onTransitionEnd: onTransitionEnd
  });
};

Item.prototype.onHideTransitionEnd = function() {
  // check if still hidden
  // during transition, item may have been un-hidden
  if ( this.isHidden ) {
    this.css({ display: 'none' });
    this.emitEvent('hide');
  }
};

Item.prototype.destroy = function() {
  this.css({
    position: '',
    left: '',
    right: '',
    top: '',
    bottom: '',
    transition: '',
    transform: ''
  });
};

return Item;

}));

/*!
 * Outlayer v1.4.0
 * the brains and guts of a layout library
 * MIT license
 */

( function( window, factory ) {
  
  // universal module definition

  if ( typeof define == 'function' && define.amd ) {
    // AMD
    define( 'outlayer/outlayer',[
        'eventie/eventie',
        'eventEmitter/EventEmitter',
        'get-size/get-size',
        'fizzy-ui-utils/utils',
        './item'
      ],
      function( eventie, EventEmitter, getSize, utils, Item ) {
        return factory( window, eventie, EventEmitter, getSize, utils, Item);
      }
    );
  } else if ( typeof exports == 'object' ) {
    // CommonJS
    module.exports = factory(
      window,
      require('eventie'),
      require('wolfy87-eventemitter'),
      require('get-size'),
      require('fizzy-ui-utils'),
      require('./item')
    );
  } else {
    // browser global
    window.Outlayer = factory(
      window,
      window.eventie,
      window.EventEmitter,
      window.getSize,
      window.fizzyUIUtils,
      window.Outlayer.Item
    );
  }

}( window, function factory( window, eventie, EventEmitter, getSize, utils, Item ) {


// ----- vars ----- //

var console = window.console;
var jQuery = window.gallery_jQuery;
var noop = function() {};

// -------------------------- Outlayer -------------------------- //

// globally unique identifiers
var GUID = 0;
// internal store of all Outlayer intances
var instances = {};


/**
 * @param {Element, String} element
 * @param {Object} options
 * @constructor
 */
function Outlayer( element, options ) {
  var queryElement = utils.getQueryElement( element );
  if ( !queryElement ) {
    if ( console ) {
      console.error( 'Bad element for ' + this.constructor.namespace +
        ': ' + ( queryElement || element ) );
    }
    return;
  }
  this.element = queryElement;
  // add jQuery
  if ( jQuery ) {
    this.$element = jQuery( this.element );
  }

  // options
  this.options = utils.extend( {}, this.constructor.defaults );
  this.option( options );

  // add id for Outlayer.getFromElement
  var id = ++GUID;
  this.element.outlayerGUID = id; // expando
  instances[ id ] = this; // associate via id

  // kick it off
  this._create();

  if ( this.options.isInitLayout ) {
    this.layout();
  }
}

// settings are for internal use only
Outlayer.namespace = 'outlayer';
Outlayer.Item = Item;

// default options
Outlayer.defaults = {
  containerStyle: {
    position: 'relative'
  },
  isInitLayout: true,
  isOriginLeft: true,
  isOriginTop: true,
  isResizeBound: true,
  isResizingContainer: true,
  // item options
  transitionDuration: '0.4s',
  hiddenStyle: {
    opacity: 0,
    transform: 'scale(0.001)'
  },
  visibleStyle: {
    opacity: 1,
    transform: 'scale(1)'
  }
};

// inherit EventEmitter
utils.extend( Outlayer.prototype, EventEmitter.prototype );

/**
 * set options
 * @param {Object} opts
 */
Outlayer.prototype.option = function( opts ) {
  utils.extend( this.options, opts );
};

Outlayer.prototype._create = function() {
  // get items from children
  this.reloadItems();
  // elements that affect layout, but are not laid out
  this.stamps = [];
  this.stamp( this.options.stamp );
  // set container style
  utils.extend( this.element.style, this.options.containerStyle );
	
  // bind resize method
  if ( this.options.isResizeBound ) {
    this.bindResize();
  }
};

// goes through all children again and gets bricks in proper order
Outlayer.prototype.reloadItems = function() {
  // collection of item elements
  this.items = this._itemize( this.element.children );
};


/**
 * turn elements into Outlayer.Items to be used in layout
 * @param {Array or NodeList or HTMLElement} elems
 * @returns {Array} items - collection of new Outlayer Items
 */
Outlayer.prototype._itemize = function( elems ) {

  var itemElems = this._filterFindItemElements( elems );
  var Item = this.constructor.Item;
	
  // create new Outlayer Items for collection
  var items = [];
  for ( var i=0, len = itemElems.length; i < len; i++ ) {
	  
    var elem = itemElems[i];
    var item = new Item( elem, this );
    items.push( item );
  }

  return items;
};

/**
 * get item elements to be used in layout
 * @param {Array or NodeList or HTMLElement} elems
 * @returns {Array} items - item elements
 */
Outlayer.prototype._filterFindItemElements = function( elems ) {
  return utils.filterFindElements( elems, this.options.itemSelector );
};

/**
 * getter method for getting item elements
 * @returns {Array} elems - collection of item elements
 */
Outlayer.prototype.getItemElements = function() {
  var elems = [];
  for ( var i=0, len = this.items.length; i < len; i++ ) {
    elems.push( this.items[i].element );
  }
  return elems;
};

// ----- init & layout ----- //

/**
 * lays out all items
 */
Outlayer.prototype.layout = function() {
  this._resetLayout();
  this._manageStamps();

  // don't animate first layout
  var isInstant = this.options.isLayoutInstant !== undefined ?
    this.options.isLayoutInstant : !this._isLayoutInited;
  this.layoutItems( this.items, isInstant );

  // flag for initalized
  this._isLayoutInited = true;
};

// _init is alias for layout
Outlayer.prototype._init = Outlayer.prototype.layout;

/**
 * logic before any new layout
 */
Outlayer.prototype._resetLayout = function() {
  this.getSize();
};


Outlayer.prototype.getSize = function() {
  this.size = getSize( this.element );
};

/**
 * get measurement from option, for columnWidth, rowHeight, gutter
 * if option is String -> get element from selector string, & get size of element
 * if option is Element -> get size of element
 * else use option as a number
 *
 * @param {String} measurement
 * @param {String} size - width or height
 * @private
 */
Outlayer.prototype._getMeasurement = function( measurement, size ) {
  var option = this.options[ measurement ];
  var elem;
  if ( !option ) {
    // default to 0
    this[ measurement ] = 0;
  } else {
    // use option as an element
    if ( typeof option === 'string' ) {
      elem = this.element.querySelector( option );
    } else if ( utils.isElement( option ) ) {
      elem = option;
    }
    // use size of element, if element
    this[ measurement ] = elem ? getSize( elem )[ size ] : option;
  }
};

/**
 * layout a collection of item elements
 * @api public
 */
Outlayer.prototype.layoutItems = function( items, isInstant ) {
  items = this._getItemsForLayout( items );

  this._layoutItems( items, isInstant );

  this._postLayout();
};

/**
 * get the items to be laid out
 * you may want to skip over some items
 * @param {Array} items
 * @returns {Array} items
 */
Outlayer.prototype._getItemsForLayout = function( items ) {
  var layoutItems = [];
  for ( var i=0, len = items.length; i < len; i++ ) {
    var item = items[i];
    if ( !item.isIgnored ) {
      layoutItems.push( item );
    }
  }
  return layoutItems;
};

/**
 * layout items
 * @param {Array} items
 * @param {Boolean} isInstant
 */
Outlayer.prototype._layoutItems = function( items, isInstant ) {
  this._emitCompleteOnItems( 'layout', items );

  if ( !items || !items.length ) {
    // no items, emit event with empty array
    return;
  }

  var queue = [];

  for ( var i=0, len = items.length; i < len; i++ ) {
    var item = items[i];
    // get x/y object from method
    var position = this._getItemLayoutPosition( item );
    // enqueue
    position.item = item;
    position.isInstant = isInstant || item.isLayoutInstant;
    queue.push( position );
  }

  this._processLayoutQueue( queue );
};

/**
 * get item layout position
 * @param {Outlayer.Item} item
 * @returns {Object} x and y position
 */
Outlayer.prototype._getItemLayoutPosition = function( /* item */ ) {
  return {
    x: 0,
    y: 0
  };
};

/**
 * iterate over array and position each item
 * Reason being - separating this logic prevents 'layout invalidation'
 * thx @paul_irish
 * @param {Array} queue
 */
Outlayer.prototype._processLayoutQueue = function( queue ) {
  for ( var i=0, len = queue.length; i < len; i++ ) {
    var obj = queue[i];
    this._positionItem( obj.item, obj.x, obj.y, obj.isInstant );
  }
};

/**
 * Sets position of item in DOM
 * @param {Outlayer.Item} item
 * @param {Number} x - horizontal position
 * @param {Number} y - vertical position
 * @param {Boolean} isInstant - disables transitions
 */
Outlayer.prototype._positionItem = function( item, x, y, isInstant ) {
  if ( isInstant ) {
    // if not transition, just set CSS
    item.goTo( x, y );
  } else {
    item.moveTo( x, y );
  }
};

/**
 * Any logic you want to do after each layout,
 * i.e. size the container
 */
Outlayer.prototype._postLayout = function() {
  this.resizeContainer();
};

Outlayer.prototype.resizeContainer = function() {
  if ( !this.options.isResizingContainer ) {
    return;
  }
  var size = this._getContainerSize();
  if ( size ) {
    this._setContainerMeasure( size.width, true );
    this._setContainerMeasure( size.height, false );
  }
};

/**
 * Sets width or height of container if returned
 * @returns {Object} size
 *   @param {Number} width
 *   @param {Number} height
 */
Outlayer.prototype._getContainerSize = noop;

/**
 * @param {Number} measure - size of width or height
 * @param {Boolean} isWidth
 */
Outlayer.prototype._setContainerMeasure = function( measure, isWidth ) {
  if ( measure === undefined ) {
    return;
  }

  var elemSize = this.size;
  // add padding and border width if border box
  if ( elemSize.isBorderBox ) {
    measure += isWidth ? elemSize.paddingLeft + elemSize.paddingRight +
      elemSize.borderLeftWidth + elemSize.borderRightWidth :
      elemSize.paddingBottom + elemSize.paddingTop +
      elemSize.borderTopWidth + elemSize.borderBottomWidth;
  }

  measure = Math.max( measure, 0 );
  this.element.style[ isWidth ? 'width' : 'height' ] = measure + 'px';
};

/**
 * emit eventComplete on a collection of items events
 * @param {String} eventName
 * @param {Array} items - Outlayer.Items
 */
Outlayer.prototype._emitCompleteOnItems = function( eventName, items ) {
  var _this = this;
  function onComplete() {
    _this.emitEvent( eventName + 'Complete', [ items ] );
  }

  var count = items.length;
  if ( !items || !count ) {
    onComplete();
    return;
  }

  var doneCount = 0;
  function tick() {
    doneCount++;
    if ( doneCount === count ) {
      onComplete();
    }
  }

  // bind callback
  for ( var i=0, len = items.length; i < len; i++ ) {
    var item = items[i];
    item.once( eventName, tick );
  }
};

// -------------------------- ignore & stamps -------------------------- //


/**
 * keep item in collection, but do not lay it out
 * ignored items do not get skipped in layout
 * @param {Element} elem
 */
Outlayer.prototype.ignore = function( elem ) {
  var item = this.getItem( elem );
  if ( item ) {
    item.isIgnored = true;
  }
};

/**
 * return item to layout collection
 * @param {Element} elem
 */
Outlayer.prototype.unignore = function( elem ) {
  var item = this.getItem( elem );
  if ( item ) {
    delete item.isIgnored;
  }
};

/**
 * adds elements to stamps
 * @param {NodeList, Array, Element, or String} elems
 */
Outlayer.prototype.stamp = function( elems ) {
  elems = this._find( elems );
  if ( !elems ) {
    return;
  }

  this.stamps = this.stamps.concat( elems );
  // ignore
  for ( var i=0, len = elems.length; i < len; i++ ) {
    var elem = elems[i];
    this.ignore( elem );
  }
};

/**
 * removes elements to stamps
 * @param {NodeList, Array, or Element} elems
 */
Outlayer.prototype.unstamp = function( elems ) {
  elems = this._find( elems );
  if ( !elems ){
    return;
  }

  for ( var i=0, len = elems.length; i < len; i++ ) {
    var elem = elems[i];
    // filter out removed stamp elements
    utils.removeFrom( this.stamps, elem );
    this.unignore( elem );
  }

};

/**
 * finds child elements
 * @param {NodeList, Array, Element, or String} elems
 * @returns {Array} elems
 */
Outlayer.prototype._find = function( elems ) {
  if ( !elems ) {
    return;
  }
  // if string, use argument as selector string
  if ( typeof elems === 'string' ) {
    elems = this.element.querySelectorAll( elems );
  }
  elems = utils.makeArray( elems );
  return elems;
};

Outlayer.prototype._manageStamps = function() {
  if ( !this.stamps || !this.stamps.length ) {
    return;
  }

  this._getBoundingRect();

  for ( var i=0, len = this.stamps.length; i < len; i++ ) {
    var stamp = this.stamps[i];
    this._manageStamp( stamp );
  }
};

// update boundingLeft / Top
Outlayer.prototype._getBoundingRect = function() {
  // get bounding rect for container element
  var boundingRect = this.element.getBoundingClientRect();
  var size = this.size;
  this._boundingRect = {
    left: boundingRect.left + size.paddingLeft + size.borderLeftWidth,
    top: boundingRect.top + size.paddingTop + size.borderTopWidth,
    right: boundingRect.right - ( size.paddingRight + size.borderRightWidth ),
    bottom: boundingRect.bottom - ( size.paddingBottom + size.borderBottomWidth )
  };
};

/**
 * @param {Element} stamp
**/
Outlayer.prototype._manageStamp = noop;

/**
 * get x/y position of element relative to container element
 * @param {Element} elem
 * @returns {Object} offset - has left, top, right, bottom
 */
Outlayer.prototype._getElementOffset = function( elem ) {
  var boundingRect = elem.getBoundingClientRect();
  var thisRect = this._boundingRect;
  var size = getSize( elem );
  var offset = {
    left: boundingRect.left - thisRect.left - size.marginLeft,
    top: boundingRect.top - thisRect.top - size.marginTop,
    right: thisRect.right - boundingRect.right - size.marginRight,
    bottom: thisRect.bottom - boundingRect.bottom - size.marginBottom
  };
  return offset;
};

// -------------------------- resize -------------------------- //

// enable event handlers for listeners
// i.e. resize -> onresize
Outlayer.prototype.handleEvent = function( event ) {
  var method = 'on' + event.type;
  if ( this[ method ] ) {
    this[ method ]( event );
  }
};

/**
 * Bind layout to window resizing
 */
Outlayer.prototype.bindResize = function() {
  // bind just one listener
  if ( this.isResizeBound ) {
    return;
  }
  eventie.bind( window, 'resize', this );
  this.isResizeBound = true;
};

/**
 * Unbind layout to window resizing
 */
Outlayer.prototype.unbindResize = function() {
  if ( this.isResizeBound ) {
    eventie.unbind( window, 'resize', this );
  }
  this.isResizeBound = false;
};

// original debounce by John Hann
// http://unscriptable.com/index.php/2009/03/20/debouncing-javascript-methods/

// this fires every resize
Outlayer.prototype.onresize = function() {
  if ( this.resizeTimeout ) {
    clearTimeout( this.resizeTimeout );
  }

  var _this = this;
  function delayed() {
    _this.resize();
    delete _this.resizeTimeout;
  }

  this.resizeTimeout = setTimeout( delayed, 100 );
};

// debounced, layout on resize
Outlayer.prototype.resize = function() {
  // don't trigger if size did not change
  // or if resize was unbound. See #9
  if ( !this.isResizeBound || !this.needsResizeLayout() ) {
    return;
  }

  this.layout();
};

/**
 * check if layout is needed post layout
 * @returns Boolean
 */
Outlayer.prototype.needsResizeLayout = function() {
  var size = getSize( this.element );
  // check that this.size and size are there
  // IE8 triggers resize on body size change, so they might not be
  var hasSizes = this.size && size;
  return hasSizes && size.innerWidth !== this.size.innerWidth;
};

// -------------------------- methods -------------------------- //

/**
 * add items to Outlayer instance
 * @param {Array or NodeList or Element} elems
 * @returns {Array} items - Outlayer.Items
**/
Outlayer.prototype.addItems = function( elems ) {
  var items = this._itemize( elems );
  // add items to collection
  if ( items.length ) {
    this.items = this.items.concat( items );
  }
  return items;
};

/**
 * Layout newly-appended item elements
 * @param {Array or NodeList or Element} elems
 */
Outlayer.prototype.appended = function( elems ) {
  var items = this.addItems( elems );
  if ( !items.length ) {
    return;
  }
  // layout and reveal just the new items
  this.layoutItems( items, true );
  this.reveal( items );
};

/**
 * Layout prepended elements
 * @param {Array or NodeList or Element} elems
 */
Outlayer.prototype.prepended = function( elems ) {
  var items = this._itemize( elems );
  if ( !items.length ) {
    return;
  }
  // add items to beginning of collection
  var previousItems = this.items.slice(0);
  this.items = items.concat( previousItems );
  // start new layout
  this._resetLayout();
  this._manageStamps();
  // layout new stuff without transition
  this.layoutItems( items, true );
  this.reveal( items );
  // layout previous items
  this.layoutItems( previousItems );
};

/**
 * reveal a collection of items
 * @param {Array of Outlayer.Items} items
 */
Outlayer.prototype.reveal = function( items ) {
  this._emitCompleteOnItems( 'reveal', items );

  var len = items && items.length;
  for ( var i=0; len && i < len; i++ ) {
    var item = items[i];
    item.reveal();
  }
};

/**
 * hide a collection of items
 * @param {Array of Outlayer.Items} items
 */
Outlayer.prototype.hide = function( items ) {
  this._emitCompleteOnItems( 'hide', items );

  var len = items && items.length;
  for ( var i=0; len && i < len; i++ ) {
    var item = items[i];
    item.hide();
  }
};

/**
 * reveal item elements
 * @param {Array}, {Element}, {NodeList} items
 */
Outlayer.prototype.revealItemElements = function( elems ) {
  var items = this.getItems( elems );
  this.reveal( items );
};

/**
 * hide item elements
 * @param {Array}, {Element}, {NodeList} items
 */
Outlayer.prototype.hideItemElements = function( elems ) {
  var items = this.getItems( elems );
  this.hide( items );
};

/**
 * get Outlayer.Item, given an Element
 * @param {Element} elem
 * @param {Function} callback
 * @returns {Outlayer.Item} item
 */
Outlayer.prototype.getItem = function( elem ) {
  // loop through items to get the one that matches
  for ( var i=0, len = this.items.length; i < len; i++ ) {
    var item = this.items[i];
    if ( item.element === elem ) {
      // return item
      return item;
    }
  }
};

/**
 * get collection of Outlayer.Items, given Elements
 * @param {Array} elems
 * @returns {Array} items - Outlayer.Items
 */
Outlayer.prototype.getItems = function( elems ) {
  elems = utils.makeArray( elems );
  var items = [];
  for ( var i=0, len = elems.length; i < len; i++ ) {
    var elem = elems[i];
    var item = this.getItem( elem );
    if ( item ) {
      items.push( item );
    }
  }

  return items;
};

/**
 * remove element(s) from instance and DOM
 * @param {Array or NodeList or Element} elems
 */
Outlayer.prototype.remove = function( elems ) {
  var removeItems = this.getItems( elems );

  this._emitCompleteOnItems( 'remove', removeItems );

  // bail if no items to remove
  if ( !removeItems || !removeItems.length ) {
    return;
  }

  for ( var i=0, len = removeItems.length; i < len; i++ ) {
    var item = removeItems[i];
    item.remove();
    // remove item from collection
    utils.removeFrom( this.items, item );
  }
};

// ----- destroy ----- //

// remove and disable Outlayer instance
Outlayer.prototype.destroy = function() {
  // clean up dynamic styles
  var style = this.element.style;
  style.height = '';
  style.position = '';
  style.width = '';
  // destroy items
  for ( var i=0, len = this.items.length; i < len; i++ ) {
    var item = this.items[i];
    item.destroy();
  }

  this.unbindResize();

  var id = this.element.outlayerGUID;
  delete instances[ id ]; // remove reference to instance by id
  delete this.element.outlayerGUID;
  // remove data for jQuery
  if ( jQuery ) {
    jQuery.removeData( this.element, this.constructor.namespace );
  }

};

// -------------------------- data -------------------------- //

/**
 * get Outlayer instance from element
 * @param {Element} elem
 * @returns {Outlayer}
 */
Outlayer.data = function( elem ) {
  elem = utils.getQueryElement( elem );
  var id = elem && elem.outlayerGUID;
  return id && instances[ id ];
};


// -------------------------- create Outlayer class -------------------------- //

/**
 * create a layout class
 * @param {String} namespace
 */
Outlayer.create = function( namespace, options ) {
  // sub-class Outlayer
  function Layout() {
    Outlayer.apply( this, arguments );
  }
  // inherit Outlayer prototype, use Object.create if there
  if ( Object.create ) {
    Layout.prototype = Object.create( Outlayer.prototype );
  } else {
    utils.extend( Layout.prototype, Outlayer.prototype );
  }
  // set contructor, used for namespace and Item
  Layout.prototype.constructor = Layout;

  Layout.defaults = utils.extend( {}, Outlayer.defaults );
  // apply new options
  utils.extend( Layout.defaults, options );
  // keep prototype.settings for backwards compatibility (Packery v1.2.0)
  Layout.prototype.settings = {};

  Layout.namespace = namespace;

  Layout.data = Outlayer.data;

  // sub-class Item
  Layout.Item = function LayoutItem() {
    Item.apply( this, arguments );
  };

  Layout.Item.prototype = new Item();

  // -------------------------- declarative -------------------------- //

  utils.htmlInit( Layout, namespace );

  // -------------------------- jQuery bridge -------------------------- //

  // make into jQuery plugin
  if ( jQuery && jQuery.bridget ) {
    jQuery.bridget( namespace, Layout );
  }

  return Layout;
};

// ----- fin ----- //

// back in global
Outlayer.Item = Item;

return Outlayer;

}));


/*!
 * Masonry v3.3.0
 * Cascading grid layout library
 * http://masonry.desandro.com
 * MIT License
 * by David DeSandro
 */

( function( window, factory ) {
  
  // universal module definition
  if ( typeof define === 'function' && define.amd ) {
    // AMD
    define( [
        'outlayer/outlayer',
        'get-size/get-size',
        'fizzy-ui-utils/utils'
      ],
      factory );
  } else if ( typeof exports === 'object' ) {
    // CommonJS
    module.exports = factory(
      require('outlayer'),
      require('get-size'),
      require('fizzy-ui-utils')
    );
  } else {
    // browser global
    window.Masonry = factory(
      window.Outlayer,
      window.getSize,
      window.fizzyUIUtils
    );
  }

}( window, function factory( Outlayer, getSize, utils ) {



// -------------------------- masonryDefinition -------------------------- //

  // create an Outlayer layout class
  var Masonry = Outlayer.create('masonry');

  Masonry.prototype._resetLayout = function() {
    this.getSize();
    this._getMeasurement( 'columnWidth', 'outerWidth' );
    this._getMeasurement( 'gutter', 'outerWidth' );
    this.measureColumns();

    // reset column Y
    var i = this.cols;
    this.colYs = [];
    while (i--) {
      this.colYs.push( 0 );
    }

    this.maxY = 0;
  };

  Masonry.prototype.measureColumns = function() {
    this.getContainerWidth();
    // if columnWidth is 0, default to outerWidth of first item
    if ( !this.columnWidth ) {
      var firstItem = this.items[0];
      var firstItemElem = firstItem && firstItem.element;
      // columnWidth fall back to item of first element
      this.columnWidth = firstItemElem && getSize( firstItemElem ).outerWidth ||
        // if first elem has no width, default to size of container
        this.containerWidth;
    }

    var columnWidth = this.columnWidth += this.gutter;

    // calculate columns
    var containerWidth = this.containerWidth + this.gutter;
    var cols = containerWidth / columnWidth;
    // fix rounding errors, typically with gutters
    var excess = columnWidth - containerWidth % columnWidth;
    // if overshoot is less than a pixel, round up, otherwise floor it
    var mathMethod = excess && excess < 1 ? 'round' : 'floor';
    cols = Math[ mathMethod ]( cols );
    this.cols = Math.max( cols, 1 );
  };

  Masonry.prototype.getContainerWidth = function() {
    // container is parent if fit width
    var container = this.options.isFitWidth ? this.element.parentNode : this.element;
    // check that this.size and size are there
    // IE8 triggers resize on body size change, so they might not be
    var size = getSize( container );
    this.containerWidth = size && size.innerWidth;
  };

  Masonry.prototype._getItemLayoutPosition = function( item ) {
    item.getSize();
    // how many columns does this brick span
    var remainder = item.size.outerWidth % this.columnWidth;
    var mathMethod = remainder && remainder < 1 ? 'round' : 'ceil';
    // round if off by 1 pixel, otherwise use ceil
    var colSpan = Math[ mathMethod ]( item.size.outerWidth / this.columnWidth );
    colSpan = Math.min( colSpan, this.cols );

    var colGroup = this._getColGroup( colSpan );
    // get the minimum Y value from the columns
    var minimumY = Math.min.apply( Math, colGroup );
    var shortColIndex = utils.indexOf( colGroup, minimumY );

    // position the brick
    var position = {
      x: this.columnWidth * shortColIndex,
      y: minimumY
    };

    // apply setHeight to necessary columns
    var setHeight = minimumY + item.size.outerHeight;
    var setSpan = this.cols + 1 - colGroup.length;
    for ( var i = 0; i < setSpan; i++ ) {
      this.colYs[ shortColIndex + i ] = setHeight;
    }

    return position;
  };

  /**
   * @param {Number} colSpan - number of columns the element spans
   * @returns {Array} colGroup
   */
  Masonry.prototype._getColGroup = function( colSpan ) {
    if ( colSpan < 2 ) {
      // if brick spans only one column, use all the column Ys
      return this.colYs;
    }

    var colGroup = [];
    // how many different places could this brick fit horizontally
    var groupCount = this.cols + 1 - colSpan;
    // for each group potential horizontal position
    for ( var i = 0; i < groupCount; i++ ) {
      // make an array of colY values for that one group
      var groupColYs = this.colYs.slice( i, i + colSpan );
      // and get the max value of the array
      colGroup[i] = Math.max.apply( Math, groupColYs );
    }
    return colGroup;
  };

  Masonry.prototype._manageStamp = function( stamp ) {
    var stampSize = getSize( stamp );
    var offset = this._getElementOffset( stamp );
    // get the columns that this stamp affects
    var firstX = this.options.isOriginLeft ? offset.left : offset.right;
    var lastX = firstX + stampSize.outerWidth;
    var firstCol = Math.floor( firstX / this.columnWidth );
    firstCol = Math.max( 0, firstCol );
    var lastCol = Math.floor( lastX / this.columnWidth );
    // lastCol should not go over if multiple of columnWidth #425
    lastCol -= lastX % this.columnWidth ? 0 : 1;
    lastCol = Math.min( this.cols - 1, lastCol );
    // set colYs to bottom of the stamp
    var stampMaxY = ( this.options.isOriginTop ? offset.top : offset.bottom ) +
      stampSize.outerHeight;
    for ( var i = firstCol; i <= lastCol; i++ ) {
      this.colYs[i] = Math.max( stampMaxY, this.colYs[i] );
    }
  };

  Masonry.prototype._getContainerSize = function() {
    this.maxY = Math.max.apply( Math, this.colYs );
    var size = {
      height: this.maxY
    };

    if ( this.options.isFitWidth ) {
      size.width = this._getContainerFitWidth();
    }

    return size;
  };

  Masonry.prototype._getContainerFitWidth = function() {
    var unusedCols = 0;
    // count unused columns
    var i = this.cols;
    while ( --i ) {
      if ( this.colYs[i] !== 0 ) {
        break;
      }
      unusedCols++;
    }
    // fit container to columns that have been used
    return ( this.cols - unusedCols ) * this.columnWidth - this.gutter;
  };

  Masonry.prototype.needsResizeLayout = function() {
    var previousWidth = this.containerWidth;
    this.getContainerWidth();
    return previousWidth !== this.containerWidth;
  };

  return Masonry;

}));

/*! Hammer.JS - v2.0.4 - 2014-09-28
 * http://hammerjs.github.io/
 *
 * Copyright (c) 2014 Jorik Tangelder;
 * Licensed under the MIT license */
!function(a,b,c,d){"use strict";function e(a,b,c){return setTimeout(k(a,c),b)}function f(a,b,c){return Array.isArray(a)?(g(a,c[b],c),!0):!1}function g(a,b,c){var e;if(a)if(a.forEach)a.forEach(b,c);else if(a.length!==d)for(e=0;e<a.length;)b.call(c,a[e],e,a),e++;else for(e in a)a.hasOwnProperty(e)&&b.call(c,a[e],e,a)}function h(a,b,c){for(var e=Object.keys(b),f=0;f<e.length;)(!c||c&&a[e[f]]===d)&&(a[e[f]]=b[e[f]]),f++;return a}function i(a,b){return h(a,b,!0)}function j(a,b,c){var d,e=b.prototype;d=a.prototype=Object.create(e),d.constructor=a,d._super=e,c&&h(d,c)}function k(a,b){return function(){return a.apply(b,arguments)}}function l(a,b){return typeof a==kb?a.apply(b?b[0]||d:d,b):a}function m(a,b){return a===d?b:a}function n(a,b,c){g(r(b),function(b){a.addEventListener(b,c,!1)})}function o(a,b,c){g(r(b),function(b){a.removeEventListener(b,c,!1)})}function p(a,b){for(;a;){if(a==b)return!0;a=a.parentNode}return!1}function q(a,b){return a.indexOf(b)>-1}function r(a){return a.trim().split(/\s+/g)}function s(a,b,c){if(a.indexOf&&!c)return a.indexOf(b);for(var d=0;d<a.length;){if(c&&a[d][c]==b||!c&&a[d]===b)return d;d++}return-1}function t(a){return Array.prototype.slice.call(a,0)}function u(a,b,c){for(var d=[],e=[],f=0;f<a.length;){var g=b?a[f][b]:a[f];s(e,g)<0&&d.push(a[f]),e[f]=g,f++}return c&&(d=b?d.sort(function(a,c){return a[b]>c[b]}):d.sort()),d}function v(a,b){for(var c,e,f=b[0].toUpperCase()+b.slice(1),g=0;g<ib.length;){if(c=ib[g],e=c?c+f:b,e in a)return e;g++}return d}function w(){return ob++}function x(a){var b=a.ownerDocument;return b.defaultView||b.parentWindow}function y(a,b){var c=this;this.manager=a,this.callback=b,this.element=a.element,this.target=a.options.inputTarget,this.domHandler=function(b){l(a.options.enable,[a])&&c.handler(b)},this.init()}function z(a){var b,c=a.options.inputClass;return new(b=c?c:rb?N:sb?Q:qb?S:M)(a,A)}function A(a,b,c){var d=c.pointers.length,e=c.changedPointers.length,f=b&yb&&d-e===0,g=b&(Ab|Bb)&&d-e===0;c.isFirst=!!f,c.isFinal=!!g,f&&(a.session={}),c.eventType=b,B(a,c),a.emit("hammer.input",c),a.recognize(c),a.session.prevInput=c}function B(a,b){var c=a.session,d=b.pointers,e=d.length;c.firstInput||(c.firstInput=E(b)),e>1&&!c.firstMultiple?c.firstMultiple=E(b):1===e&&(c.firstMultiple=!1);var f=c.firstInput,g=c.firstMultiple,h=g?g.center:f.center,i=b.center=F(d);b.timeStamp=nb(),b.deltaTime=b.timeStamp-f.timeStamp,b.angle=J(h,i),b.distance=I(h,i),C(c,b),b.offsetDirection=H(b.deltaX,b.deltaY),b.scale=g?L(g.pointers,d):1,b.rotation=g?K(g.pointers,d):0,D(c,b);var j=a.element;p(b.srcEvent.target,j)&&(j=b.srcEvent.target),b.target=j}function C(a,b){var c=b.center,d=a.offsetDelta||{},e=a.prevDelta||{},f=a.prevInput||{};(b.eventType===yb||f.eventType===Ab)&&(e=a.prevDelta={x:f.deltaX||0,y:f.deltaY||0},d=a.offsetDelta={x:c.x,y:c.y}),b.deltaX=e.x+(c.x-d.x),b.deltaY=e.y+(c.y-d.y)}function D(a,b){var c,e,f,g,h=a.lastInterval||b,i=b.timeStamp-h.timeStamp;if(b.eventType!=Bb&&(i>xb||h.velocity===d)){var j=h.deltaX-b.deltaX,k=h.deltaY-b.deltaY,l=G(i,j,k);e=l.x,f=l.y,c=mb(l.x)>mb(l.y)?l.x:l.y,g=H(j,k),a.lastInterval=b}else c=h.velocity,e=h.velocityX,f=h.velocityY,g=h.direction;b.velocity=c,b.velocityX=e,b.velocityY=f,b.direction=g}function E(a){for(var b=[],c=0;c<a.pointers.length;)b[c]={clientX:lb(a.pointers[c].clientX),clientY:lb(a.pointers[c].clientY)},c++;return{timeStamp:nb(),pointers:b,center:F(b),deltaX:a.deltaX,deltaY:a.deltaY}}function F(a){var b=a.length;if(1===b)return{x:lb(a[0].clientX),y:lb(a[0].clientY)};for(var c=0,d=0,e=0;b>e;)c+=a[e].clientX,d+=a[e].clientY,e++;return{x:lb(c/b),y:lb(d/b)}}function G(a,b,c){return{x:b/a||0,y:c/a||0}}function H(a,b){return a===b?Cb:mb(a)>=mb(b)?a>0?Db:Eb:b>0?Fb:Gb}function I(a,b,c){c||(c=Kb);var d=b[c[0]]-a[c[0]],e=b[c[1]]-a[c[1]];return Math.sqrt(d*d+e*e)}function J(a,b,c){c||(c=Kb);var d=b[c[0]]-a[c[0]],e=b[c[1]]-a[c[1]];return 180*Math.atan2(e,d)/Math.PI}function K(a,b){return J(b[1],b[0],Lb)-J(a[1],a[0],Lb)}function L(a,b){return I(b[0],b[1],Lb)/I(a[0],a[1],Lb)}function M(){this.evEl=Nb,this.evWin=Ob,this.allow=!0,this.pressed=!1,y.apply(this,arguments)}function N(){this.evEl=Rb,this.evWin=Sb,y.apply(this,arguments),this.store=this.manager.session.pointerEvents=[]}function O(){this.evTarget=Ub,this.evWin=Vb,this.started=!1,y.apply(this,arguments)}function P(a,b){var c=t(a.touches),d=t(a.changedTouches);return b&(Ab|Bb)&&(c=u(c.concat(d),"identifier",!0)),[c,d]}function Q(){this.evTarget=Xb,this.targetIds={},y.apply(this,arguments)}function R(a,b){var c=t(a.touches),d=this.targetIds;if(b&(yb|zb)&&1===c.length)return d[c[0].identifier]=!0,[c,c];var e,f,g=t(a.changedTouches),h=[],i=this.target;if(f=c.filter(function(a){return p(a.target,i)}),b===yb)for(e=0;e<f.length;)d[f[e].identifier]=!0,e++;for(e=0;e<g.length;)d[g[e].identifier]&&h.push(g[e]),b&(Ab|Bb)&&delete d[g[e].identifier],e++;return h.length?[u(f.concat(h),"identifier",!0),h]:void 0}function S(){y.apply(this,arguments);var a=k(this.handler,this);this.touch=new Q(this.manager,a),this.mouse=new M(this.manager,a)}function T(a,b){this.manager=a,this.set(b)}function U(a){if(q(a,bc))return bc;var b=q(a,cc),c=q(a,dc);return b&&c?cc+" "+dc:b||c?b?cc:dc:q(a,ac)?ac:_b}function V(a){this.id=w(),this.manager=null,this.options=i(a||{},this.defaults),this.options.enable=m(this.options.enable,!0),this.state=ec,this.simultaneous={},this.requireFail=[]}function W(a){return a&jc?"cancel":a&hc?"end":a&gc?"move":a&fc?"start":""}function X(a){return a==Gb?"down":a==Fb?"up":a==Db?"left":a==Eb?"right":""}function Y(a,b){var c=b.manager;return c?c.get(a):a}function Z(){V.apply(this,arguments)}function $(){Z.apply(this,arguments),this.pX=null,this.pY=null}function _(){Z.apply(this,arguments)}function ab(){V.apply(this,arguments),this._timer=null,this._input=null}function bb(){Z.apply(this,arguments)}function cb(){Z.apply(this,arguments)}function db(){V.apply(this,arguments),this.pTime=!1,this.pCenter=!1,this._timer=null,this._input=null,this.count=0}function eb(a,b){return b=b||{},b.recognizers=m(b.recognizers,eb.defaults.preset),new fb(a,b)}function fb(a,b){b=b||{},this.options=i(b,eb.defaults),this.options.inputTarget=this.options.inputTarget||a,this.handlers={},this.session={},this.recognizers=[],this.element=a,this.input=z(this),this.touchAction=new T(this,this.options.touchAction),gb(this,!0),g(b.recognizers,function(a){var b=this.add(new a[0](a[1]));a[2]&&b.recognizeWith(a[2]),a[3]&&b.requireFailure(a[3])},this)}function gb(a,b){var c=a.element;g(a.options.cssProps,function(a,d){c.style[v(c.style,d)]=b?a:""})}function hb(a,c){var d=b.createEvent("Event");d.initEvent(a,!0,!0),d.gesture=c,c.target.dispatchEvent(d)}var ib=["","webkit","moz","MS","ms","o"],jb=b.createElement("div"),kb="function",lb=Math.round,mb=Math.abs,nb=Date.now,ob=1,pb=/mobile|tablet|ip(ad|hone|od)|android/i,qb="ontouchstart"in a,rb=v(a,"PointerEvent")!==d,sb=qb&&pb.test(navigator.userAgent),tb="touch",ub="pen",vb="mouse",wb="kinect",xb=25,yb=1,zb=2,Ab=4,Bb=8,Cb=1,Db=2,Eb=4,Fb=8,Gb=16,Hb=Db|Eb,Ib=Fb|Gb,Jb=Hb|Ib,Kb=["x","y"],Lb=["clientX","clientY"];y.prototype={handler:function(){},init:function(){this.evEl&&n(this.element,this.evEl,this.domHandler),this.evTarget&&n(this.target,this.evTarget,this.domHandler),this.evWin&&n(x(this.element),this.evWin,this.domHandler)},destroy:function(){this.evEl&&o(this.element,this.evEl,this.domHandler),this.evTarget&&o(this.target,this.evTarget,this.domHandler),this.evWin&&o(x(this.element),this.evWin,this.domHandler)}};var Mb={mousedown:yb,mousemove:zb,mouseup:Ab},Nb="mousedown",Ob="mousemove mouseup";j(M,y,{handler:function(a){var b=Mb[a.type];b&yb&&0===a.button&&(this.pressed=!0),b&zb&&1!==a.which&&(b=Ab),this.pressed&&this.allow&&(b&Ab&&(this.pressed=!1),this.callback(this.manager,b,{pointers:[a],changedPointers:[a],pointerType:vb,srcEvent:a}))}});var Pb={pointerdown:yb,pointermove:zb,pointerup:Ab,pointercancel:Bb,pointerout:Bb},Qb={2:tb,3:ub,4:vb,5:wb},Rb="pointerdown",Sb="pointermove pointerup pointercancel";a.MSPointerEvent&&(Rb="MSPointerDown",Sb="MSPointerMove MSPointerUp MSPointerCancel"),j(N,y,{handler:function(a){var b=this.store,c=!1,d=a.type.toLowerCase().replace("ms",""),e=Pb[d],f=Qb[a.pointerType]||a.pointerType,g=f==tb,h=s(b,a.pointerId,"pointerId");e&yb&&(0===a.button||g)?0>h&&(b.push(a),h=b.length-1):e&(Ab|Bb)&&(c=!0),0>h||(b[h]=a,this.callback(this.manager,e,{pointers:b,changedPointers:[a],pointerType:f,srcEvent:a}),c&&b.splice(h,1))}});var Tb={touchstart:yb,touchmove:zb,touchend:Ab,touchcancel:Bb},Ub="touchstart",Vb="touchstart touchmove touchend touchcancel";j(O,y,{handler:function(a){var b=Tb[a.type];if(b===yb&&(this.started=!0),this.started){var c=P.call(this,a,b);b&(Ab|Bb)&&c[0].length-c[1].length===0&&(this.started=!1),this.callback(this.manager,b,{pointers:c[0],changedPointers:c[1],pointerType:tb,srcEvent:a})}}});var Wb={touchstart:yb,touchmove:zb,touchend:Ab,touchcancel:Bb},Xb="touchstart touchmove touchend touchcancel";j(Q,y,{handler:function(a){var b=Wb[a.type],c=R.call(this,a,b);c&&this.callback(this.manager,b,{pointers:c[0],changedPointers:c[1],pointerType:tb,srcEvent:a})}}),j(S,y,{handler:function(a,b,c){var d=c.pointerType==tb,e=c.pointerType==vb;if(d)this.mouse.allow=!1;else if(e&&!this.mouse.allow)return;b&(Ab|Bb)&&(this.mouse.allow=!0),this.callback(a,b,c)},destroy:function(){this.touch.destroy(),this.mouse.destroy()}});var Yb=v(jb.style,"touchAction"),Zb=Yb!==d,$b="compute",_b="auto",ac="manipulation",bc="none",cc="pan-x",dc="pan-y";T.prototype={set:function(a){a==$b&&(a=this.compute()),Zb&&(this.manager.element.style[Yb]=a),this.actions=a.toLowerCase().trim()},update:function(){this.set(this.manager.options.touchAction)},compute:function(){var a=[];return g(this.manager.recognizers,function(b){l(b.options.enable,[b])&&(a=a.concat(b.getTouchAction()))}),U(a.join(" "))},preventDefaults:function(a){if(!Zb){var b=a.srcEvent,c=a.offsetDirection;if(this.manager.session.prevented)return void b.preventDefault();var d=this.actions,e=q(d,bc),f=q(d,dc),g=q(d,cc);return e||f&&c&Hb||g&&c&Ib?this.preventSrc(b):void 0}},preventSrc:function(a){this.manager.session.prevented=!0,a.preventDefault()}};var ec=1,fc=2,gc=4,hc=8,ic=hc,jc=16,kc=32;V.prototype={defaults:{},set:function(a){return h(this.options,a),this.manager&&this.manager.touchAction.update(),this},recognizeWith:function(a){if(f(a,"recognizeWith",this))return this;var b=this.simultaneous;return a=Y(a,this),b[a.id]||(b[a.id]=a,a.recognizeWith(this)),this},dropRecognizeWith:function(a){return f(a,"dropRecognizeWith",this)?this:(a=Y(a,this),delete this.simultaneous[a.id],this)},requireFailure:function(a){if(f(a,"requireFailure",this))return this;var b=this.requireFail;return a=Y(a,this),-1===s(b,a)&&(b.push(a),a.requireFailure(this)),this},dropRequireFailure:function(a){if(f(a,"dropRequireFailure",this))return this;a=Y(a,this);var b=s(this.requireFail,a);return b>-1&&this.requireFail.splice(b,1),this},hasRequireFailures:function(){return this.requireFail.length>0},canRecognizeWith:function(a){return!!this.simultaneous[a.id]},emit:function(a){function b(b){c.manager.emit(c.options.event+(b?W(d):""),a)}var c=this,d=this.state;hc>d&&b(!0),b(),d>=hc&&b(!0)},tryEmit:function(a){return this.canEmit()?this.emit(a):void(this.state=kc)},canEmit:function(){for(var a=0;a<this.requireFail.length;){if(!(this.requireFail[a].state&(kc|ec)))return!1;a++}return!0},recognize:function(a){var b=h({},a);return l(this.options.enable,[this,b])?(this.state&(ic|jc|kc)&&(this.state=ec),this.state=this.process(b),void(this.state&(fc|gc|hc|jc)&&this.tryEmit(b))):(this.reset(),void(this.state=kc))},process:function(){},getTouchAction:function(){},reset:function(){}},j(Z,V,{defaults:{pointers:1},attrTest:function(a){var b=this.options.pointers;return 0===b||a.pointers.length===b},process:function(a){var b=this.state,c=a.eventType,d=b&(fc|gc),e=this.attrTest(a);return d&&(c&Bb||!e)?b|jc:d||e?c&Ab?b|hc:b&fc?b|gc:fc:kc}}),j($,Z,{defaults:{event:"pan",threshold:10,pointers:1,direction:Jb},getTouchAction:function(){var a=this.options.direction,b=[];return a&Hb&&b.push(dc),a&Ib&&b.push(cc),b},directionTest:function(a){var b=this.options,c=!0,d=a.distance,e=a.direction,f=a.deltaX,g=a.deltaY;return e&b.direction||(b.direction&Hb?(e=0===f?Cb:0>f?Db:Eb,c=f!=this.pX,d=Math.abs(a.deltaX)):(e=0===g?Cb:0>g?Fb:Gb,c=g!=this.pY,d=Math.abs(a.deltaY))),a.direction=e,c&&d>b.threshold&&e&b.direction},attrTest:function(a){return Z.prototype.attrTest.call(this,a)&&(this.state&fc||!(this.state&fc)&&this.directionTest(a))},emit:function(a){this.pX=a.deltaX,this.pY=a.deltaY;var b=X(a.direction);b&&this.manager.emit(this.options.event+b,a),this._super.emit.call(this,a)}}),j(_,Z,{defaults:{event:"pinch",threshold:0,pointers:2},getTouchAction:function(){return[bc]},attrTest:function(a){return this._super.attrTest.call(this,a)&&(Math.abs(a.scale-1)>this.options.threshold||this.state&fc)},emit:function(a){if(this._super.emit.call(this,a),1!==a.scale){var b=a.scale<1?"in":"out";this.manager.emit(this.options.event+b,a)}}}),j(ab,V,{defaults:{event:"press",pointers:1,time:500,threshold:5},getTouchAction:function(){return[_b]},process:function(a){var b=this.options,c=a.pointers.length===b.pointers,d=a.distance<b.threshold,f=a.deltaTime>b.time;if(this._input=a,!d||!c||a.eventType&(Ab|Bb)&&!f)this.reset();else if(a.eventType&yb)this.reset(),this._timer=e(function(){this.state=ic,this.tryEmit()},b.time,this);else if(a.eventType&Ab)return ic;return kc},reset:function(){clearTimeout(this._timer)},emit:function(a){this.state===ic&&(a&&a.eventType&Ab?this.manager.emit(this.options.event+"up",a):(this._input.timeStamp=nb(),this.manager.emit(this.options.event,this._input)))}}),j(bb,Z,{defaults:{event:"rotate",threshold:0,pointers:2},getTouchAction:function(){return[bc]},attrTest:function(a){return this._super.attrTest.call(this,a)&&(Math.abs(a.rotation)>this.options.threshold||this.state&fc)}}),j(cb,Z,{defaults:{event:"swipe",threshold:10,velocity:.65,direction:Hb|Ib,pointers:1},getTouchAction:function(){return $.prototype.getTouchAction.call(this)},attrTest:function(a){var b,c=this.options.direction;return c&(Hb|Ib)?b=a.velocity:c&Hb?b=a.velocityX:c&Ib&&(b=a.velocityY),this._super.attrTest.call(this,a)&&c&a.direction&&a.distance>this.options.threshold&&mb(b)>this.options.velocity&&a.eventType&Ab},emit:function(a){var b=X(a.direction);b&&this.manager.emit(this.options.event+b,a),this.manager.emit(this.options.event,a)}}),j(db,V,{defaults:{event:"tap",pointers:1,taps:1,interval:300,time:250,threshold:2,posThreshold:10},getTouchAction:function(){return[ac]},process:function(a){var b=this.options,c=a.pointers.length===b.pointers,d=a.distance<b.threshold,f=a.deltaTime<b.time;if(this.reset(),a.eventType&yb&&0===this.count)return this.failTimeout();if(d&&f&&c){if(a.eventType!=Ab)return this.failTimeout();var g=this.pTime?a.timeStamp-this.pTime<b.interval:!0,h=!this.pCenter||I(this.pCenter,a.center)<b.posThreshold;this.pTime=a.timeStamp,this.pCenter=a.center,h&&g?this.count+=1:this.count=1,this._input=a;var i=this.count%b.taps;if(0===i)return this.hasRequireFailures()?(this._timer=e(function(){this.state=ic,this.tryEmit()},b.interval,this),fc):ic}return kc},failTimeout:function(){return this._timer=e(function(){this.state=kc},this.options.interval,this),kc},reset:function(){clearTimeout(this._timer)},emit:function(){this.state==ic&&(this._input.tapCount=this.count,this.manager.emit(this.options.event,this._input))}}),eb.VERSION="2.0.4",eb.defaults={domEvents:!1,touchAction:$b,enable:!0,inputTarget:null,inputClass:null,preset:[[bb,{enable:!1}],[_,{enable:!1},["rotate"]],[cb,{direction:Hb}],[$,{direction:Hb},["swipe"]],[db],[db,{event:"doubletap",taps:2},["tap"]],[ab]],cssProps:{userSelect:"none",touchSelect:"none",touchCallout:"none",contentZooming:"none",userDrag:"none",tapHighlightColor:"rgba(0,0,0,0)"}};var lc=1,mc=2;fb.prototype={set:function(a){return h(this.options,a),a.touchAction&&this.touchAction.update(),a.inputTarget&&(this.input.destroy(),this.input.target=a.inputTarget,this.input.init()),this},stop:function(a){this.session.stopped=a?mc:lc},recognize:function(a){var b=this.session;if(!b.stopped){this.touchAction.preventDefaults(a);var c,d=this.recognizers,e=b.curRecognizer;(!e||e&&e.state&ic)&&(e=b.curRecognizer=null);for(var f=0;f<d.length;)c=d[f],b.stopped===mc||e&&c!=e&&!c.canRecognizeWith(e)?c.reset():c.recognize(a),!e&&c.state&(fc|gc|hc)&&(e=b.curRecognizer=c),f++}},get:function(a){if(a instanceof V)return a;for(var b=this.recognizers,c=0;c<b.length;c++)if(b[c].options.event==a)return b[c];return null},add:function(a){if(f(a,"add",this))return this;var b=this.get(a.options.event);return b&&this.remove(b),this.recognizers.push(a),a.manager=this,this.touchAction.update(),a},remove:function(a){if(f(a,"remove",this))return this;var b=this.recognizers;return a=this.get(a),b.splice(s(b,a),1),this.touchAction.update(),this},on:function(a,b){var c=this.handlers;return g(r(a),function(a){c[a]=c[a]||[],c[a].push(b)}),this},off:function(a,b){var c=this.handlers;return g(r(a),function(a){b?c[a].splice(s(c[a],b),1):delete c[a]}),this},emit:function(a,b){this.options.domEvents&&hb(a,b);var c=this.handlers[a]&&this.handlers[a].slice();if(c&&c.length){b.type=a,b.preventDefault=function(){b.srcEvent.preventDefault()};for(var d=0;d<c.length;)c[d](b),d++}},destroy:function(){this.element&&gb(this,!1),this.handlers={},this.session={},this.input.destroy(),this.element=null}},h(eb,{INPUT_START:yb,INPUT_MOVE:zb,INPUT_END:Ab,INPUT_CANCEL:Bb,STATE_POSSIBLE:ec,STATE_BEGAN:fc,STATE_CHANGED:gc,STATE_ENDED:hc,STATE_RECOGNIZED:ic,STATE_CANCELLED:jc,STATE_FAILED:kc,DIRECTION_NONE:Cb,DIRECTION_LEFT:Db,DIRECTION_RIGHT:Eb,DIRECTION_UP:Fb,DIRECTION_DOWN:Gb,DIRECTION_HORIZONTAL:Hb,DIRECTION_VERTICAL:Ib,DIRECTION_ALL:Jb,Manager:fb,Input:y,TouchAction:T,TouchInput:Q,MouseInput:M,PointerEventInput:N,TouchMouseInput:S,SingleTouchInput:O,Recognizer:V,AttrRecognizer:Z,Tap:db,Pan:$,Swipe:cb,Pinch:_,Rotate:bb,Press:ab,on:n,off:o,each:g,merge:i,extend:h,inherit:j,bindFn:k,prefixed:v}),typeof define==kb&&define.amd?define(function(){return eb}):"undefined"!=typeof module&&module.exports?module.exports=eb:a[c]=eb}(window,document,"Hammer");


/*!
 * imagesLoaded PACKAGED v3.1.8
 * JavaScript is all like "You images are done yet or what?"
 * MIT License
 */

(function(){function e(){}function t(e,t){for(var n=e.length;n--;)if(e[n].listener===t)return n;return-1}function n(e){return function(){return this[e].apply(this,arguments)}}var i=e.prototype,r=this,o=r.EventEmitter;i.getListeners=function(e){var t,n,i=this._getEvents();if("object"==typeof e){t={};for(n in i)i.hasOwnProperty(n)&&e.test(n)&&(t[n]=i[n])}else t=i[e]||(i[e]=[]);return t},i.flattenListeners=function(e){var t,n=[];for(t=0;e.length>t;t+=1)n.push(e[t].listener);return n},i.getListenersAsObject=function(e){var t,n=this.getListeners(e);return n instanceof Array&&(t={},t[e]=n),t||n},i.addListener=function(e,n){var i,r=this.getListenersAsObject(e),o="object"==typeof n;for(i in r)r.hasOwnProperty(i)&&-1===t(r[i],n)&&r[i].push(o?n:{listener:n,once:!1});return this},i.on=n("addListener"),i.addOnceListener=function(e,t){return this.addListener(e,{listener:t,once:!0})},i.once=n("addOnceListener"),i.defineEvent=function(e){return this.getListeners(e),this},i.defineEvents=function(e){for(var t=0;e.length>t;t+=1)this.defineEvent(e[t]);return this},i.removeListener=function(e,n){var i,r,o=this.getListenersAsObject(e);for(r in o)o.hasOwnProperty(r)&&(i=t(o[r],n),-1!==i&&o[r].splice(i,1));return this},i.off=n("removeListener"),i.addListeners=function(e,t){return this.manipulateListeners(!1,e,t)},i.removeListeners=function(e,t){return this.manipulateListeners(!0,e,t)},i.manipulateListeners=function(e,t,n){var i,r,o=e?this.removeListener:this.addListener,s=e?this.removeListeners:this.addListeners;if("object"!=typeof t||t instanceof RegExp)for(i=n.length;i--;)o.call(this,t,n[i]);else for(i in t)t.hasOwnProperty(i)&&(r=t[i])&&("function"==typeof r?o.call(this,i,r):s.call(this,i,r));return this},i.removeEvent=function(e){var t,n=typeof e,i=this._getEvents();if("string"===n)delete i[e];else if("object"===n)for(t in i)i.hasOwnProperty(t)&&e.test(t)&&delete i[t];else delete this._events;return this},i.removeAllListeners=n("removeEvent"),i.emitEvent=function(e,t){var n,i,r,o,s=this.getListenersAsObject(e);for(r in s)if(s.hasOwnProperty(r))for(i=s[r].length;i--;)n=s[r][i],n.once===!0&&this.removeListener(e,n.listener),o=n.listener.apply(this,t||[]),o===this._getOnceReturnValue()&&this.removeListener(e,n.listener);return this},i.trigger=n("emitEvent"),i.emit=function(e){var t=Array.prototype.slice.call(arguments,1);return this.emitEvent(e,t)},i.setOnceReturnValue=function(e){return this._onceReturnValue=e,this},i._getOnceReturnValue=function(){return this.hasOwnProperty("_onceReturnValue")?this._onceReturnValue:!0},i._getEvents=function(){return this._events||(this._events={})},e.noConflict=function(){return r.EventEmitter=o,e},"function"==typeof define&&define.amd?define("eventEmitter/EventEmitter",[],function(){return e}):"object"==typeof module&&module.exports?module.exports=e:this.EventEmitter=e}).call(this),function(e){function t(t){var n=e.event;return n.target=n.target||n.srcElement||t,n}var n=document.documentElement,i=function(){};n.addEventListener?i=function(e,t,n){e.addEventListener(t,n,!1)}:n.attachEvent&&(i=function(e,n,i){e[n+i]=i.handleEvent?function(){var n=t(e);i.handleEvent.call(i,n)}:function(){var n=t(e);i.call(e,n)},e.attachEvent("on"+n,e[n+i])});var r=function(){};n.removeEventListener?r=function(e,t,n){e.removeEventListener(t,n,!1)}:n.detachEvent&&(r=function(e,t,n){e.detachEvent("on"+t,e[t+n]);try{delete e[t+n]}catch(i){e[t+n]=void 0}});var o={bind:i,unbind:r};"function"==typeof define&&define.amd?define("eventie/eventie",o):e.eventie=o}(this),function(e,t){"function"==typeof define&&define.amd?define(["eventEmitter/EventEmitter","eventie/eventie"],function(n,i){return t(e,n,i)}):"object"==typeof exports?module.exports=t(e,require("wolfy87-eventemitter"),require("eventie")):e.imagesLoaded=t(e,e.EventEmitter,e.eventie)}(window,function(e,t,n){function i(e,t){for(var n in t)e[n]=t[n];return e}function r(e){return"[object Array]"===d.call(e)}function o(e){var t=[];if(r(e))t=e;else if("number"==typeof e.length)for(var n=0,i=e.length;i>n;n++)t.push(e[n]);else t.push(e);return t}function s(e,t,n){if(!(this instanceof s))return new s(e,t);"string"==typeof e&&(e=document.querySelectorAll(e)),this.elements=o(e),this.options=i({},this.options),"function"==typeof t?n=t:i(this.options,t),n&&this.on("always",n),this.getImages(),a&&(this.jqDeferred=new a.Deferred);var r=this;setTimeout(function(){r.check()})}function f(e){this.img=e}function c(e){this.src=e,v[e]=this}var a=e.gallery_jQuery,u=e.console,h=u!==void 0,d=Object.prototype.toString;s.prototype=new t,s.prototype.options={},s.prototype.getImages=function(){this.images=[];for(var e=0,t=this.elements.length;t>e;e++){var n=this.elements[e];"IMG"===n.nodeName&&this.addImage(n);var i=n.nodeType;if(i&&(1===i||9===i||11===i))for(var r=n.querySelectorAll("img"),o=0,s=r.length;s>o;o++){var f=r[o];this.addImage(f)}}},s.prototype.addImage=function(e){var t=new f(e);this.images.push(t)},s.prototype.check=function(){function e(e,r){return t.options.debug&&h&&u.log("confirm",e,r),t.progress(e),n++,n===i&&t.complete(),!0}var t=this,n=0,i=this.images.length;if(this.hasAnyBroken=!1,!i)return this.complete(),void 0;for(var r=0;i>r;r++){var o=this.images[r];o.on("confirm",e),o.check()}},s.prototype.progress=function(e){this.hasAnyBroken=this.hasAnyBroken||!e.isLoaded;var t=this;setTimeout(function(){t.emit("progress",t,e),t.jqDeferred&&t.jqDeferred.notify&&t.jqDeferred.notify(t,e)})},s.prototype.complete=function(){var e=this.hasAnyBroken?"fail":"done";this.isComplete=!0;var t=this;setTimeout(function(){if(t.emit(e,t),t.emit("always",t),t.jqDeferred){var n=t.hasAnyBroken?"reject":"resolve";t.jqDeferred[n](t)}})},a&&(a.fn.imagesLoaded=function(e,t){var n=new s(this,e,t);return n.jqDeferred.promise(a(this))}),f.prototype=new t,f.prototype.check=function(){var e=v[this.img.src]||new c(this.img.src);if(e.isConfirmed)return this.confirm(e.isLoaded,"cached was confirmed"),void 0;if(this.img.complete&&void 0!==this.img.naturalWidth)return this.confirm(0!==this.img.naturalWidth,"naturalWidth"),void 0;var t=this;e.on("confirm",function(e,n){return t.confirm(e.isLoaded,n),!0}),e.check()},f.prototype.confirm=function(e,t){this.isLoaded=e,this.emit("confirm",this,t)};var v={};return c.prototype=new t,c.prototype.check=function(){if(!this.isChecked){var e=new Image;n.bind(e,"load",this),n.bind(e,"error",this),e.src=this.src,this.isChecked=!0}},c.prototype.handleEvent=function(e){var t="on"+e.type;this[t]&&this[t](e)},c.prototype.onload=function(e){this.confirm(!0,"onload"),this.unbindProxyEvents(e)},c.prototype.onerror=function(e){this.confirm(!1,"onerror"),this.unbindProxyEvents(e)},c.prototype.confirm=function(e,t){this.isConfirmed=!0,this.isLoaded=e,this.emit("confirm",this,t)},c.prototype.unbindProxyEvents=function(e){n.unbind(e.target,"load",this),n.unbind(e.target,"error",this)},s});

	function isElementInViewport_gallery(el, h) {
		var scrolled = window.pageYOffset;
		var viewed = scrolled + getViewportH();
		var elH = el.offsetHeight;
		var elTop = getOffset(el).top;
		var elBottom = elTop + elH;
		var h = h || 0;

		if(!TRANSITION_SUPPORT){
			scrolled = document.body.scrollTop || document.documentElement.scrollTop;
			viewed = scrolled + getViewportH();
		}
		if (window.project) {
			scrolled = scrolled + $(el).parent().parent().scrollTop();
			viewed = scrolled + getViewportH();
		}

		return (elTop + elH * h) <= viewed && (elBottom) >= scrolled;
	}
	
	function getViewportH() {
		var client = window.document.documentElement['clientHeight'],
			inner = window['innerHeight'] ? window['innerHeight'] : $(window).height();   

		return (client < inner) ? inner : client;            
	}
	
	function getOffset(el) {
		var offsetTop = 0,
			offsetLeft = 0;

		do {
			if (!isNaN(el.offsetTop)) {
				offsetTop += el.offsetTop;
			}
			if (!isNaN(el.offsetLeft)) {
				offsetLeft += el.offsetLeft;
			}
		} while (el = el.offsetParent)

		return {
			top: offsetTop,
			left: offsetLeft
		}
	}
	
	var transitionCheckStyles = document.createElement('div').style;
	
	var TRANSITION_SUPPORT = (transitionCheckStyles.transition != null) || (transitionCheckStyles.webkitTransition != null) || (transitionCheckStyles.mozTransition != null) || (transitionCheckStyles.oTransition != null);
	
	!function(a,b,c,d){var e=a(b);a.fn.lazyload=function(f){function g(){var b=0;i.each(function(){var c=a(this);if(!j.skip_invisible||c.is(":visible"))if(a.abovethetop(this,j)||a.leftofbegin(this,j));else if(a.belowthefold(this,j)||a.rightoffold(this,j)){if(++b>j.failure_limit)return!1}else c.trigger("appear"),b=0})}var h,i=this,j={threshold:0,failure_limit:0,event:"scroll",effect:"show",container:b,data_attribute:"original",skip_invisible:!1,appear:null,load:null,placeholder:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsQAAA7EAZUrDhsAAAANSURBVBhXYzh8+PB/AAffA0nNPuCLAAAAAElFTkSuQmCC"};return f&&(d!==f.failurelimit&&(f.failure_limit=f.failurelimit,delete f.failurelimit),d!==f.effectspeed&&(f.effect_speed=f.effectspeed,delete f.effectspeed),a.extend(j,f)),h=j.container===d||j.container===b?e:a(j.container),0===j.event.indexOf("scroll")&&h.bind(j.event,function(){return g()}),this.each(function(){var b=this,c=a(b);b.loaded=!1,(c.attr("src")===d||c.attr("src")===!1)&&c.is("img")&&c.attr("src",j.placeholder),c.one("appear",function(){if(!this.loaded){if(j.appear){var d=i.length;j.appear.call(b,d,j)}a("<img />").bind("load",function(){var d=c.attr("data-"+j.data_attribute);c.hide(),c.is("img")?c.attr("src",d):c.css("background-image","url('"+d+"')"),c[j.effect](j.effect_speed),b.loaded=!0;var e=a.grep(i,function(a){return!a.loaded});if(i=a(e),j.load){var f=i.length;j.load.call(b,f,j)}}).attr("src",c.attr("data-"+j.data_attribute))}}),0!==j.event.indexOf("scroll")&&c.bind(j.event,function(){b.loaded||c.trigger("appear")})}),e.bind("resize",function(){g()}),/(?:iphone|ipod|ipad).*os 5/gi.test(navigator.appVersion)&&e.bind("pageshow",function(b){b.originalEvent&&b.originalEvent.persisted&&i.each(function(){a(this).trigger("appear")})}),a(c).ready(function(){g()}),this},a.belowthefold=function(c,f){var g;return g=f.container===d||f.container===b?(b.innerHeight?b.innerHeight:e.height())+e.scrollTop():a(f.container).offset().top+a(f.container).height(),g<=a(c).offset().top-f.threshold},a.rightoffold=function(c,f){var g;return g=f.container===d||f.container===b?e.width()+e.scrollLeft():a(f.container).offset().left+a(f.container).width(),g<=a(c).offset().left-f.threshold},a.abovethetop=function(c,f){var g;return g=f.container===d||f.container===b?e.scrollTop():a(f.container).offset().top,g>=a(c).offset().top+f.threshold+a(c).height()},a.leftofbegin=function(c,f){var g;return g=f.container===d||f.container===b?e.scrollLeft():a(f.container).offset().left,g>=a(c).offset().left+f.threshold+a(c).width()},a.inviewport=function(b,c){return!(a.rightoffold(b,c)||a.leftofbegin(b,c)||a.belowthefold(b,c)||a.abovethetop(b,c))},a.extend(a.expr[":"],{"below-the-fold":function(b){return a.belowthefold(b,{threshold:0})},"above-the-top":function(b){return!a.belowthefold(b,{threshold:0})},"right-of-screen":function(b){return a.rightoffold(b,{threshold:0})},"left-of-screen":function(b){return!a.rightoffold(b,{threshold:0})},"in-viewport":function(b){return a.inviewport(b,{threshold:0})},"above-the-fold":function(b){return!a.belowthefold(b,{threshold:0})},"right-of-fold":function(b){return a.rightoffold(b,{threshold:0})},"left-of-fold":function(b){return!a.rightoffold(b,{threshold:0})}})}(gallery_jQuery,window,document);
	
	(function($) {

	/**
	Mobile support module for lightbox
		- creates HTML structure needed on mobile
		- initializes carousel pluggin
	*/


	var GalleryMobify = window.GalleryMobify = window.GalleryMobify || {};
	GalleryMobify.$ = GalleryMobify.$ || window.Zepto || window.gallery_jQuery;
	GalleryMobify.UI = GalleryMobify.UI ? GalleryMobify.$.extend(GalleryMobify.UI, { classPrefix: 'm-' }) : { classPrefix: 'm-' };

	(function($, document) {
	    $.support = $.support || {};

	    $.extend($.support, {
	        'touch': 'ontouchend' in document
	    });

	})(GalleryMobify.$, document);



	/**
	    @module Holds common functions relating to UI.
	*/
	GalleryMobify.UI.Utils = (function($) {
	    var exports = {}
	        , has = $.support
	        , ua = navigator.userAgent;

	    /**
	        Events (either touch or mouse)
	    */
	    exports.events = (has.touch)
	        ? {down: 'touchstart', move: 'touchmove', up: 'touchend'}
	        : {down: 'mousedown', move: 'mousemove', up: 'mouseup'};

	    /**
	        Returns the position of a mouse or touch event in (x, y)
	        @function
	        @param {Event} touch or mouse event
	        @returns {Object} X and Y coordinates
	    */
	    exports.getCursorPosition = (has.touch)
	        ? function(e) {e = e.originalEvent || e; return {x: e.touches[0].clientX, y: e.touches[0].clientY}}
	        : function(e) {return {x: e.clientX, y: e.clientY}};


	    /**
	        Returns prefix property for current browser.
	        @param {String} CSS Property Name
	        @return {String} Detected CSS Property Name
	    */
	    exports.getProperty = function(name) {
	        var prefixes = ['Webkit', 'Moz', 'O', 'ms', '']
	          , testStyle = document.createElement('div').style;
	        
	        for (var i = 0; i < prefixes.length; ++i) {
	            if (testStyle[prefixes[i] + name] !== undefined) {
	                return prefixes[i] + name;
	            }
	        }

	        // Not Supported
	        return;
	    };

	    $.extend(has, {
	        'transform': !! (exports.getProperty('Transform'))

	        // Usage of transform3d on *android* would cause problems for input fields:
	        // - https://coderwall.com/p/d5lmba
	        // - http://static.trygve-lie.com/bugs/android_input/
	      , 'transform3d': !! (window.WebKitCSSMatrix && 'm11' in new WebKitCSSMatrix() && !/android\s+[1-2]/i.test(ua)) 
	    });

	    // translateX(element, delta)
	    // Moves the element by delta (px)
	    var transformProperty = exports.getProperty('Transform');
	    if (has.transform3d) {
	        exports.translateX = function(element, delta) {
	             if (typeof delta == 'number') delta = delta + 'px';
	             element.style[transformProperty] = 'translate3d(' + delta  + ',0,0)';
	        };
	    } else if (has.transform) {
	        exports.translateX = function(element, delta) {
	             if (typeof delta == 'number') delta = delta + 'px';
	             element.style[transformProperty] = 'translate(' + delta  + ',0)';
	        };
	    } else {
	        exports.translateX = function(element, delta) {
	            if (typeof delta == 'number') delta = delta + 'px';
	            element.style.left = delta;
	        };
	    }

	    // setTransitions
	    var transitionProperty = exports.getProperty('Transition')
	      , durationProperty = exports.getProperty('TransitionDuration');

	    exports.setTransitions = function(element, enable) {
	        if (enable) {
	            element.style[durationProperty] = '';
	        } else {
	            element.style[durationProperty] = '0s';
	        }
	    }


	    // Request Animation Frame
	    // courtesy of @paul_irish
	    exports.requestAnimationFrame = (function() {
	        var prefixed = (window.requestAnimationFrame       || 
	                        window.webkitRequestAnimationFrame || 
	                        window.mozRequestAnimationFrame    || 
	                        window.oRequestAnimationFrame      || 
	                        window.msRequestAnimationFrame     || 
	                        function( callback ){
	                            window.setTimeout(callback, 1000 / 60);
	                        });

	        var requestAnimationFrame = function() {
	            prefixed.apply(window, arguments);
	        };

	        return requestAnimationFrame;
	    })();

	    return exports;

	})(GalleryMobify.$);

	GalleryMobify.UI.Carousel = (function($, Utils) {
	    var defaults = {
	            dragRadius: 10
	          , moveRadius: 10
	          , classPrefix: undefined
	          , classNames: {
	                outer: 'carousel'
	              , inner: 'carousel-inner'
	              , item: 'item'
	              , center: 'center'
	              , touch: 'has-touch'
	              , dragging: 'dragging'
	              , active: 'active'
	              , fluid: 'fluid'
	            }
	        }
	       , has = $.support;

	    // Constructor
	    var Carousel = function(element, options) {
	        this.setOptions(options);
	        this.initElements(element);
	        this.initOffsets();
	        this.initAnimation();
	        this.bind();
	    };

	    // Expose Dfaults
	    Carousel.defaults = defaults;
	    
	    Carousel.prototype.setOptions = function(opts) {
	        var options = this.options || $.extend({}, defaults, opts);
	        
	        /* classNames requires a deep copy */
	        options.classNames = $.extend({}, options.classNames, opts.classNames || {});

	        /* By default, classPrefix is `undefined`, which means to use the GalleryMobify-wide level prefix */
	        options.classPrefix = options.classPrefix || GalleryMobify.UI.classPrefix;

	        
	        this.options = options;
	    };

	    Carousel.prototype.initElements = function(element) {
	        this._index = 1;  // 1-based index
	        
	        this.element = element;
	        this.$element = $(element);
	        this.$inner = this.$element.find('.' + this._getClass('inner'));

	        this.$items = this.$inner.children();
	        
	        this.$start = this.$items.eq(0);
	        this.$sec = this.$items.eq(1);
	        this.$current = this.$items.eq(this._index - 1);  // convert to 0-based index

	        this._length = this.$items.length;
	        this._alignment = this.$element.hasClass(this._getClass('center')) ? 0.5 : 0;

	        this._isFluid = this.$element.hasClass(this._getClass('fluid'));
	    };

	    Carousel.prototype.initOffsets = function() {
	        this._offsetDrag = 0;
	    }

	    Carousel.prototype.initAnimation = function() {
	        this.animating = false;
	        this.dragging = false;
	        this._needsUpdate = false;
	        this._enableAnimation();
	    };


	    Carousel.prototype._getClass = function(id) {
	        return this.options.classPrefix + this.options.classNames[id];
	    };


	    Carousel.prototype._enableAnimation = function() {
	        if (this.animating) {
	            return;
	        }

	        Utils.setTransitions(this.$inner[0], true);
	        this.$inner.removeClass(this._getClass('dragging'));
	        this.animating = true;
	    }

	    Carousel.prototype._disableAnimation = function() {
	        if (!this.animating) {
	            return;
	        }
	        if (this.$inner==null) {
				this.$inner = $("#m-carousel-inner");
			}
	        Utils.setTransitions(this.$inner[0], false);
	        this.$inner.addClass(this._getClass('dragging'));
	        this.animating = false;
	    }

	    Carousel.prototype.update = function() {
	        /* We throttle calls to the real `_update` for efficiency */
	        if (this._needsUpdate) {
	            return;
	        }

	        var self = this;
	        this._needsUpdate = true;
	        Utils.requestAnimationFrame(function() {
	            self._update();
	        });
	    }

	    Carousel.prototype._update = function() {
	        if (!this._needsUpdate) {
	            return;
	        }

	        var $current = this.$current
	          , $start = this.$start;
	        var currentOffset = $current.prop('offsetLeft') + $current.prop('clientWidth') * this._alignment
	          , startOffset = $start.prop('offsetLeft') + $start.prop('clientWidth') * this._alignment
	          , x = Math.round(-(currentOffset - startOffset) + this._offsetDrag);
			  
	        Utils.translateX(this.$inner[0], x);

	        this._needsUpdate = false;
	    }

	    Carousel.prototype.bind = function() {
	        var abs = Math.abs
	            , dragging = false
	            , canceled = false
	            , dragRadius = this.options.dragRadius
	            , xy
	            , dx
	            , dy
	            , dragThresholdMet
	            , self = this
	            , $element = this.$element
	            , $inner = this.$inner
	            , opts = this.options
	            , lockLeft = false
	            , lockRight = false
	            , windowWidth = $(window).width();

	        function start(e) {
	        	
	            if (!has.touch) e.preventDefault();
	            
	            dragging = true;
	            canceled = false;

	            xy = Utils.getCursorPosition(e);
	            dx = 0;
	            dy = 0;
	            dragThresholdMet = false;

	            // Disable smooth transitions
	            self._disableAnimation();

	            lockLeft = self._index == 1;
	            lockRight = self._index == self._length;
	        }

	        function drag(e) {
	        	
	            if (!dragging || canceled) return;

	            var newXY = Utils.getCursorPosition(e)
	              , dragLimit = self.$element.width();
	            dx = xy.x - newXY.x;
	            dy = xy.y - newXY.y;

	            if (dragThresholdMet || abs(dx) > abs(dy) && (abs(dx) > dragRadius)) {
	                dragThresholdMet = true;
	                e.preventDefault();
	                
	                if (lockLeft && (dx < 0)) {
	                    dx = dx * (-dragLimit)/(dx - dragLimit);
	                } else if (lockRight && (dx > 0)) {
	                    dx = dx * (dragLimit)/(dx + dragLimit);
	                }
	                self._offsetDrag = -dx;
	                self.update();
	            } else if ((abs(dy) > abs(dx)) && (abs(dy) > dragRadius)) {
	                canceled = true;
	            }
	        }

	        function end(e) {
	        	
	            if (!dragging) {
	                return;
	            }

	            dragging = false;
	            
	            self._enableAnimation();

	            if (!canceled && abs(dx) > opts.moveRadius) {
	                // Move to the next slide if necessary
	                if (dx > 0) {
	                    self.next();
	                } else {
	                    self.prev();
	                }
	            } else {
	                // Reset back to regular position
	                self._offsetDrag = 0;
	                self.update();
	            }

	        }

	        function click(e) {
	            if (dragThresholdMet) e.preventDefault();
	        }
	       
	        $inner
	            .bind(Utils.events.down + '.carousel', start)
	            .bind(Utils.events.move + '.carousel', drag)
	            .bind(Utils.events.up + '.carousel', end)
	            .bind('click.carousel', click)
	            .bind('mouseout.carousel', end);

	        $element.bind('click', '[data-slide]', function(e){
	            e.preventDefault();
	            var action = $(this).attr('data-slide')
	              , index = parseInt(action, 10);

	            if (!isNaN(index)) {
	                self.move(index);
	            }
	        });

	        $element.on('afterSlide', function(e, previousSlide, nextSlide) {
	            self.$items.eq(previousSlide - 1).removeClass(self._getClass('active'));
	            self.$items.eq(nextSlide - 1).addClass(self._getClass('active'));

	            self.$element.find('[data-slide=\'' + previousSlide + '\']').removeClass(self._getClass('active'));
	            self.$element.find('[data-slide=\'' + nextSlide + '\']').addClass(self._getClass('active'));
	        });
	        $(window).unbind('resize.mobile2 orientationchange.mobile2').bind('resize.mobile2 orientationchange.mobile2', function(e) {
	            // Disable animation for now to avoid seeing 
	            // the carousel sliding, as it updates its position.
	            // Animation will be enabled automatically when you're swiping.
	            // Don't update Carousel on window height change
	            if(windowWidth == $(window).width())
	                return;
				
				self._disableAnimation();
				windowWidth = $(window).width();
				var gallery = $('#mobile-gallery');
				centerMobileGallery(gallery);
				$('.m-item img').each(function() {
					$(this).trigger('load');
				});
				setTimeout(function() {
					self.update();
				}, 10);
	        });

	        $element.trigger('beforeSlide', [1, 1]);
	        $element.trigger('afterSlide', [1, 1]);

	        self.update();

	    };

	    Carousel.prototype.unbind = function() {
	        this.$inner.off();
	    }

	    Carousel.prototype.destroy = function() {
	        this.unbind();
	        this.$element.trigger('destroy');
	        this.$element.remove();
	        
	        // Cleanup
	        this.$element = null;
	        this.$inner = null;
	        this.$start = null;
	        this.$current = null;
	    }

	    Carousel.prototype.move = function(newIndex, opts) {
	        var $element = this.$element
	            , $inner = this.$inner
	            , $items = this.$items
	            , $start = this.$start
	            , $current = this.$current
	            , length = this._length
	            , index = this._index;
	                
	        opts = opts || {};

	        // Bound Values between [1, length];
	        if (newIndex < 1) {
	            newIndex = 1;
	        } else if (newIndex > this._length) {
	            newIndex = length;
	        }
	        
	        // Bail out early if no move is necessary.
	        if (newIndex == this._index) {
	            //return; // Return Type?
	        }

	        // Making sure that animation is enabled before moving
	        this._enableAnimation();

	        // Trigger beforeSlide event
	        $element.trigger('beforeSlide', [index, newIndex]);


	        // Index must be decremented to convert between 1- and 0-based indexing.
	        this.$current = $current = $items.eq(newIndex - 1);

	        this._offsetDrag = 0;
	        this._index = newIndex;
	        this.update();
	        // Trigger afterSlide event
	        $element.trigger('afterSlide', [index, newIndex]);
	    };

	    Carousel.prototype.next = function() {
	        this.move(this._index + 1);
	    };
	    
	    Carousel.prototype.prev = function() {
	        this.move(this._index - 1);
	    };

	    return Carousel;

	})(GalleryMobify.$, GalleryMobify.UI.Utils);

    /**
        jQuery interface to set up a carousel


        @param {String} [action] Action to perform. When no action is passed, the carousel is simply initialized.
        @param {Object} [options] Options passed to the action.
    */
    $.fn.carousel = function (action, options) {
        var initOptions = $.extend({}, $.fn.carousel.defaults);

        // Handle different calling conventions
        if (typeof action == 'object') {
            initOptions = $(initOptions, action);
            options = null;
            action = null;
        }

        this.each(function () {
            var $this = $(this)
              , carousel = this._carousel;

            
            if (!carousel) {
                carousel = new GalleryMobify.UI.Carousel(this, initOptions);
            }

            if (action) {
                if (options instanceof Array) {
					var callstring = "carousel[action](options[0]";
					for (var i=1; i<options.length; i++) {
						callstring += ",options[1]";
					}
					callstring += ")";
					eval(callstring);
				} else {
					carousel[action](options);
				}

                if (action === 'destroy') {
                    carousel = null;
                }
            }
            
            this._carousel = carousel;
        })

        return this;
    };

    $.fn.carousel.defaults = {};

})(gallery_jQuery);

})(gallery_jQuery);